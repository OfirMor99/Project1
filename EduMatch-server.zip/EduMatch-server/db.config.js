module.exports = {
  HOST: "localhost",
  USER: "edumatch_user",
  PASSWORD: "Or572001!",
  DB: "edumatch"
};
