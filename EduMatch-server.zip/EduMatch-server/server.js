// server.js (clean, no duplicates) — UPDATED: teacher history excludes cancelled + student past fix
// Main Express server entry point for the EduMatch API (routes, helpers, middleware)

const express = require("express"); // Web server framework
const cookieParser = require("cookie-parser"); // Reads cookies from incoming requests (req.cookies)
const db = require("./db"); // MySQL connection (db.query)

const usersController = require("./controllers/users.controller"); // Auth + profile logic (register/login/me/update/logout)
const favoritesController = require("./controllers/favorites.controller"); // Favorites endpoints (get/add/remove)

const app = express(); // Create the Express application
const PORT = 3001; // Server port (http://localhost:3001)

console.log("✅ MY EXPRESS SERVER RUNNING ON", PORT); // Startup log
console.log("🔥 SERVER VERSION: CLEAN (NO DUPLICATES) + BOOKINGS FIXES"); // Version/debug log

// =======================
// MIDDLEWARE
// =======================
app.use(express.json()); // Parse JSON request bodies into req.body
app.use(express.urlencoded({ extended: true })); // Parse URL-encoded bodies (forms)
app.use(cookieParser()); // Parse cookies into req.cookies
app.use(express.static("public")); // Serve files from /public (HTML/CSS/JS/images)

// =======================
// HELPERS
// =======================
function normalizeDate(val) {
  // Converts different date inputs into "YYYY-MM-DD" or returns null if invalid

  if (val === undefined || val === null) return null; // Missing value

  // If it's a JS Date object -> format as local date (avoids UTC shift issues)
  if (val instanceof Date && !isNaN(val.getTime())) {
    const y = val.getFullYear();
    const m = String(val.getMonth() + 1).padStart(2, "0");
    const d = String(val.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  }

  const s0 = String(val).trim(); // Convert to string and trim spaces
  if (!s0) return null; // Empty string

  // If already starts with YYYY-MM-DD -> keep only the date part
  if (/^\d{4}-\d{2}-\d{2}/.test(s0)) return s0.slice(0, 10);

  // Supports DD/MM/YYYY or DD-MM-YYYY or DD.MM.YYYY -> convert to YYYY-MM-DD
  const dmY = s0.match(/^(\d{1,2})[.\-/](\d{1,2})[.\-/](\d{4})$/);
  if (dmY) {
    const dd = String(Number(dmY[1])).padStart(2, "0");
    const mm = String(Number(dmY[2])).padStart(2, "0");
    const yy = String(dmY[3]);
    return `${yy}-${mm}-${dd}`;
  }

  return null; // Unrecognized format
}

function getAuthUserId(req) {
  // Reads the logged-in user id from the auth cookie ("authUser")
  const userId = req.cookies?.authUser;
  const n = userId ? Number(userId) : null;
  return Number.isFinite(n) ? n : null; // Returns number or null
}

function queryAsync(sql, params = []) {
  // Promisified db.query helper so we can use async/await
  return new Promise((resolve, reject) => {
    db.query(sql, params, (err, rows) => {
      if (err) return reject(err);
      resolve(rows);
    });
  });
}

function cleanStr(val) {
  // Normalizes string inputs: trims and returns null for empty values
  if (val === undefined || val === null) return null;
  const s = String(val).trim();
  return s ? s : null;
}

function normalizeTime(val) {
  // Converts time input to "HH:MM" or returns null if invalid
  if (val === undefined || val === null) return null;

  const s = String(val).trim();
  if (!s) return null;

  // Accept "HH:MM"
  if (/^\d{2}:\d{2}$/.test(s)) return s;

  // Accept "HH:MM:SS" and cut seconds
  if (/^\d{2}:\d{2}:\d{2}$/.test(s)) return s.slice(0, 5);

  return null; // Invalid time format
}

async function requireTeacher(req, res) {
  // Guard: ensures the current user is logged in AND has role "teacher"
  // Returns userId if teacher, otherwise returns null after sending response

  const userId = getAuthUserId(req);
  if (!userId) {
    res.status(401).json({ ok: false, message: "Unauthorized" }); // Not logged in
    return null;
  }

  // Fetch the role for this user from user_roles + roles
  const roleRows = await queryAsync(
    `
    SELECT r.role_name
    FROM user_roles ur
    JOIN roles r ON r.role_id = ur.role_id
    WHERE ur.user_id = ?
    LIMIT 1
    `,
    [userId]
  );

  const role = roleRows.length ? String(roleRows[0].role_name) : "student"; // Default to student if missing
  if (role !== "teacher") {
    res.status(403).json({ ok: false, message: "Teachers only" }); // Logged in but not a teacher
    return null;
  }

  return userId; // Authorized teacher
}

// =======================
// HEALTH / DEBUG
// =======================
app.get("/api/health", (req, res) => {
  // Simple health check endpoint
  res.json({ ok: true, message: "EduMatch API is running" });
});

app.post("/api/echo", (req, res) => {
  // Debug endpoint: logs and returns the body you send
  console.log("✅ HIT: /api/echo", { query: req.query, body: req.body });
  res.json({ receivedBody: req.body });
});

// =======================
// ✅ CITIES API
// =======================
app.get("/api/cities", async (req, res) => {
  // Returns distinct list of cities from teacher_profile for the UI dropdown

  // Disable caching so the list updates immediately when DB changes
  res.set("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
  res.set("Pragma", "no-cache");
  res.set("Expires", "0");

  try {
    const rows = await queryAsync(
      `
      SELECT DISTINCT city
      FROM teacher_profile
      WHERE city IS NOT NULL
        AND city <> ''
      ORDER BY city
      `
    );

    const cities = rows.map((r) => r.city); // Convert rows -> array of strings
    return res.json({ ok: true, cities });
  } catch (err) {
    console.error("DB error (GET /api/cities):", err);
    return res.status(500).json({ ok: false, message: "DB error" });
  }
});

// =======================
// SUBJECTS RESOLVE (GET)
// =======================
app.get("/api/subjects/resolve", async (req, res) => {
  // Utility endpoint: resolves a subject name into its subject_id

  try {
    const name = cleanStr(req.query?.name); // Normalize query input
    if (!name) return res.status(400).json({ ok: false, message: "Missing name" });

    const rows = await queryAsync(
      "SELECT subject_id FROM subjects WHERE subject_name = ? LIMIT 1",
      [name]
    );

    if (!rows.length) return res.status(404).json({ ok: false, message: "Subject not found" });
    return res.json({ ok: true, subject_id: rows[0].subject_id });
  } catch (err) {
    console.error("DB error (GET /api/subjects/resolve):", err);
    return res.status(500).json({ ok: false, message: "DB error" });
  }
});

// =======================
// REGISTER / LOGIN / AUTH
// =======================
app.post("/api/register", usersController.register); // Create new user + role (+ teacher profile if needed)
app.post("/api/login", usersController.login); // Login and set auth cookie

app.get("/api/me", usersController.me); // Get current user details (based on cookie)
app.put("/api/me", usersController.updateMe); // Update profile (including teacher fields)
app.post("/api/logout", usersController.logout); // Clear auth cookie / logout

// =======================
// FAVORITES API
// =======================
app.get("/api/favorites", favoritesController.getFavorites); // List favorites for current user
app.post("/api/favorites/:teacherId", favoritesController.addFavorite); // Add teacher to favorites
app.delete("/api/favorites/:teacherId", favoritesController.removeFavorite); // Remove teacher from favorites

// =======================
// BOOKINGS API
// =======================
app.post("/api/bookings", async (req, res) => {
  // Student creates a booking request (currently inserts booking row, lesson_mode copied from teacher_profile)

  try {
    const student_user_id = getAuthUserId(req);
    if (!student_user_id) return res.status(401).json({ ok: false, message: "התחבר על מנת להזמין שיעור" }); // Must be logged in

    // Read inputs (supports teacher_user_id OR teacher_id on the client side)
    const teacher_user_id = Number(req.body?.teacher_user_id ?? req.body?.teacher_id);
    const subject_id = Number(req.body?.subject_id);
    const lesson_date = normalizeDate(req.body?.lesson_date ?? req.body?.date);
    const start_time = normalizeTime(req.body?.start_time);

    // Validate inputs early (avoid bad inserts)
    if (!Number.isFinite(teacher_user_id)) return res.status(400).json({ ok: false, message: "Invalid teacher_user_id" });
    if (!Number.isFinite(subject_id)) return res.status(400).json({ ok: false, message: "Invalid subject_id" });
    if (!lesson_date) return res.status(400).json({ ok: false, message: "Invalid lesson_date" });
    if (!start_time) return res.status(400).json({ ok: false, message: "Invalid start_time" });

    // Ensure teacher teaches this subject and get price/duration from teacher_subjects
    const tsRows = await queryAsync(
      `SELECT price_per_hour, duration_minutes
       FROM teacher_subjects
       WHERE user_id = ? AND subject_id = ?
       LIMIT 1`,
      [teacher_user_id, subject_id]
    );
    if (!tsRows.length) return res.status(400).json({ ok: false, message: "Teacher does not teach this subject" });

    // Get teacher's lesson_mode (frontal/online/both)
    const tpRows = await queryAsync(
      `SELECT lesson_mode FROM teacher_profile WHERE user_id = ? LIMIT 1`,
      [teacher_user_id]
    );
    const lesson_mode = tpRows.length ? tpRows[0].lesson_mode : "both"; // Default fallback

    // Prevent double-booking: if there's already a CONFIRMED booking for that slot, block it
    const exists = await queryAsync(
      `SELECT booking_id FROM bookings
       WHERE teacher_user_id = ? AND lesson_date = ? AND start_time = ? AND status = 'confirmed'
       LIMIT 1`,
      [teacher_user_id, lesson_date, start_time]
    );
    if (exists.length) return res.status(409).json({ ok: false, message: "השעה הזו כבר תפוסה" });

    const { price_per_hour, duration_minutes } = tsRows[0]; // Values to store in booking row

    // Insert booking row
    const ins = await queryAsync(
      `INSERT INTO bookings
       (student_user_id, teacher_user_id, subject_id, lesson_date, start_time,
        duration_minutes, price_per_hour, lesson_mode)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        student_user_id,
        teacher_user_id,
        subject_id,
        lesson_date,
        start_time,
        Number(duration_minutes),
        Number(price_per_hour),
        lesson_mode,
      ]
    );

    return res.json({ ok: true, bookingId: ins.insertId }); // Return booking id to the client
  } catch (err) {
    console.error("DB error (POST /api/bookings):", err);
    return res.status(500).json({ ok: false, message: "DB error" });
  }
});

// -----------------------
// Student: future bookings
// -----------------------
app.get("/api/bookings/future", async (req, res) => {
  // Returns future bookings for the logged-in student (excluding cancelled)

  try {
    const student_user_id = getAuthUserId(req);
    if (!student_user_id) return res.status(401).json({ ok: false, message: "התחבר על מנת לצפות בשיעורים" });

    const rows = await queryAsync(
      `SELECT
         b.booking_id,
         DATE_FORMAT(b.lesson_date, '%Y-%m-%d') AS lesson_date,
         TIME_FORMAT(b.start_time, '%H:%i') AS start_time,
         b.duration_minutes,
         b.price_per_hour,
         b.lesson_mode,
         b.status,
         s.subject_name,
         u.user_id AS teacher_user_id,
         u.first_name AS teacher_first_name,
         u.last_name  AS teacher_last_name
       FROM bookings b
       JOIN subjects s ON s.subject_id = b.subject_id
       JOIN users u ON u.user_id = b.teacher_user_id
       WHERE b.student_user_id = ?
         AND b.status <> 'cancelled'
         AND TIMESTAMP(b.lesson_date, b.start_time) >= NOW()
       ORDER BY b.lesson_date ASC, b.start_time ASC`,
      [student_user_id]
    );

    return res.json({ ok: true, lessons: rows });
  } catch (err) {
    console.error("DB error (GET /api/bookings/future):", err);
    return res.status(500).json({ ok: false, message: "DB error" });
  }
});

// -----------------------
// Student: past bookings (history) ✅ FIXED: filter by student_user_id
// -----------------------
app.get("/api/bookings/past", async (req, res) => {
  // Returns past CONFIRMED bookings for the logged-in student (history)

  try {
    const student_user_id = getAuthUserId(req);
    if (!student_user_id) return res.status(401).json({ ok: false, message: "התחבר על מנת לצפות בשיעורים" });

    const rows = await queryAsync(
      `SELECT
         b.booking_id,
         DATE_FORMAT(b.lesson_date, '%Y-%m-%d') AS lesson_date,
         TIME_FORMAT(b.start_time, '%H:%i') AS start_time,
         b.duration_minutes,
         b.price_per_hour,
         b.lesson_mode,
         b.status,
         s.subject_name,
         u.user_id AS teacher_user_id,
         u.first_name AS teacher_first_name,
         u.last_name  AS teacher_last_name
       FROM bookings b
       JOIN subjects s ON s.subject_id = b.subject_id
       JOIN users u ON u.user_id = b.teacher_user_id
       WHERE b.student_user_id = ?
         AND b.status = 'confirmed'
         AND TIMESTAMP(b.lesson_date, b.start_time) < NOW()
       ORDER BY b.lesson_date DESC, b.start_time DESC`,
      [student_user_id]
    );

    return res.json({ ok: true, lessons: rows });
  } catch (err) {
    console.error("DB error (GET /api/bookings/past):", err);
    return res.status(500).json({ ok: false, message: "DB error" });
  }
});

// -----------------------
// Teacher: future bookings
// -----------------------
app.get("/api/bookings/teacher/future", async (req, res) => {
  // Returns future bookings for the logged-in teacher (excluding cancelled)

  try {
    const teacher_user_id = await requireTeacher(req, res);
    if (!teacher_user_id) return; // requireTeacher already responded

    const rows = await queryAsync(
      `
      SELECT
        b.booking_id,
        DATE_FORMAT(b.lesson_date, '%Y-%m-%d') AS lesson_date,
        TIME_FORMAT(b.start_time, '%H:%i') AS start_time,
        b.duration_minutes,
        b.price_per_hour,
        b.lesson_mode,
        b.status,
        s.subject_name,

        stu.user_id AS student_user_id,
        stu.first_name AS student_first_name,
        stu.last_name  AS student_last_name,
        stu.email      AS student_email
      FROM bookings b
      JOIN subjects s ON s.subject_id = b.subject_id
      JOIN users stu ON stu.user_id = b.student_user_id
      WHERE b.teacher_user_id = ?
        AND b.status <> 'cancelled'
        AND TIMESTAMP(b.lesson_date, b.start_time) >= NOW()
      ORDER BY b.lesson_date ASC, b.start_time ASC
      `,
      [teacher_user_id]
    );

    return res.json({ ok: true, lessons: rows });
  } catch (err) {
    console.error("DB error (GET /api/bookings/teacher/future):", err);
    return res.status(500).json({ ok: false, message: "DB error" });
  }
});

// -----------------------
// Teacher: past bookings (history) ✅ FIXED: exclude cancelled completely
// -----------------------
app.get("/api/bookings/teacher/past", async (req, res) => {
  // Returns past CONFIRMED bookings for the logged-in teacher (history)

  try {
    const teacher_user_id = await requireTeacher(req, res);
    if (!teacher_user_id) return; // requireTeacher already responded

    const rows = await queryAsync(
      `
      SELECT
        b.booking_id,
        DATE_FORMAT(b.lesson_date, '%Y-%m-%d') AS lesson_date,
        TIME_FORMAT(b.start_time, '%H:%i') AS start_time,
        b.duration_minutes,
        b.price_per_hour,
        b.lesson_mode,
        b.status,
        s.subject_name,

        stu.user_id AS student_user_id,
        stu.first_name AS student_first_name,
        stu.last_name  AS student_last_name,
        stu.email      AS student_email
      FROM bookings b
      JOIN subjects s ON s.subject_id = b.subject_id
      JOIN users stu ON stu.user_id = b.student_user_id
      WHERE b.teacher_user_id = ?
        AND b.status = 'confirmed'
        AND TIMESTAMP(b.lesson_date, b.start_time) < NOW()
      ORDER BY b.lesson_date DESC, b.start_time DESC
      `,
      [teacher_user_id]
    );

    return res.json({ ok: true, lessons: rows });
  } catch (err) {
    console.error("DB error (GET /api/bookings/teacher/past):", err);
    return res.status(500).json({ ok: false, message: "DB error" });
  }
});

// -----------------------
// Cancel booking (student only)
// -----------------------
app.put("/api/bookings/:id/cancel", async (req, res) => {
  // Allows a student to cancel a FUTURE confirmed booking that belongs to them

  try {
    const student_user_id = getAuthUserId(req);
    if (!student_user_id) return res.status(401).json({ ok: false, message: "התחבר על מנת לבטל שיעור" });

    const bookingId = Number(req.params.id);
    if (!Number.isFinite(bookingId)) return res.status(400).json({ ok: false, message: "Invalid booking id" });

    // Only cancels if:
    // - booking belongs to this student
    // - status is confirmed
    // - lesson is in the future
    const result = await queryAsync(
      `
      UPDATE bookings
      SET status = 'cancelled'
      WHERE booking_id = ?
        AND student_user_id = ?
        AND status = 'confirmed'
        AND TIMESTAMP(lesson_date, start_time) > NOW()
      `,
      [bookingId, student_user_id]
    );

    if (!result.affectedRows) {
      // Not found / already cancelled / not owned / not future
      return res.status(404).json({
        ok: false,
        message: "לא נמצאה הזמנה לביטול (אולי כבר בוטלה / לא שלך / לא עתידית).",
      });
    }

    return res.json({ ok: true });
  } catch (err) {
    console.error("DB error (PUT /api/bookings/:id/cancel):", err);
    return res.status(500).json({ ok: false, message: "DB error" });
  }
});

// =======================
// TEACHERS SEARCH (GET)
// =======================
app.get("/api/teachers", (req, res) => {
  // Teachers search endpoint for the Teachers page (filters: subject, city, name, maxPrice)

  const subject = (req.query.subject || "").trim(); // Required (min length 2)
  const city = (req.query.city || "").trim(); // Optional exact match
  const name = (req.query.name || "").trim(); // Optional partial match on full name
  const maxPrice = req.query.maxPrice ? Number(req.query.maxPrice) : null; // Optional numeric filter

  // Hard requirement: subject must exist (prevents returning huge results)
  if (!subject || subject.length < 2) return res.json({ ok: true, teachers: [] });

  const params = []; // SQL parameter values
  let where = `
    WHERE r.role_name = 'teacher'
      AND s.subject_name LIKE ?
  `;
  params.push(`%${subject}%`); // Subject search is partial match

  if (city) {
    where += " AND tp.city = ? ";
    params.push(city);
  }

  if (name) {
    where += " AND CONCAT(u.first_name,' ',u.last_name) LIKE ? ";
    params.push(`%${name}%`);
  }

  if (Number.isFinite(maxPrice)) {
    where += " AND ts.price_per_hour <= ? ";
    params.push(maxPrice);
  }

  // Query returns one row per (teacher x subject) match
  const sql = `
    SELECT
      u.user_id,
      u.email,
      u.first_name,
      u.last_name,
      tp.city,
      tp.lesson_mode,
      s.subject_name,
      ts.price_per_hour,
      ts.duration_minutes
    FROM users u
    JOIN user_roles ur ON ur.user_id = u.user_id
    JOIN roles r ON r.role_id = ur.role_id
    LEFT JOIN teacher_profile tp ON tp.user_id = u.user_id
    JOIN teacher_subjects ts ON ts.user_id = u.user_id
    JOIN subjects s ON s.subject_id = ts.subject_id
    ${where}
    ORDER BY u.user_id DESC
  `;

  db.query(sql, params, (err, rows) => {
    if (err) {
      console.error("DB error (GET /api/teachers):", err);
      return res.status(500).json({ ok: false, message: "DB error" });
    }

    const map = new Map(); // Used to group subjects under each teacher

    rows.forEach((r) => {
      const id = r.user_id;

      // First time we see this teacher -> create teacher object
      if (!map.has(id)) {
        map.set(id, {
          user_id: id,
          email: r.email,
          fullName: `${r.first_name} ${r.last_name}`.trim(),
          city: r.city,
          lesson_mode: r.lesson_mode,
          subjects: [],
        });
      }

      // Push the subject details into this teacher's subjects array
      map.get(id).subjects.push({
        subject: r.subject_name,
        price: Number(r.price_per_hour),
        duration_minutes: Number(r.duration_minutes),
      });
    });

    // Return grouped teachers list
    return res.json({ ok: true, teachers: Array.from(map.values()) });
  });
});

// =======================
// TEACHER DETAILS (GET by ID)
// =======================
app.get("/api/teachers/:id", async (req, res) => {
  // Returns full teacher details for the Book page:
  // basic info + subjects + weekly availability + exceptions

  // Disable caching so teacher details are always up to date
  res.set("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
  res.set("Pragma", "no-cache");
  res.set("Expires", "0");

  const teacherId = Number(req.params.id);
  if (!Number.isFinite(teacherId)) return res.status(400).json({ ok: false, message: "Invalid teacher id" });

  try {
    // Base teacher info + subjects (joins may return multiple rows, one per subject)
    const rows = await queryAsync(
      `
      SELECT
        u.user_id,
        u.email,
        u.first_name,
        u.last_name,
        tp.city,
        tp.lesson_mode,
        s.subject_name,
        ts.price_per_hour,
        ts.duration_minutes
      FROM users u
      JOIN user_roles ur ON ur.user_id = u.user_id
      JOIN roles r ON r.role_id = ur.role_id
      LEFT JOIN teacher_profile tp ON tp.user_id = u.user_id
      LEFT JOIN teacher_subjects ts ON ts.user_id = u.user_id
      LEFT JOIN subjects s ON s.subject_id = ts.subject_id
      WHERE r.role_name = 'teacher'
        AND u.user_id = ?
      `,
      [teacherId]
    );

    if (!rows.length) return res.status(404).json({ ok: false, message: "Teacher not found" });

    const base = rows[0]; // First row has the teacher base fields

    // Teacher object returned to the client
    const teacher = {
      user_id: base.user_id,
      email: base.email,
      fullName: `${base.first_name} ${base.last_name}`.trim(),
      city: base.city,
      lessonMode: base.lesson_mode || null,
      subjects: [],
      availabilityWeekly: {
        sun: { enabled: false, start: "", end: "" },
        mon: { enabled: false, start: "", end: "" },
        tue: { enabled: false, start: "", end: "" },
        wed: { enabled: false, start: "", end: "" },
        thu: { enabled: false, start: "", end: "" },
        fri: { enabled: false, start: "", end: "" },
        sat: { enabled: false, start: "", end: "" },
      },
      exceptions: [],
    };

    // Collect subjects from rows (each row might include a subject)
    rows.forEach((r) => {
      if (r.subject_name) {
        teacher.subjects.push({
          subject: r.subject_name,
          price: Number(r.price_per_hour),
          duration_minutes: Number(r.duration_minutes),
        });
      }
    });

    // Weekly availability: query all availability rows for this teacher
    const avRows = await queryAsync(
      `
      SELECT day_of_week, start_time, end_time
      FROM teacher_availability
      WHERE user_id = ?
      ORDER BY day_of_week, start_time
      `,
      [teacherId]
    );

    // Map DB day_of_week (0-6) -> keys used in the UI object
    const dayKeyByDow = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];

    // Helper: returns "HH:MM" from a time value
    const padTime = (t) => (t ? String(t).slice(0, 5) : "");

    // Merge multiple availability rows into a single range per day (min start, max end)
    avRows.forEach((r) => {
      const key = dayKeyByDow[r.day_of_week];
      if (!key) return;

      const start = padTime(r.start_time);
      const end = padTime(r.end_time);
      if (!start || !end) return;

      const cur = teacher.availabilityWeekly[key];

      if (!cur.enabled) {
        // First range for this day
        teacher.availabilityWeekly[key] = { enabled: true, start, end };
      } else {
        // Merge: expand range if needed
        if (start < cur.start) cur.start = start;
        if (end > cur.end) cur.end = end;
      }
    });

    // Exceptions: blocked dates or custom availability ranges
    const exRows = await queryAsync(
      `
      SELECT DATE_FORMAT(ex_date, '%Y-%m-%d') AS ex_date,
             ex_type, start_time, end_time
      FROM teacher_exceptions
      WHERE user_id = ?
      ORDER BY ex_date
      `,
      [teacherId]
    );

    // Normalize exception rows for the client
    teacher.exceptions = exRows
      .map((r) => ({
        date: r.ex_date,
        type: r.ex_type,
        start: r.start_time ? String(r.start_time).slice(0, 5) : "",
        end: r.end_time ? String(r.end_time).slice(0, 5) : "",
      }))
      .filter((x) => !!x.date);

    return res.json({ ok: true, teacher });
  } catch (err) {
    console.error("DB error (GET /api/teachers/:id):", err);
    return res.status(500).json({ ok: false, message: "DB error" });
  }
});

// DEBUG
app.get("/api/_whoami", (req, res) => {
  // Quick debug endpoint (no auth): shows server identity and port
  res.json({ ok: true, server: "my-express", port: PORT });
});

// =======================
// SERVER
// =======================
app.listen(PORT, () => {
  // Start listening for HTTP requests
  console.log(`Server running on http://localhost:${PORT}`);
});
