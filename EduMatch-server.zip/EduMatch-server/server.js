// server.js 

const express = require("express");
const cookieParser = require("cookie-parser");
const db = require("./db"); // MySQL connection (callback-based db.query)

const usersController = require("./controllers/users.controller"); // register/login/me/update/logout
const favoritesController = require("./controllers/favorites.controller"); // favorites get/add/remove

const app = express();
const PORT = 3001;


// MIDDLEWARE
app.use(express.json()); // parses JSON bodies -> req.body
app.use(express.urlencoded({ extended: true })); // parses form bodies
app.use(cookieParser()); // exposes cookies on req.cookies
app.use(express.static("public")); // serves /public assets (HTML/CSS/JS/images)

// HELPERS
function normalizeDate(val) {
  // Normalizes various date inputs to "YYYY-MM-DD" (keeps local date to avoid UTC shift)

  if (val === undefined || val === null) return null;

  // Accept JS Date object (local date, not UTC)
  if (val instanceof Date && !isNaN(val.getTime())) {
    const y = val.getFullYear();
    const m = String(val.getMonth() + 1).padStart(2, "0");
    const d = String(val.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  }

  const s0 = String(val).trim();
  if (!s0) return null;

  // Accept ISO-like strings and keep only the date part
  if (/^\d{4}-\d{2}-\d{2}/.test(s0)) return s0.slice(0, 10);

  // Accept common DD/MM/YYYY variants 
  const dmY = s0.match(/^(\d{1,2})[.\-/](\d{1,2})[.\-/](\d{4})$/);
  if (dmY) {
    const dd = String(Number(dmY[1])).padStart(2, "0");
    const mm = String(Number(dmY[2])).padStart(2, "0");
    const yy = String(dmY[3]);
    return `${yy}-${mm}-${dd}`;
  }

  return null;
}

function getAuthUserId(req) {
  // Single source of truth for auth: read user id from cookie ("authUser")
  const userId = req.cookies?.authUser;
  const n = userId ? Number(userId) : null;
  return Number.isFinite(n) ? n : null;
}

function queryAsync(sql, params = []) {
  // Wraps callback-based db.query -> Promise (so routes can use async/await cleanly)
  return new Promise((resolve, reject) => {
    db.query(sql, params, (err, rows) => {
      if (err) return reject(err);
      resolve(rows);
    });
  });
}

function cleanStr(val) {
  if (val === undefined || val === null) return null;
  const s = String(val).trim();
  return s ? s : null;
}

function normalizeTime(val) {
  if (val === undefined || val === null) return null;

  const s = String(val).trim();
  if (!s) return null;

  if (/^\d{2}:\d{2}$/.test(s)) return s;
  if (/^\d{2}:\d{2}:\d{2}$/.test(s)) return s.slice(0, 5);

  return null;
}

async function requireTeacher(req, res) {

  const userId = getAuthUserId(req);
  if (!userId) {
    res.status(401).json({ ok: false, message: "Unauthorized" });
    return null;
  }

  // Role lookup is centralized here so teacher routes stay clean
  const roleRows = await queryAsync(
    `
    SELECT r.role_name
    FROM user_roles ur
    JOIN roles r ON r.role_id = ur.role_id
    WHERE ur.user_id = ?
    LIMIT 1
    `,
    [userId]
  );

  const role = roleRows.length ? String(roleRows[0].role_name) : "student"; // fallback for safety
  if (role !== "teacher") {
    res.status(403).json({ ok: false, message: "Teachers only" });
    return null;
  }

  return userId;
}

// HEALTH / DEBUG
app.get("/api/health", (req, res) => {
  res.json({ ok: true, message: "EduMatch API is running" });
});

app.post("/api/echo", (req, res) => {
  res.json({ receivedBody: req.body });
});

// ✅ CITIES API
app.get("/api/cities", async (req, res) => {
  // Used by UI dropdown; no-cache so new cities appear immediately after DB updates
  res.set("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
  res.set("Pragma", "no-cache");
  res.set("Expires", "0");

  try {
    const rows = await queryAsync(
      `
      SELECT DISTINCT city
      FROM teacher_profile
      WHERE city IS NOT NULL
        AND city <> ''
      ORDER BY city
      `
    );

    const cities = rows.map((r) => r.city);
    return res.json({ ok: true, cities });
  } catch (err) {
    console.error("DB error (GET /api/cities):", err);
    return res.status(500).json({ ok: false, message: "DB error" });
  }
});

// SUBJECTS RESOLVE (GET)
app.get("/api/subjects/resolve", async (req, res) => {
  // Utility for client: map subject name -> subject_id (avoids duplicating logic on FE)

  try {
    const name = cleanStr(req.query?.name);
    if (!name) return res.status(400).json({ ok: false, message: "Missing name" });

    const rows = await queryAsync(
      "SELECT subject_id FROM subjects WHERE subject_name = ? LIMIT 1",
      [name]
    );

    if (!rows.length) return res.status(404).json({ ok: false, message: "Subject not found" });
    return res.json({ ok: true, subject_id: rows[0].subject_id });
  } catch (err) {
    console.error("DB error (GET /api/subjects/resolve):", err);
    return res.status(500).json({ ok: false, message: "DB error" });
  }
});

// REGISTER / LOGIN / AUTH
app.post("/api/register", usersController.register);
app.post("/api/login", usersController.login);

app.get("/api/me", usersController.me);
app.put("/api/me", usersController.updateMe);
app.post("/api/logout", usersController.logout);

// FAVORITES API
app.get("/api/favorites", favoritesController.getFavorites);
app.post("/api/favorites/:teacherId", favoritesController.addFavorite);
app.delete("/api/favorites/:teacherId", favoritesController.removeFavorite);

// BOOKINGS API
app.post("/api/bookings", async (req, res) => {

  try {
    const student_user_id = getAuthUserId(req);
    if (!student_user_id) return res.status(401).json({ ok: false, message: "התחבר על מנת להזמין שיעור" });

    // Client might send teacher_user_id OR teacher_id (support both)
    const teacher_user_id = Number(req.body?.teacher_user_id ?? req.body?.teacher_id);
    const subject_id = Number(req.body?.subject_id);
    const lesson_date = normalizeDate(req.body?.lesson_date ?? req.body?.date);
    const start_time = normalizeTime(req.body?.start_time);

    // Fail fast: prevents inserting invalid rows
    if (!Number.isFinite(teacher_user_id)) return res.status(400).json({ ok: false, message: "Invalid teacher_user_id" });
    if (!Number.isFinite(subject_id)) return res.status(400).json({ ok: false, message: "Invalid subject_id" });
    if (!lesson_date) return res.status(400).json({ ok: false, message: "Invalid lesson_date" });
    if (!start_time) return res.status(400).json({ ok: false, message: "Invalid start_time" });

    // Ensure teacher teaches this subject (+ read price & duration to store)
    const tsRows = await queryAsync(
      `SELECT price_per_hour, duration_minutes
       FROM teacher_subjects
       WHERE user_id = ? AND subject_id = ?
       LIMIT 1`,
      [teacher_user_id, subject_id]
    );
    if (!tsRows.length) return res.status(400).json({ ok: false, message: "Teacher does not teach this subject" });

    // Copy lesson_mode from profile so booking keeps a stable snapshot
    const tpRows = await queryAsync(
      `SELECT lesson_mode FROM teacher_profile WHERE user_id = ? LIMIT 1`,
      [teacher_user_id]
    );
    const lesson_mode = tpRows.length ? tpRows[0].lesson_mode : "both";

    // Only block if a CONFIRMED booking exists (pending/cancelled shouldn't lock slot)
    const exists = await queryAsync(
      `SELECT booking_id FROM bookings
       WHERE teacher_user_id = ? AND lesson_date = ? AND start_time = ? AND status = 'confirmed'
       LIMIT 1`,
      [teacher_user_id, lesson_date, start_time]
    );
    if (exists.length) return res.status(409).json({ ok: false, message: "השעה הזו כבר תפוסה" });

    const { price_per_hour, duration_minutes } = tsRows[0];

    const ins = await queryAsync(
      `INSERT INTO bookings
       (student_user_id, teacher_user_id, subject_id, lesson_date, start_time,
        duration_minutes, price_per_hour, lesson_mode)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        student_user_id,
        teacher_user_id,
        subject_id,
        lesson_date,
        start_time,
        Number(duration_minutes),
        Number(price_per_hour),
        lesson_mode,
      ]
    );

    return res.json({ ok: true, bookingId: ins.insertId });
  } catch (err) {
    console.error("DB error (POST /api/bookings):", err);
    return res.status(500).json({ ok: false, message: "DB error" });
  }
});

// Student: future bookings
app.get("/api/bookings/future", async (req, res) => {
  // Future lessons view for student (excludes cancelled)

  try {
    const student_user_id = getAuthUserId(req);
    if (!student_user_id) return res.status(401).json({ ok: false, message: "התחבר על מנת לצפות בשיעורים" });

    const rows = await queryAsync(
      `SELECT
         b.booking_id,
         DATE_FORMAT(b.lesson_date, '%Y-%m-%d') AS lesson_date,
         TIME_FORMAT(b.start_time, '%H:%i') AS start_time,
         b.duration_minutes,
         b.price_per_hour,
         b.lesson_mode,
         b.status,
         s.subject_name,
         u.user_id AS teacher_user_id,
         u.first_name AS teacher_first_name,
         u.last_name  AS teacher_last_name
       FROM bookings b
       JOIN subjects s ON s.subject_id = b.subject_id
       JOIN users u ON u.user_id = b.teacher_user_id
       WHERE b.student_user_id = ?
         AND b.status <> 'cancelled'
         AND TIMESTAMP(b.lesson_date, b.start_time) >= NOW()
       ORDER BY b.lesson_date ASC, b.start_time ASC`,
      [student_user_id]
    );

    return res.json({ ok: true, lessons: rows });
  } catch (err) {
    console.error("DB error (GET /api/bookings/future):", err);
    return res.status(500).json({ ok: false, message: "DB error" });
  }
});

// Student: past bookings (history)
app.get("/api/bookings/past", async (req, res) => {

  try {
    const student_user_id = getAuthUserId(req);
    if (!student_user_id) return res.status(401).json({ ok: false, message: "התחבר על מנת לצפות בשיעורים" });

    const rows = await queryAsync(
      `SELECT
         b.booking_id,
         DATE_FORMAT(b.lesson_date, '%Y-%m-%d') AS lesson_date,
         TIME_FORMAT(b.start_time, '%H:%i') AS start_time,
         b.duration_minutes,
         b.price_per_hour,
         b.lesson_mode,
         b.status,
         s.subject_name,
         u.user_id AS teacher_user_id,
         u.first_name AS teacher_first_name,
         u.last_name  AS teacher_last_name
       FROM bookings b
       JOIN subjects s ON s.subject_id = b.subject_id
       JOIN users u ON u.user_id = b.teacher_user_id
       WHERE b.student_user_id = ?
         AND b.status = 'confirmed'
         AND TIMESTAMP(b.lesson_date, b.start_time) < NOW()
       ORDER BY b.lesson_date DESC, b.start_time DESC`,
      [student_user_id]
    );

    return res.json({ ok: true, lessons: rows });
  } catch (err) {
    console.error("DB error (GET /api/bookings/past):", err);
    return res.status(500).json({ ok: false, message: "DB error" });
  }
});

// Teacher: future bookings
app.get("/api/bookings/teacher/future", async (req, res) => {

  try {
    const teacher_user_id = await requireTeacher(req, res);
    if (!teacher_user_id) return;

    const rows = await queryAsync(
      `
      SELECT
        b.booking_id,
        DATE_FORMAT(b.lesson_date, '%Y-%m-%d') AS lesson_date,
        TIME_FORMAT(b.start_time, '%H:%i') AS start_time,
        b.duration_minutes,
        b.price_per_hour,
        b.lesson_mode,
        b.status,
        s.subject_name,

        stu.user_id AS student_user_id,
        stu.first_name AS student_first_name,
        stu.last_name  AS student_last_name,
        stu.email      AS student_email
      FROM bookings b
      JOIN subjects s ON s.subject_id = b.subject_id
      JOIN users stu ON stu.user_id = b.student_user_id
      WHERE b.teacher_user_id = ?
        AND b.status <> 'cancelled'
        AND TIMESTAMP(b.lesson_date, b.start_time) >= NOW()
      ORDER BY b.lesson_date ASC, b.start_time ASC
      `,
      [teacher_user_id]
    );

    return res.json({ ok: true, lessons: rows });
  } catch (err) {
    console.error("DB error (GET /api/bookings/teacher/future):", err);
    return res.status(500).json({ ok: false, message: "DB error" });
  }
});

// Teacher: past bookings (history) 
app.get("/api/bookings/teacher/past", async (req, res) => {
  try {
    const teacher_user_id = await requireTeacher(req, res);
    if (!teacher_user_id) return;

    const rows = await queryAsync(
      `
      SELECT
        b.booking_id,
        DATE_FORMAT(b.lesson_date, '%Y-%m-%d') AS lesson_date,
        TIME_FORMAT(b.start_time, '%H:%i') AS start_time,
        b.duration_minutes,
        b.price_per_hour,
        b.lesson_mode,
        b.status,
        s.subject_name,

        stu.user_id AS student_user_id,
        stu.first_name AS student_first_name,
        stu.last_name  AS student_last_name,
        stu.email      AS student_email
      FROM bookings b
      JOIN subjects s ON s.subject_id = b.subject_id
      JOIN users stu ON stu.user_id = b.student_user_id
      WHERE b.teacher_user_id = ?
        AND b.status = 'confirmed'
        AND TIMESTAMP(b.lesson_date, b.start_time) < NOW()
      ORDER BY b.lesson_date DESC, b.start_time DESC
      `,
      [teacher_user_id]
    );

    return res.json({ ok: true, lessons: rows });
  } catch (err) {
    console.error("DB error (GET /api/bookings/teacher/past):", err);
    return res.status(500).json({ ok: false, message: "DB error" });
  }
});

// Cancel booking (student only)
app.put("/api/bookings/:id/cancel", async (req, res) => {

  try {
    const student_user_id = getAuthUserId(req);
    if (!student_user_id) return res.status(401).json({ ok: false, message: "התחבר על מנת לבטל שיעור" });

    const bookingId = Number(req.params.id);
    if (!Number.isFinite(bookingId)) return res.status(400).json({ ok: false, message: "Invalid booking id" });

    const result = await queryAsync(
      `
      UPDATE bookings
      SET status = 'cancelled'
      WHERE booking_id = ?
        AND student_user_id = ?
        AND status = 'confirmed'
        AND TIMESTAMP(lesson_date, start_time) > NOW()
      `,
      [bookingId, student_user_id]
    );

    if (!result.affectedRows) {
      return res.status(404).json({
        ok: false,
        message: "לא נמצאה הזמנה לביטול (אולי כבר בוטלה / לא שלך / לא עתידית).",
      });
    }

    return res.json({ ok: true });
  } catch (err) {
    console.error("DB error (PUT /api/bookings/:id/cancel):", err);
    return res.status(500).json({ ok: false, message: "DB error" });
  }
});

// TEACHERS SEARCH (GET)
app.get("/api/teachers", (req, res) => {

  const subject = (req.query.subject || "").trim(); 
  const city = (req.query.city || "").trim();
  const name = (req.query.name || "").trim();
  const maxPrice = req.query.maxPrice ? Number(req.query.maxPrice) : null;

  if (!subject || subject.length < 2) return res.json({ ok: true, teachers: [] });

  const params = [];
  let where = `
    WHERE r.role_name = 'teacher'
      AND s.subject_name LIKE ?
  `;
  params.push(`%${subject}%`);

  if (city) {
    where += " AND tp.city = ? ";
    params.push(city);
  }

  if (name) {
    // Full name search (first + last)
    where += " AND CONCAT(u.first_name,' ',u.last_name) LIKE ? ";
    params.push(`%${name}%`);
  }

  if (Number.isFinite(maxPrice)) {
    where += " AND ts.price_per_hour <= ? ";
    params.push(maxPrice);
  }

  const sql = `
    SELECT
      u.user_id,
      u.email,
      u.first_name,
      u.last_name,
      tp.city,
      tp.lesson_mode,
      s.subject_name,
      ts.price_per_hour,
      ts.duration_minutes
    FROM users u
    JOIN user_roles ur ON ur.user_id = u.user_id
    JOIN roles r ON r.role_id = ur.role_id
    LEFT JOIN teacher_profile tp ON tp.user_id = u.user_id
    JOIN teacher_subjects ts ON ts.user_id = u.user_id
    JOIN subjects s ON s.subject_id = ts.subject_id
    ${where}
    ORDER BY u.user_id DESC
  `;

  db.query(sql, params, (err, rows) => {
    if (err) {
      console.error("DB error (GET /api/teachers):", err);
      return res.status(500).json({ ok: false, message: "DB error" });
    }

    // Group rows (teacher x subject) 
    const map = new Map();

    rows.forEach((r) => {
      const id = r.user_id;

      if (!map.has(id)) {
        map.set(id, {
          user_id: id,
          email: r.email,
          fullName: `${r.first_name} ${r.last_name}`.trim(),
          city: r.city,
          lesson_mode: r.lesson_mode,
          subjects: [],
        });
      }

      map.get(id).subjects.push({
        subject: r.subject_name,
        price: Number(r.price_per_hour),
        duration_minutes: Number(r.duration_minutes),
      });
    });

    return res.json({ ok: true, teachers: Array.from(map.values()) });
  });
});

// TEACHER DETAILS (GET by ID)
app.get("/api/teachers/:id", async (req, res) => {

  res.set("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
  res.set("Pragma", "no-cache");
  res.set("Expires", "0");

  const teacherId = Number(req.params.id);
  if (!Number.isFinite(teacherId)) return res.status(400).json({ ok: false, message: "Invalid teacher id" });

  try {
    const rows = await queryAsync(
      `
      SELECT
        u.user_id,
        u.email,
        u.first_name,
        u.last_name,
        tp.city,
        tp.lesson_mode,
        s.subject_name,
        ts.price_per_hour,
        ts.duration_minutes
      FROM users u
      JOIN user_roles ur ON ur.user_id = u.user_id
      JOIN roles r ON r.role_id = ur.role_id
      LEFT JOIN teacher_profile tp ON tp.user_id = u.user_id
      LEFT JOIN teacher_subjects ts ON ts.user_id = u.user_id
      LEFT JOIN subjects s ON s.subject_id = ts.subject_id
      WHERE r.role_name = 'teacher'
        AND u.user_id = ?
      `,
      [teacherId]
    );

    if (!rows.length) return res.status(404).json({ ok: false, message: "Teacher not found" });

    const base = rows[0];

    // Shape matches what the frontend expects (Book/Profile pages)
    const teacher = {
      user_id: base.user_id,
      email: base.email,
      fullName: `${base.first_name} ${base.last_name}`.trim(),
      city: base.city,
      lessonMode: base.lesson_mode || null,
      subjects: [],
      availabilityWeekly: {
        sun: { enabled: false, start: "", end: "" },
        mon: { enabled: false, start: "", end: "" },
        tue: { enabled: false, start: "", end: "" },
        wed: { enabled: false, start: "", end: "" },
        thu: { enabled: false, start: "", end: "" },
        fri: { enabled: false, start: "", end: "" },
        sat: { enabled: false, start: "", end: "" },
      },
      exceptions: [],
    };

    rows.forEach((r) => {
      if (r.subject_name) {
        teacher.subjects.push({
          subject: r.subject_name,
          price: Number(r.price_per_hour),
          duration_minutes: Number(r.duration_minutes),
        });
      }
    });

    const avRows = await queryAsync(
      `
      SELECT day_of_week, start_time, end_time
      FROM teacher_availability
      WHERE user_id = ?
      ORDER BY day_of_week, start_time
      `,
      [teacherId]
    );

    // day_of_week in DB is 0-6; map to keys used by client
    const dayKeyByDow = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];

    const padTime = (t) => (t ? String(t).slice(0, 5) : "");

    avRows.forEach((r) => {
      const key = dayKeyByDow[r.day_of_week];
      if (!key) return;

      const start = padTime(r.start_time);
      const end = padTime(r.end_time);
      if (!start || !end) return;

      const cur = teacher.availabilityWeekly[key];

      if (!cur.enabled) {
        teacher.availabilityWeekly[key] = { enabled: true, start, end };
      } else {
        if (start < cur.start) cur.start = start;
        if (end > cur.end) cur.end = end;
      }
    });

    const exRows = await queryAsync(
      `
      SELECT DATE_FORMAT(ex_date, '%Y-%m-%d') AS ex_date,
             ex_type, start_time, end_time
      FROM teacher_exceptions
      WHERE user_id = ?
      ORDER BY ex_date
      `,
      [teacherId]
    );

    teacher.exceptions = exRows
      .map((r) => ({
        date: r.ex_date,
        type: r.ex_type,
        start: r.start_time ? String(r.start_time).slice(0, 5) : "",
        end: r.end_time ? String(r.end_time).slice(0, 5) : "",
      }))
      .filter((x) => !!x.date);

    return res.json({ ok: true, teacher });
  } catch (err) {
    console.error("DB error (GET /api/teachers/:id):", err);
    return res.status(500).json({ ok: false, message: "DB error" });
  }
});

// DEBUG
app.get("/api/_whoami", (req, res) => {
  res.json({ ok: true, server: "my-express", port: PORT });
});

// SERVER
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
