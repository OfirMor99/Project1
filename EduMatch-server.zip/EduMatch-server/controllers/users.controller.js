// controllers/users.controller.js
const db = require("../db");

// =======================
// Cookies
// =======================
function setAuthCookie(res, userId) {
  res.setHeader("Cache-Control", "no-store");

  // Main auth cookie (httpOnly)
  res.cookie("authUser", String(userId), {
    httpOnly: true,
    sameSite: "lax",
    secure: false, // localhost
    maxAge: 7 * 24 * 60 * 60 * 1000,
    path: "/",
  });

  // Debug cookie (visible in DevTools)
  res.cookie("authUser_debug", String(userId), {
    httpOnly: false,
    sameSite: "lax",
    secure: false,
    maxAge: 7 * 24 * 60 * 60 * 1000,
    path: "/",
  });
}

function clearAuthCookie(res) {
  res.setHeader("Cache-Control", "no-store");

  // Clears auth cookies
  res.clearCookie("authUser", {
    httpOnly: true,
    sameSite: "lax",
    secure: false,
    path: "/",
  });

  res.clearCookie("authUser_debug", {
    httpOnly: false,
    sameSite: "lax",
    secure: false,
    path: "/",
  });
}

// =======================
// Helpers
// =======================
function cleanStr(val) {
  // Trim strings and normalize empty -> null
  if (val === undefined || val === null) return null;
  const s = String(val).trim();
  return s ? s : null;
}

function safeNum(val) {
  // Safe number parsing
  if (val === undefined || val === null || val === "") return null;
  const n = Number(val);
  return Number.isFinite(n) ? n : null;
}

function isEmailValid(value) {
  // Basic email format check
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test((value || "").trim());
}

function isIsraeliPhoneValid(value) {
  // Israeli mobile format: 05XXXXXXXX
  return /^05\d{8}$/.test((value || "").trim());
}

function normalizeRole(val) {
  // Allow only teacher/student
  const r = cleanStr(val);
  return r === "teacher" || r === "student" ? r : "student";
}

function normalizeLessonMode(val) {
  // Allow only online/frontal/both
  const m = cleanStr(val);
  return m === "online" || m === "frontal" || m === "both" ? m : "both";
}

function normalizeTime(val) {
  // Normalize time to HH:mm
  if (val === undefined || val === null) return null;
  const s = String(val).trim();
  if (!s) return null;
  if (/^\d{2}:\d{2}$/.test(s)) return s;
  if (/^\d{2}:\d{2}:\d{2}$/.test(s)) return s.slice(0, 5);
  return null;
}

function normalizeISODate(val) {
  // Normalize date to YYYY-MM-DD (supports dd/mm/yyyy)
  if (val === undefined || val === null) return null;
  const s = String(val).trim();
  if (!s) return null;
  if (/^\d{4}-\d{2}-\d{2}/.test(s)) return s.slice(0, 10);

  const m = s.match(/^(\d{1,2})[.\-/](\d{1,2})[.\-/](\d{4})$/);
  if (m) {
    const dd = String(Number(m[1])).padStart(2, "0");
    const mm = String(Number(m[2])).padStart(2, "0");
    const yy = String(m[3]);
    return `${yy}-${mm}-${dd}`;
  }
  return null;
}

function queryAsync(sql, params = []) {
  // Promise wrapper for db.query
  return new Promise((resolve, reject) => {
    db.query(sql, params, (err, rows) => {
      if (err) return reject(err);
      resolve(rows);
    });
  });
}

// Cache columns per table
const _tableColsCache = new Map();
async function getTableColumns(tableName) {
  // Avoid repeating SHOW COLUMNS calls
  if (_tableColsCache.has(tableName)) return _tableColsCache.get(tableName);
  const rows = await queryAsync(`SHOW COLUMNS FROM \`${tableName}\``);
  const cols = new Set(rows.map((r) => String(r.Field)));
  _tableColsCache.set(tableName, cols);
  return cols;
}

function getAuthUserId(req) {
  // Read auth user id from cookie
  const n = req.cookies?.authUser ? Number(req.cookies.authUser) : null;
  return Number.isFinite(n) ? n : null;
}

// =======================
// GET /api/me
// =======================
async function me(req, res) {
  try {
    const userId = getAuthUserId(req);
    if (!userId) return res.status(401).json({ ok: false, message: "Unauthorized" });

    // Base user row
    const usersRows = await queryAsync(
      `SELECT user_id, email, phone, first_name, last_name
       FROM users
       WHERE user_id = ?
       LIMIT 1`,
      [userId]
    );

    if (!usersRows.length) {
      clearAuthCookie(res);
      return res.status(401).json({ ok: false, message: "Unauthorized" });
    }

    const u = usersRows[0];

    // Role from DB
    const roleRows = await queryAsync(
      `
      SELECT r.role_name
      FROM user_roles ur
      JOIN roles r ON r.role_id = ur.role_id
      WHERE ur.user_id = ?
      LIMIT 1
      `,
      [userId]
    );

    const role = roleRows.length ? String(roleRows[0].role_name) : "student";
    const normalizedRole = role === "teacher" ? "teacher" : "student";

    // Response object
    const user = {
      user_id: u.user_id,
      email: u.email,
      phone: u.phone,
      first_name: u.first_name,
      last_name: u.last_name,
      role: normalizedRole,
      subjects: [],
      availability: [],
      exceptions: [],
      city: null,
      years_experience: null,
      lesson_mode: null,
    };

    // Teacher extras
    if (normalizedRole === "teacher") {
      const teacherRows = await queryAsync(
        `SELECT user_id, city, years_experience, lesson_mode
         FROM teacher_profile
         WHERE user_id = ?
         LIMIT 1`,
        [userId]
      );

      user.city = teacherRows.length ? teacherRows[0].city : null;
      user.years_experience = teacherRows.length ? teacherRows[0].years_experience : null;
      user.lesson_mode = teacherRows.length ? teacherRows[0].lesson_mode : null;

      const subjRows = await queryAsync(
        `SELECT s.subject_name, ts.price_per_hour, ts.duration_minutes
         FROM teacher_subjects ts
         JOIN subjects s ON s.subject_id = ts.subject_id
         WHERE ts.user_id = ?
         ORDER BY s.subject_name`,
        [userId]
      );

      user.subjects = subjRows.map((r) => ({
        subject: r.subject_name,
        subject_name: r.subject_name,
        price: Number(r.price_per_hour),
        price_per_hour: Number(r.price_per_hour),
        duration_minutes: Number(r.duration_minutes),
      }));

      const avRows = await queryAsync(
        `SELECT day_of_week, start_time, end_time
         FROM teacher_availability
         WHERE user_id = ?
         ORDER BY day_of_week, start_time`,
        [userId]
      );

      user.availability = avRows.map((r) => ({
        day_of_week: Number(r.day_of_week),
        start_time: r.start_time ? String(r.start_time).slice(0, 5) : null,
        end_time: r.end_time ? String(r.end_time).slice(0, 5) : null,
      }));

      const exRows = await queryAsync(
        `
        SELECT DATE_FORMAT(ex_date, '%Y-%m-%d') AS ex_date,
               ex_type, start_time, end_time
        FROM teacher_exceptions
        WHERE user_id = ?
        ORDER BY ex_date
        `,
        [userId]
      );

      user.exceptions = exRows.map((r) => ({
        date: r.ex_date,
        type: r.ex_type,
        start_time: r.start_time ? String(r.start_time).slice(0, 5) : null,
        end_time: r.end_time ? String(r.end_time).slice(0, 5) : null,
      }));
    }

    return res.json({ ok: true, user });
  } catch (err) {
    console.error("DB error (me):", err);
    return res.status(500).json({ ok: false, message: "DB error" });
  }
}

// =======================
// PUT /api/me
// =======================
async function updateMe(req, res) {
  try {
    const userId = getAuthUserId(req);
    if (!userId) return res.status(401).json({ ok: false, message: "Unauthorized" });

    const first_name = cleanStr(req.body?.first_name);
    const last_name = cleanStr(req.body?.last_name);
    const phone = cleanStr(req.body?.phone);
    const city = cleanStr(req.body?.city);

    if (!first_name || !last_name) {
      return res.status(400).json({ ok: false, message: "Missing first_name/last_name" });
    }

    if (!phone || !isIsraeliPhoneValid(phone)) {
      return res.status(400).json({ ok: false, message: "Invalid phone" });
    }

    // Role from DB (source of truth)
    const roleRows = await queryAsync(
      `
      SELECT r.role_name
      FROM user_roles ur
      JOIN roles r ON r.role_id = ur.role_id
      WHERE ur.user_id = ?
      LIMIT 1
      `,
      [userId]
    );
    const roleName = roleRows.length ? String(roleRows[0].role_name) : "student";
    const isTeacher = roleName === "teacher";

    // Transaction for consistent updates
    await queryAsync("START TRANSACTION");

    try {
      // Update base user fields
      await queryAsync(
        `
        UPDATE users
        SET first_name = ?, last_name = ?, phone = ?
        WHERE user_id = ?
        LIMIT 1
        `,
        [first_name, last_name, phone, userId]
      );

      // Teacher updates (profile + replace child tables)
      if (isTeacher) {
        const years_experience = safeNum(req.body?.years_experience);
        const lesson_mode = normalizeLessonMode(req.body?.lesson_mode) || "both";

        if (years_experience === null || years_experience < 0) {
          throw new Error("Invalid years_experience");
        }

        // Upsert teacher_profile
        await queryAsync(
          `
          INSERT INTO teacher_profile (user_id, city, years_experience, lesson_mode)
          VALUES (?, ?, ?, ?)
          ON DUPLICATE KEY UPDATE
            city = VALUES(city),
            years_experience = VALUES(years_experience),
            lesson_mode = VALUES(lesson_mode)
          `,
          [userId, city, years_experience, lesson_mode]
        );

        // Subjects: validate -> delete -> insert
        const subjects = Array.isArray(req.body?.subjects) ? req.body.subjects : [];
        if (!subjects.length) throw new Error("At least one subject is required");

        for (let i = 0; i < subjects.length; i++) {
          const s = subjects[i] || {};
          const subject_name = cleanStr(s.subject_name);
          const price_per_hour = safeNum(s.price_per_hour);
          const duration_minutes = safeNum(s.duration_minutes);

          if (!subject_name) throw new Error(`Missing subject_name row ${i + 1}`);
          if (!price_per_hour || price_per_hour <= 0) throw new Error(`Invalid price row ${i + 1}`);
          if (!duration_minutes || duration_minutes <= 0) throw new Error(`Invalid duration row ${i + 1}`);
        }

        await queryAsync(`DELETE FROM teacher_subjects WHERE user_id = ?`, [userId]);

        for (const s of subjects) {
          const subject_name = cleanStr(s.subject_name);
          const price_per_hour = Number(s.price_per_hour);
          const duration_minutes = Number(s.duration_minutes);

          // Find subject_id or create new subject
          const found = await queryAsync(
            "SELECT subject_id FROM subjects WHERE subject_name = ? LIMIT 1",
            [subject_name]
          );

          let subjectId;
          if (found.length) subjectId = found[0].subject_id;
          else {
            const ins = await queryAsync("INSERT INTO subjects (subject_name) VALUES (?)", [subject_name]);
            subjectId = ins.insertId;
          }

          await queryAsync(
            `
            INSERT INTO teacher_subjects (user_id, subject_id, price_per_hour, duration_minutes)
            VALUES (?, ?, ?, ?)
            `,
            [userId, subjectId, price_per_hour, duration_minutes]
          );
        }

        // Availability: delete -> insert
        const availability = Array.isArray(req.body?.availability) ? req.body.availability : [];
        await queryAsync(`DELETE FROM teacher_availability WHERE user_id = ?`, [userId]);

        for (const a of availability) {
          const day_of_week = Number(a.day_of_week);
          const start_time = normalizeTime(a.start_time);
          const end_time = normalizeTime(a.end_time);

          if (!Number.isFinite(day_of_week) || day_of_week < 0 || day_of_week > 6) {
            throw new Error("Invalid availability day_of_week");
          }
          if (!start_time || !end_time || !(start_time < end_time)) {
            throw new Error("Invalid availability time range");
          }

          await queryAsync(
            `
            INSERT INTO teacher_availability (user_id, day_of_week, start_time, end_time)
            VALUES (?, ?, ?, ?)
            `,
            [userId, day_of_week, start_time, end_time]
          );
        }

        // Exceptions: delete -> insert
        const exceptions = Array.isArray(req.body?.exceptions) ? req.body.exceptions : [];
        await queryAsync(`DELETE FROM teacher_exceptions WHERE user_id = ?`, [userId]);

        for (const ex of exceptions) {
          const date = normalizeISODate(ex.date);
          const type = ex?.type === "custom" ? "custom" : "off";
          const start_time = type === "custom" ? normalizeTime(ex.start_time) : null;
          const end_time = type === "custom" ? normalizeTime(ex.end_time) : null;

          if (!date) throw new Error("Invalid exception date");
          if (type === "custom") {
            if (!start_time || !end_time || !(start_time < end_time)) {
              throw new Error("Invalid exception time range");
            }
          }

          await queryAsync(
            `
            INSERT INTO teacher_exceptions (user_id, ex_date, ex_type, start_time, end_time)
            VALUES (?, ?, ?, ?, ?)
            `,
            [userId, date, type, start_time, end_time]
          );
        }
      }

      await queryAsync("COMMIT");
      return res.json({ ok: true });
    } catch (innerErr) {
      await queryAsync("ROLLBACK");
      const msg = innerErr?.sqlMessage || innerErr?.message || "Update failed";
      return res.status(400).json({ ok: false, message: msg });
    }
  } catch (err) {
    console.error("DB error (updateMe):", err);
    return res.status(500).json({ ok: false, message: "DB error" });
  }
}

// =======================
// POST /api/logout
// =======================
async function logout(req, res) {
  clearAuthCookie(res);
  return res.json({ ok: true });
}

// =======================
// POST /api/login
// =======================
async function login(req, res) {
  try {
    const email = cleanStr(req.body?.email);
    const password = cleanStr(req.body?.password);

    if (!email || !password) {
      return res.status(400).json({ ok: false, message: "Missing email or password" });
    }

    // Check credentials
    const rows = await queryAsync(
      "SELECT user_id, password FROM users WHERE email = ? LIMIT 1",
      [email]
    );

    if (!rows.length) {
      return res.status(401).json({ ok: false, message: "Invalid email or password" });
    }

    const user = rows[0];
    if (String(user.password) !== String(password)) {
      return res.status(401).json({ ok: false, message: "Invalid email or password" });
    }

    setAuthCookie(res, user.user_id);
    return res.status(200).json({ ok: true, user_id: user.user_id });
  } catch (err) {
    console.error("DB error (login):", err);
    return res.status(500).json({ ok: false, message: "DB error" });
  }
}

// =======================
// REGISTER
// =======================
async function register(req, res) {
  let responded = false;

  // Prevent double responses in async flows
  const safeSend = (fn) => {
    if (responded) return;
    responded = true;
    return fn();
  };

  try {
    const body = req.body || {};

    const first_name = cleanStr(body.first_name);
    const last_name = cleanStr(body.last_name);
    const email = cleanStr(body.email);
    const phone = cleanStr(body.phone);
    const password = cleanStr(body.password);

    const role = normalizeRole(body.role);
    const lesson_mode = normalizeLessonMode(body.lesson_mode);

    // Basic validations
    if (!first_name || !last_name) {
      return safeSend(() => res.status(400).json({ ok: false, message: "Missing name" }));
    }

    if (!email || !isEmailValid(email)) {
      return safeSend(() => res.status(400).json({ ok: false, message: "Invalid email" }));
    }

    if (phone && !isIsraeliPhoneValid(phone)) {
      return safeSend(() => res.status(400).json({ ok: false, message: "Invalid phone" }));
    }

    if (!password || password.length < 6) {
      return safeSend(() => res.status(400).json({ ok: false, message: "Password too short" }));
    }

    // Teacher-only fields
    const teacher_city = cleanStr(body["teacher-city"]);
    const teacher_experience = safeNum(body["teacher-experience"]);
    const subjects = Array.isArray(body.subjects) ? body.subjects : [];

    if (role === "teacher") {
      if (!teacher_city) {
        return safeSend(() => res.status(400).json({ ok: false, message: "Missing city" }));
      }

      if (teacher_experience === null || teacher_experience < 0) {
        return safeSend(() => res.status(400).json({ ok: false, message: "Invalid experience" }));
      }

      if (!subjects.length) {
        return safeSend(() =>
          res.status(400).json({ ok: false, message: "At least one subject is required" })
        );
      }

      for (let i = 0; i < subjects.length; i++) {
        const s = subjects[i] || {};
        const subject_name = cleanStr(s.subject_name);
        const price_per_hour = safeNum(s.price_per_hour);
        const duration_minutes = safeNum(s.duration_minutes);

        if (!subject_name) {
          return safeSend(() =>
            res.status(400).json({ ok: false, message: `Missing subject name in row ${i + 1}` })
          );
        }
        if (!price_per_hour || price_per_hour <= 0) {
          return safeSend(() =>
            res.status(400).json({ ok: false, message: `Invalid price in row ${i + 1}` })
          );
        }
        if (!duration_minutes || duration_minutes <= 0) {
          return safeSend(() => res.status(400).json({ ok: false, message: "Missing lesson duration" }));
        }
      }
    }

    // Prevent duplicate email
    const existing = await queryAsync("SELECT user_id FROM users WHERE email = ? LIMIT 1", [email]);
    if (existing.length) {
      return safeSend(() => res.status(409).json({ ok: false, message: "Email already exists" }));
    }

    // Transaction for multi-table insert
    await queryAsync("START TRANSACTION");

    try {
      const userResult = await queryAsync(
        `
        INSERT INTO users (email, phone, password, created_at, first_name, last_name)
        VALUES (?, ?, ?, NOW(), ?, ?)
        `,
        [email, phone, password, first_name, last_name]
      );

      const userId = userResult.insertId;

      // Assign role
      const roleRow = await queryAsync(
        "SELECT role_id FROM roles WHERE role_name = ? LIMIT 1",
        [role]
      );
      if (!roleRow.length) throw new Error(`Role not found in roles table: ${role}`);

      await queryAsync(
        `
        INSERT INTO user_roles (user_id, role_id)
        VALUES (?, ?)
        ON DUPLICATE KEY UPDATE role_id = VALUES(role_id)
        `,
        [userId, roleRow[0].role_id]
      );

      // Teacher extra inserts
      if (role === "teacher") {
        await queryAsync(
          `
          INSERT INTO teacher_profile (user_id, city, years_experience, lesson_mode)
          VALUES (?, ?, ?, ?)
          `,
          [userId, teacher_city, teacher_experience, lesson_mode]
        );

        // Optional table sanity checks
        await getTableColumns("teacher_subjects");
        await getTableColumns("subjects");

        for (const s of subjects) {
          const subject_name = cleanStr(s.subject_name);
          const price_per_hour = safeNum(s.price_per_hour);
          const duration_minutes = safeNum(s.duration_minutes);

          const found = await queryAsync(
            "SELECT subject_id FROM subjects WHERE subject_name = ? LIMIT 1",
            [subject_name]
          );

          let subjectId;
          if (found.length) subjectId = found[0].subject_id;
          else {
            const ins = await queryAsync("INSERT INTO subjects (subject_name) VALUES (?)", [subject_name]);
            subjectId = ins.insertId;
          }

          await queryAsync(
            `
            INSERT INTO teacher_subjects (user_id, subject_id, price_per_hour, duration_minutes)
            VALUES (?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
              price_per_hour = VALUES(price_per_hour),
              duration_minutes = VALUES(duration_minutes)
            `,
            [userId, subjectId, price_per_hour, duration_minutes]
          );
        }
      }

      await queryAsync("COMMIT");
      setAuthCookie(res, userId);

      return safeSend(() => res.status(201).json({ ok: true, user_id: userId }));
    } catch (innerErr) {
      await queryAsync("ROLLBACK");
      const msg = innerErr?.sqlMessage || innerErr?.message || "Register failed";
      return safeSend(() => res.status(500).json({ ok: false, message: msg }));
    }
  } catch (err) {
    console.error("DB error (register):", err);
    return safeSend(() => res.status(500).json({ ok: false, message: err?.message || "DB error" }));
  }
}

module.exports = { register, login, me, updateMe, logout };
