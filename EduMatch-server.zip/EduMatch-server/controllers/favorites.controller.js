// controllers/favorites.controller.js
// Handles student's favorite teachers logic

const db = require("../db");

// Returns authenticated user ID from cookies (or null if not logged in)
function getAuthUserId(req) {
  const userId = req.cookies?.authUser;
  return userId ? Number(userId) : null;
}

// Promise-based wrapper for SQL queries (enables async/await)
function queryAsync(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.query(sql, params, (err, rows) => {
      if (err) return reject(err);
      resolve(rows);
    });
  });
}

// GET /api/favorites
// Returns the student's favorite teachers with their subjects
async function getFavorites(req, res) {
  try {
    const studentId = getAuthUserId(req);
    if (!studentId) {
      return res.status(401).json({ ok: false, message: "Not authenticated" });
    }

    // One row per (teacher, subject); grouped later in the server
    const rows = await queryAsync(
      `
      SELECT
        u.user_id AS teacher_user_id,
        CONCAT(u.first_name,' ',u.last_name) AS fullName,
        s.subject_name,
        ts.price_per_hour,
        ts.duration_minutes
      FROM student_favorites f
      JOIN users u ON u.user_id = f.teacher_user_id
      LEFT JOIN teacher_subjects ts ON ts.user_id = u.user_id
      LEFT JOIN subjects s ON s.subject_id = ts.subject_id
      WHERE f.student_user_id = ?
      ORDER BY f.created_at DESC, s.subject_name ASC
      `,
      [studentId]
    );

    // Group subjects by teacher
    const map = new Map();

    rows.forEach((r) => {
      const id = Number(r.teacher_user_id);

      if (!map.has(id)) {
        map.set(id, {
          user_id: id,
          fullName: r.fullName,
          subjects: [],
        });
      }

      if (r.subject_name) {
        map.get(id).subjects.push({
          subject_name: r.subject_name,
          price_per_hour: Number(r.price_per_hour),
          duration_minutes: Number(r.duration_minutes || 0),
        });
      }
    });

    return res.json({ ok: true, favorites: Array.from(map.values()) });
  } catch (err) {
    console.error("getFavorites error:", err);
    return res.status(500).json({ ok: false, message: "Server error" });
  }
}

// POST /api/favorites/:teacherId
// Adds a teacher to the student's favorites
async function addFavorite(req, res) {
  try {
    const studentId = getAuthUserId(req);
    if (!studentId) {
      return res.status(401).json({ ok: false, message: "Not authenticated" });
    }

    const teacherId = Number(req.params.teacherId);
    if (!Number.isFinite(teacherId)) {
      return res.status(400).json({ ok: false, message: "Invalid teacherId" });
    }

    // INSERT IGNORE prevents duplicate favorites
    await queryAsync(
      `INSERT IGNORE INTO student_favorites (student_user_id, teacher_user_id)
       VALUES (?, ?)`,
      [studentId, teacherId]
    );

    return res.json({ ok: true });
  } catch (err) {
    console.error("addFavorite error:", err);
    return res.status(500).json({ ok: false, message: "Server error" });
  }
}

// DELETE /api/favorites/:teacherId
// Removes a teacher from the student's favorites
async function removeFavorite(req, res) {
  try {
    const studentId = getAuthUserId(req);
    if (!studentId) {
      return res.status(401).json({ ok: false, message: "Not authenticated" });
    }

    const teacherId = Number(req.params.teacherId);
    if (!Number.isFinite(teacherId)) {
      return res.status(400).json({ ok: false, message: "Invalid teacherId" });
    }

    await queryAsync(
      `DELETE FROM student_favorites
       WHERE student_user_id = ? AND teacher_user_id = ?`,
      [studentId, teacherId]
    );

    return res.json({ ok: true });
  } catch (err) {
    console.error("removeFavorite error:", err);
    return res.status(500).json({ ok: false, message: "Server error" });
  }
}

module.exports = { getFavorites, addFavorite, removeFavorite };
