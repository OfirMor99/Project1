// db.js
const mysql = require("mysql2");
const dbConfig = require("./db.config.js");

const connection = mysql.createConnection({
  host: dbConfig.HOST,
  user: dbConfig.USER,
  password: dbConfig.PASSWORD,
  database: dbConfig.DB,
});

connection.connect((err) => {
  if (err) {
    console.error("❌ DB connection failed:", err);
    return;
  }
  console.log("✅ Successfully connected to the database.");

  connection.query("SELECT CURRENT_USER() AS u", (e, r) => {
    if (e) return console.error("❌ CURRENT_USER query failed:", e);
    console.log("✅ DB user:", r?.[0]?.u);
  });
});

module.exports = connection;
