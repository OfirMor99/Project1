// public/js/nav.js

document.addEventListener("DOMContentLoaded", () => {
  initMobileNavigation();
  renderAuthNav();
});

// Initialize mobile menu and authentication check
function initMobileNavigation() {
  const toggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector("header nav");

  if (!toggle || !nav) return;

  bindToggleClick(toggle, nav);
  bindResizeReset(toggle, nav);
}

// Toggle menu open/close on button click
function bindToggleClick(toggle, nav) {
  toggle.addEventListener("click", () => {
    const isOpen = nav.classList.toggle("is-open");

    // Update accessibility attribute and icon
    toggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
    toggle.textContent = isOpen ? "✕" : "☰";
  });
}

// Close mobile menu if window is resized to desktop width
function bindResizeReset(toggle, nav) {
  window.addEventListener("resize", () => {
    if (window.innerWidth > 600) {
      nav.classList.remove("is-open");
      toggle.setAttribute("aria-expanded", "false");
      toggle.textContent = "☰";
    }
  });
}

// Check login status and render appropriate links (Login/Logout)
async function renderAuthNav() {
  const authNav = document.getElementById("auth-nav");
  if (!authNav) return;

  const LOGIN_URL = "/pages/login/login.html";
  const HOME_URL = "/index.html";

  try {
    // Check session status with server
    const res = await fetch(`/api/me?ts=${Date.now()}`, {
      credentials: "same-origin",
      cache: "no-store",
    });

    const data = await res.json().catch(() => ({}));

    // If not logged in, show Login link
    if (!res.ok || !data?.ok) {
      authNav.innerHTML = `<li><a href="${LOGIN_URL}">התחברות</a></li>`;
      return;
    }

    // If logged in, show Logout link
    authNav.innerHTML = `<li><a href="#" id="logout-link">התנתק</a></li>`;

    const logoutLink = document.getElementById("logout-link");
    if (!logoutLink) return;

    logoutLink.addEventListener("click", async (e) => {
      e.preventDefault();

      try {
        // Call logout API to clear session
        await fetch("/api/logout", {
          method: "POST",
          credentials: "same-origin",
        });
      } catch (err) {
        console.error("Logout error:", err);
      }

      // Update UI and redirect to home
      authNav.innerHTML = `<li><a href="${LOGIN_URL}">התחברות</a></li>`;
      window.location.href = HOME_URL;
    });
  } catch (err) {
    console.error("Auth nav error:", err);
    // Default to login link on error
    authNav.innerHTML = `<li><a href="/pages/login/login.html">התחברות</a></li>`;
  }
}