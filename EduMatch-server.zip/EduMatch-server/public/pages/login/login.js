// public/js/login.js
document.addEventListener("DOMContentLoaded", () => {
  // Toggle password visibility (eye button) using Font Awesome icons
  document.querySelectorAll(".toggle-password").forEach((btn) => {
    btn.addEventListener("click", () => {
      const wrapper = btn.closest(".password-wrapper");
      const input = wrapper?.querySelector("input");
      const icon = btn.querySelector("i");

      if (!input) return;

      const isPassword = input.type === "password";
      input.type = isPassword ? "text" : "password";

      // Switch eye / eye-slash icons
      if (icon) {
        icon.classList.toggle("fa-eye", !isPassword);
        icon.classList.toggle("fa-eye-slash", isPassword);
      }

      // Update accessibility attributes
      btn.setAttribute("aria-label", isPassword ? "הסתר סיסמה" : "הצג סיסמה");
      btn.setAttribute("aria-pressed", isPassword ? "true" : "false");
    });
  });

  // Validates basic email format
  const isEmailValid = (value) =>
    /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test((value || "").trim());

  // Returns the closest ".form-row" wrapper for a given input
  function getRowEl(input) {
    return input?.closest?.(".form-row") || null;
  }

  // Shows a field-level error message and sets aria-invalid
  function setFieldError(input, message) {
    const row = getRowEl(input);
    if (!row || !input) return;
    const p = row.querySelector(".error-message");
    if (p) p.textContent = message || "";
    input.setAttribute("aria-invalid", message ? "true" : "false");
  }

  // Clears a field-level error
  function clearFieldError(input) {
    if (!input) return;
    setFieldError(input, "");
  }

  // Adds a short "shake" animation to highlight invalid input
  function shakeInput(input) {
    if (!input) return;
    input.classList.remove("input-error");
    void input.offsetWidth;
    input.classList.add("input-error");
    input.addEventListener("animationend", () => input.classList.remove("input-error"), {
      once: true,
    });
  }

  // Shows a form-level alert with a list of validation messages
  function setAlert(alertEl, messages) {
    if (!alertEl) return;

    if (!messages || messages.length === 0) {
      alertEl.hidden = true;
      alertEl.innerHTML = "";
      return;
    }

    alertEl.hidden = false;
    alertEl.innerHTML = `
      <strong>יש לתקן את השדות הבאים:</strong>
      <ul>
        ${messages.map((m) => `<li>${m}</li>`).join("")}
      </ul>
    `;
    // Scroll to alert for better UX
    alertEl.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  // Stores a legacy "logged in" flag in sessionStorage (optional)
  function setLoggedInLegacy() {
    try {
      sessionStorage.setItem("edumatchLoggedIn", "true");
    } catch (_) { }
  }

  // Clears login fields to prevent unwanted autofill leftovers
  function clearLoginFieldsIfPresent() {
    const loginForm = document.querySelector("#login-form");
    if (!loginForm) return;

    const email = loginForm.querySelector("#login-email");
    const password = loginForm.querySelector("#login-password");

    // Do not clear if the user already typed something
    const hasTyped = (email?.value || "").trim() || (password?.value || "").trim();
    if (hasTyped) return;

    if (email) email.value = "";
    if (password) password.value = "";

    const loginAlert = loginForm.querySelector("#login-alert");
    if (loginAlert) setAlert(loginAlert, []);
    [email, password].forEach(clearFieldError);
  }

  // Run the clear routine on load and when returning via back/forward cache
  setTimeout(clearLoginFieldsIfPresent, 80);
  window.addEventListener("pageshow", () => setTimeout(clearLoginFieldsIfPresent, 80));

  // Login form initialization
  const loginForm = document.querySelector("#login-form");
  if (!loginForm) return;

  const email = loginForm.querySelector("#login-email");
  const password = loginForm.querySelector("#login-password");
  const loginAlert = loginForm.querySelector("#login-alert");

  // Handle login form submission
  loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    const errs = [];
    // Clear previous errors
    [email, password].forEach(clearFieldError);

    // Client-side validation
    if (!email?.value.trim() || !isEmailValid(email.value)) {
      errs.push("אימייל לא תקין");
      setFieldError(email, "אימייל לא תקין");
    }

    if (!password?.value || password.value.length < 6) {
      errs.push("סיסמה קצרה מדי");
      setFieldError(password, "סיסמה קצרה מדי");
    }

    // Show validation results
    if (errs.length) {
      if (email) shakeInput(email);
      if (password) shakeInput(password);
      setAlert(loginAlert, errs);
      return;
    }

    // Disable submit button while request is running
    const submitBtn = loginForm.querySelector("button[type='submit']");
    const prevText = submitBtn?.textContent;
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.textContent = "מתחברת...";
    }

    try {
      // Send login request to server
      const res = await fetch("/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        credentials: "include",
        body: JSON.stringify({
          email: email.value.trim(),
          password: password.value,
        }),
      });

      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data?.ok) {
        setAlert(loginAlert, [data?.message || "שגיאת התחברות"]);
        return;
      }

      // Verify the auth cookie works by calling /api/me
      const meRes = await fetch(`/api/me?ts=${Date.now()}`, {
        method: "GET",
        credentials: "include",
        cache: "no-store",
        headers: { Accept: "application/json" },
      });

      const meData = await meRes.json().catch(() => null);
      if (!meRes.ok || !meData?.ok || !meData?.user) {
        setAlert(loginAlert, [
          "התחברת, אבל השרת לא מזהה את ה-cookie של ההתחברות.",
          "בדקי: Application → Cookies → authUser קיים?",
        ]);
        return;
      }

      // Mark login state and redirect to profile page
      setLoggedInLegacy();
      window.location.href = "/pages/profile/profile.html";
    } catch (err) {
      console.error("login error:", err);
      setAlert(loginAlert, ["שגיאת שרת"]);
    } finally {
      // Restore submit button state
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.textContent = prevText || "התחבר";
      }
    }
  });
});
