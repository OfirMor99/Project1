// public/js/login.js
document.addEventListener("DOMContentLoaded", () => {
  // Password visibility toggle (eye button) for inputs inside .password-wrapper
  document.querySelectorAll(".toggle-password").forEach((btn) => {
    btn.addEventListener("click", () => {
      const wrapper = btn.closest(".password-wrapper");
      const input = wrapper?.querySelector("input");
      const icon = btn.querySelector("i");

      if (!input) return;

      const isPassword = input.type === "password";
      input.type = isPassword ? "text" : "password";

      // Switch eye / eye-slash icons
      if (icon) {
        icon.classList.toggle("fa-eye", !isPassword);
        icon.classList.toggle("fa-eye-slash", isPassword);
      }

      // Update accessibility attributes
      btn.setAttribute("aria-label", isPassword ? "הסתר סיסמה" : "הצג סיסמה");
      btn.setAttribute("aria-pressed", isPassword ? "true" : "false");
    });
  });

  // Basic email format validation helper
  const isEmailValid = (value) =>
    /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test((value || "").trim());

  function getRowEl(input) {
    return input?.closest?.(".form-row") || null;
  }

  // Field-level errors are shown inside .error-message + aria-invalid for accessibility
  function setFieldError(input, message) {
    const row = getRowEl(input);
    if (!row || !input) return;
    const p = row.querySelector(".error-message");
    if (p) p.textContent = message || "";
    input.setAttribute("aria-invalid", message ? "true" : "false");
  }

  function clearFieldError(input) {
    if (!input) return;
    setFieldError(input, "");
  }

  // Small shake animation to highlight invalid input
  function shakeInput(input) {
    if (!input) return;
    input.classList.remove("input-error");
    void input.offsetWidth;
    input.classList.add("input-error");
    input.addEventListener("animationend", () => input.classList.remove("input-error"), {
      once: true,
    });
  }

  // Form-level alert rendering (list of validation messages)
  function setAlert(alertEl, messages) {
    if (!alertEl) return;

    if (!messages || messages.length === 0) {
      alertEl.hidden = true;
      alertEl.innerHTML = "";
      return;
    }

    alertEl.hidden = false;
    alertEl.innerHTML = `
      <strong>יש לתקן את השדות הבאים:</strong>
      <ul>
        ${messages.map((m) => `<li>${m}</li>`).join("")}
      </ul>
    `;
    alertEl.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  // Stores a simple login flag in sessionStorage (legacy support)
  function setLoggedInLegacy() {
    try {
      sessionStorage.setItem("edumatchLoggedIn", "true");
    } catch (_) { }
  }

  // Clear fields on load to avoid unwanted autofill leftovers (only if user didn't type)
  function clearLoginFieldsIfPresent() {
    const loginForm = document.querySelector("#login-form");
    if (!loginForm) return;

    const email = loginForm.querySelector("#login-email");
    const password = loginForm.querySelector("#login-password");

    const hasTyped = (email?.value || "").trim() || (password?.value || "").trim();
    if (hasTyped) return;

    if (email) email.value = "";
    if (password) password.value = "";

    const loginAlert = loginForm.querySelector("#login-alert");
    if (loginAlert) setAlert(loginAlert, []);
    [email, password].forEach(clearFieldError);
  }

  setTimeout(clearLoginFieldsIfPresent, 80);
  window.addEventListener("pageshow", () => setTimeout(clearLoginFieldsIfPresent, 80));

  const loginForm = document.querySelector("#login-form");
  if (!loginForm) return;

  const email = loginForm.querySelector("#login-email");
  const password = loginForm.querySelector("#login-password");
  const loginAlert = loginForm.querySelector("#login-alert");

  // Submit: validate -> POST /api/login -> verify /api/me -> redirect
  loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    const errs = [];
    [email, password].forEach(clearFieldError);

    if (!email?.value.trim() || !isEmailValid(email.value)) {
      errs.push("אימייל לא תקין");
      setFieldError(email, "אימייל לא תקין");
    }

    if (!password?.value || password.value.length < 6) {
      errs.push("סיסמה קצרה מדי");
      setFieldError(password, "סיסמה קצרה מדי");
    }

    if (errs.length) {
      if (email) shakeInput(email);
      if (password) shakeInput(password);
      setAlert(loginAlert, errs);
      return;
    }

    const submitBtn = loginForm.querySelector("button[type='submit']");
    const prevText = submitBtn?.textContent;
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.textContent = "מתחברת...";
    }

    try {
      const res = await fetch("/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        credentials: "include",
        body: JSON.stringify({
          email: email.value.trim(),
          password: password.value,
        }),
      });

      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data?.ok) {
        setAlert(loginAlert, [data?.message || "שגיאת התחברות"]);
        return;
      }

      // Verify the auth cookie works by calling /api/me
      const meRes = await fetch(`/api/me?ts=${Date.now()}`, {
        method: "GET",
        credentials: "include",
        cache: "no-store",
        headers: { Accept: "application/json" },
      });

      const meData = await meRes.json().catch(() => null);
      if (!meRes.ok || !meData?.ok || !meData?.user) {
        setAlert(loginAlert, [
          "התחברת, אבל השרת לא מזהה את ה-cookie של ההתחברות.",
          "בדקי: Application → Cookies → authUser קיים?",
        ]);
        return;
      }

      setLoggedInLegacy();
      window.location.href = "/pages/profile/profile.html";
    } catch (err) {
      console.error("login error:", err);
      setAlert(loginAlert, ["שגיאת שרת"]);
    } finally {
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.textContent = prevText || "התחבר";
      }
    }
  });
});
