// public/pages/teachers/teachers.js

document.addEventListener("DOMContentLoaded", () => {
  // Runs the teachers search page logic after the DOM is ready.

  console.log("✅ teachers.js loaded");
  // Debug log to confirm the script is loaded.

  const form = document.getElementById("search-form");
  const listEl = document.getElementById("teachers-list");
  const noResultsEl = document.getElementById("no-results");
  const resultsTitleEl = document.getElementById("results-title");
  // Core UI elements: search form, results container, empty message, results title.

  const subjectInput = document.getElementById("filter-subject");
  const cityInput = document.getElementById("filter-city");
  const nameInput = document.getElementById("filter-name");
  // Filter inputs.

  const slider = document.getElementById("search-price-range");
  const bubble = document.getElementById("search-price-bubble");
  // Price slider + bubble display.

  // ---------- hard validation (don’t fail silently) ----------
  const missing = [];
  // Collect missing required elements so the page fails loudly (with a visible warning).

  if (!form) missing.push("#search-form (form)");
  if (!listEl) missing.push("#teachers-list (results container)");
  if (!noResultsEl) missing.push("#no-results (message container)");
  if (!resultsTitleEl) missing.push("#results-title (results title)");

  if (missing.length) {
    // If something essential is missing in the HTML, show a clear error and stop.
    console.error("❌ Missing required elements:", missing);

    if (document.body) {
      const warn = document.createElement("div");
      // Builds a styled inline error banner.

      warn.style.padding = "12px";
      warn.style.margin = "12px 0";
      warn.style.border = "1px solid #ff4d4f";
      warn.style.borderRadius = "8px";
      warn.style.background = "rgba(255, 77, 79, 0.08)";
      warn.style.direction = "rtl";
      warn.style.fontFamily = "inherit";

      warn.innerHTML = `
        <strong>שגיאה בעמוד:</strong><br/>
        חסרים אלמנטים חובה ב-HTML, ולכן החיפוש לא עובד.<br/>
        <span style="opacity:.85">${missing.join(", ")}</span>
      `;
      // Explains exactly which selectors are missing.

      document.body.prepend(warn);
      // Shows the warning at the top of the page.
    }
    return;
    // Stop execution to avoid silent failures.
  }

  // ✅ initial state: no search yet -> hide results title
  resultsTitleEl.hidden = true;
  // Hides the results title until the user searches.

  function setResultsTitleVisible(isVisible) {
    // Toggles the results title visibility.
    resultsTitleEl.hidden = !isVisible;
  }

  // =========================================================
  // ✅ DATALISTS: Cities + Subjects (DEFAULT + DB)
  // =========================================================
  function fillDatalist(listEl, items, locale = "he") {
    // Fills a datalist element with <option> items.
    if (!listEl) return;

    listEl.innerHTML = "";
    const frag = document.createDocumentFragment();

    items.forEach((val) => {
      const opt = document.createElement("option");
      opt.value = val;
      frag.appendChild(opt);
    });

    listEl.appendChild(frag);
    // Appends all options in one operation (faster).
  }

  async function loadCitiesDatalist() {
    // Loads cities suggestions from defaults + optional API.
    const list = document.getElementById("cities-list");
    if (!list) return;

    const defaultCities = [
      // Fallback city list if API is missing/unavailable.
      "אור יהודה", "אופקים", "אילת", "אלעד", "אריאל", "אשדוד", "אשקלון",
      "באר יעקב", "באר שבע", "בית שמש", "בית שאן", "בני ברק", "בת ים",
      "גבעתיים", "גדרה", "דימונה", "הרצליה", "חדרה", "חולון", "חיפה",
      "טבריה", "יבנה", "יהוד-מונוסון", "ירוחם", "ירושלים",
      "כפר סבא", "כרמיאל", "לוד", "מודיעין-מכבים-רעות", "מעלה אדומים",
      "נהריה", "נס ציונה", "נצרת", "נשר", "נתיבות", "נתניה",
      "עכו", "עפולה", "ערד",
      "פתח תקווה", "צפת", "קריית אתא", "קריית גת", "קריית ים", "קריית מוצקין", "קריית שמונה",
      "ראש העין", "ראשון לציון", "רחובות", "רמלה", "רמת גן", "רמת השרון", "רעננה",
      "שדרות", "תל אביב-יפו"
    ];

    let dbCities = [];
    // Will hold cities from backend.

    try {
      const res = await fetch(`/api/cities?ts=${Date.now()}`, {
        // Fetch cities (ts avoids cache).
        headers: { Accept: "application/json" },
        cache: "no-store",
      });

      const data = await res.json().catch(() => null);
      // Safe JSON parsing.

      if (res.ok && data?.ok && Array.isArray(data.cities)) dbCities = data.cities;
      // Use server cities only if response is valid.
    } catch (e) {
      console.warn("❌ cities API failed, using defaults only:", e);
      // If API fails, fall back to defaults.
    }

    const merged = Array.from(
      // Merge + trim + remove blanks + dedupe.
      new Set([...defaultCities, ...dbCities].map((c) => String(c || "").trim()).filter(Boolean))
    ).sort((a, b) => a.localeCompare(b, "he"));
    // Sort in Hebrew.

    fillDatalist(list, merged, "he");
    // Render to datalist.
  }

  async function loadSubjectsDatalist() {
    // Loads subject suggestions from defaults + optional API.
    const list = document.getElementById("subjects-list");
    if (!list) return;

    const defaultSubjects = [
      // Big friendly list of common subjects to help the user search quickly.
      "מתמטיקה", "אנגלית", "עברית", "לשון", "ספרות", "היסטוריה", "אזרחות", "גיאוגרפיה", "תנ״ך",
      "פיזיקה", "כימיה", "ביולוגיה", "מדעי המחשב", "מדעים",
      "תכנות", "Python", "JavaScript", "Java", "C#", "C", "C++",
      "SQL", "MySQL", "מסדי נתונים", "אלגוריתמים", "מבני נתונים", "פיתוח אתרים", "HTML", "CSS",
      "פסיכומטרי - כמותי", "פסיכומטרי - מילולי", "פסיכומטרי - אנגלית", "פסיכומטרי - חיבור",
      "חדו\"א", "אלגברה לינארית", "סטטיסטיקה", "הסתברות", "כלכלה", "חשבונאות", "ניהול", "מערכות מידע",
      "אנגלית מדוברת", "ערבית", "רוסית", "ספרדית", "צרפתית", "גרמנית",
      "פוטושופ", "אילוסטרייטור", "עיצוב גרפי", "ציור",
      "גיטרה", "פסנתר", "פיתוח קול"
    ];

    let dbSubjects = [];
    // Will hold subjects returned from backend.

    try {
      const res = await fetch(`/api/subjects?ts=${Date.now()}`, {
        // Fetch subjects (ts avoids cache).
        headers: { Accept: "application/json" },
        cache: "no-store",
      });

      const data = await res.json().catch(() => null);

      if (res.ok && data?.ok && Array.isArray(data.subjects)) {
        // Supports either array of strings or array of objects with subject_name.
        dbSubjects = data.subjects
          .map((x) => (typeof x === "string" ? x : x?.subject_name))
          .filter(Boolean);
      }
    } catch (e) {
      console.warn("ℹ️ subjects API not available, using defaults only.");
      // Not fatal: defaults are enough.
    }

    const merged = Array.from(
      // Merge + trim + remove blanks + dedupe.
      new Set([...defaultSubjects, ...dbSubjects].map((s) => String(s || "").trim()).filter(Boolean))
    ).sort((a, b) => a.localeCompare(b, "he"));
    // Sort in Hebrew.

    fillDatalist(list, merged, "he");
    // Render to datalist.
  }

  loadCitiesDatalist();
  loadSubjectsDatalist();
  // Loads both suggestion lists immediately.

  // =========================================================
  // Favorites state (DB is source of truth)
  // =========================================================
  let favoritesSet = new Set();
  // Holds teacher user_ids that are in favorites (strings).

  async function loadFavoritesSet() {
    // Loads the current favorites list from the backend.
    try {
      const res = await fetch(`/api/favorites?ts=${Date.now()}`, {
        credentials: "same-origin",
        cache: "no-store",
        headers: { Accept: "application/json" },
      });

      const data = await res.json().catch(() => null);

      if (!res.ok || !data?.ok) {
        // If not logged in or error, treat as no favorites.
        favoritesSet = new Set();
        return;
      }

      const favs = Array.isArray(data.favorites) ? data.favorites : [];
      favoritesSet = new Set(favs.map((x) => String(x.user_id)));
      // Store favorites as a set for fast lookup.
    } catch {
      favoritesSet = new Set();
      // Network errors -> empty favorites set.
    }
  }

  // ---------- price bubble (RTL fix) ----------
  function updateBubble() {
    // Updates the slider bubble label and positions it in RTL.
    if (!slider || !bubble) return;

    bubble.textContent = slider.value;
    // Shows current slider value.

    const min = Number(slider.min || 0);
    const max = Number(slider.max || 100);
    const val = Number(slider.value || 0);
    const pct = (val - min) / (max - min || 1);
    // Calculates slider value percentage.

    bubble.style.left = "auto";
    bubble.style.right = `${pct * 100}%`;
    // RTL positioning: move bubble using "right".
  }

  if (slider) {
    updateBubble();
    // Initialize bubble position.
    slider.addEventListener("input", updateBubble);
    // Update bubble while dragging.
  }

  // ---------- UI helpers ----------
  function escapeHtml(str) {
    // Escapes unsafe characters to prevent HTML injection in rendered results.
    return String(str ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function showMessage(msg) {
    // Clears results and shows an empty-state message.
    listEl.innerHTML = "";
    noResultsEl.textContent = msg;
    noResultsEl.style.display = "block";
  }

  function clearMessage() {
    // Hides the empty-state message.
    noResultsEl.style.display = "none";
    noResultsEl.textContent = "";
  }

  function setLoading(isLoading) {
    // Shows a loading message in the results list.
    if (!isLoading) return;
    clearMessage();
    listEl.innerHTML = `<p class="empty-state">טוען תוצאות...</p>`;
  }

  function prettyLessonMode(mode) {
    // Converts internal lesson_mode values to user-friendly Hebrew labels.
    const m = String(mode || "").trim().toLowerCase();
    if (m === "online") return "אונליין";
    if (m === "frontal") return "פרונטלי";
    if (m === "both") return "אונליין + פרונטלי";
    return mode ? String(mode) : "";
  }

  function requireLoginForFavorites() {
    // Alerts the user that they must log in to use favorites.
    alert("התחבר/י על מנת להוסיף מורה למועדפים");
  }

  // ---------- navigation to BOOK ----------
  function goToBook(teacherId) {
    // Navigates to book.html with teacherId (and optional current subject filter).
    const id = encodeURIComponent(String(teacherId));
    const subject = encodeURIComponent((subjectInput?.value || "").trim());
    window.location.href = `../book/book.html?teacherId=${id}${subject ? `&subject=${subject}` : ""}`;
  }

  function renderTeachers(teachers) {
    // Renders teacher cards into the results list.
    listEl.innerHTML = "";

    if (!teachers || teachers.length === 0) {
      showMessage("לא נמצאו מורים מתאימים לחיפוש שביצעת.");
      return;
    }

    clearMessage();

    teachers.forEach((t) => {
      // Build the subjects section for each teacher.
      const subjectsHtml = (t.subjects || [])
        .map((s) => {
          const price = Number(s.price);
          const dur = Number(s.duration_minutes);

          return `
            <div class="teacher-subject">
              <strong>${escapeHtml(s.subject)}</strong>
              <span>${Number.isFinite(price) ? price : ""} ₪ לשעה</span>
              <span>${Number.isFinite(dur) ? `(${dur} דק׳)` : ""}</span>
            </div>
          `;
        })
        .join("");

      const modeLabel = prettyLessonMode(t.lesson_mode);
      // Human-friendly lesson mode.

      const teacherIdStr = String(t.user_id);
      // Normalized teacher id string.

      const favOn = favoritesSet.has(teacherIdStr);
      // Checks if teacher is currently in favorites.
      const favLabel = favOn ? " הסר ממועדפים" : " הוסף למועדפים";
      // Button label depends on current favorite state.

      const card = document.createElement("article");
      card.className = "teacher-card";
      // Creates a teacher card element.

      card.innerHTML = `
        <div class="teacher-card-header">
          <h3>${escapeHtml(t.fullName)}</h3>
          <p class="teacher-meta">
            ${t.city ? `📍 ${escapeHtml(t.city)}` : ""}
            ${modeLabel ? ` • ${escapeHtml(modeLabel)}` : ""}
          </p>
        </div>

        <div class="teacher-card-body">
          ${subjectsHtml || `<p class="empty-state">אין מקצועות להצגה</p>`}
        </div>

        <div class="teacher-actions">
          <button type="button" class="btn-secondary btn-fav" data-teacher-id="${escapeHtml(t.user_id)}">
            ${escapeHtml(favLabel)}
          </button>
          <button type="button" class="btn-primary btn-book" data-teacher-id="${escapeHtml(t.user_id)}">
            בדוק זמינות
          </button>
        </div>
      `;
      // Card HTML includes favorite + booking actions.

      const favBtn = card.querySelector(".btn-fav");
      const bookBtn = card.querySelector(".btn-book");
      // Extracts the action buttons from the card.

      if (favBtn) {
        favBtn.addEventListener("click", async () => {
          // Toggles teacher favorite status via the backend.
          const id = favBtn.getAttribute("data-teacher-id");
          if (!id) return;

          const idStr = String(id);
          const currentlyOn = favoritesSet.has(idStr);

          favBtn.disabled = true;
          // Prevent double-click while request is running.

          try {
            const res = await fetch(`/api/favorites/${encodeURIComponent(idStr)}`, {
              // POST adds favorite, DELETE removes favorite.
              method: currentlyOn ? "DELETE" : "POST",
              credentials: "same-origin",
              headers: { Accept: "application/json" },
            });

            if (res.status === 401) {
              // If user is not logged in, show message and stop.
              requireLoginForFavorites();
              return;
            }

            const data = await res.json().catch(() => null);

            if (!res.ok || !data?.ok) {
              // Logs errors but doesn't break the UI.
              console.error("favorites failed:", res.status, data);
              return;
            }

            // Updates local favorites state + button label.
            if (currentlyOn) {
              favoritesSet.delete(idStr);
              favBtn.textContent = " הוסף למועדפים";
            } else {
              favoritesSet.add(idStr);
              favBtn.textContent = " הסר ממועדפים";
            }
          } catch (err) {
            console.error("favorites error:", err);
            // Network failure while updating favorite state.
          } finally {
            favBtn.disabled = false;
            // Re-enable the button after the request.
          }
        });
      }

      if (bookBtn) {
        bookBtn.addEventListener("click", () => {
          // Opens booking page for this teacher.
          const id = bookBtn.getAttribute("data-teacher-id");
          goToBook(id);
        });
      }

      listEl.appendChild(card);
      // Adds the card to the results list.
    });
  }

  async function searchTeachers() {
    // Runs the teacher search request based on current filters.
    console.log("🔎 searchTeachers() triggered");

    const subject = (subjectInput?.value || "").trim();
    const city = (cityInput?.value || "").trim();
    const name = (nameInput?.value || "").trim();
    const maxPrice = slider ? Number(slider.value) : null;
    // Reads filter values.

    if (!subject || subject.length < 2) {
      // Subject is required (minimum 2 chars).
      setResultsTitleVisible(false);
      showMessage("חובה להזין מקצוע (לפחות 2 תווים).");
      return;
    }

    setResultsTitleVisible(true);
    // Shows "Results" title after the first valid search.

    const params = new URLSearchParams();
    // Builds query parameters for /api/teachers.
    params.set("subject", subject);
    if (city) params.set("city", city);
    if (name) params.set("name", name);
    if (Number.isFinite(maxPrice)) params.set("maxPrice", String(maxPrice));

    setLoading(true);
    // Shows loading state before request.

    try {
      await loadFavoritesSet();
      // Refresh favorites set so buttons are accurate.

      const url = `/api/teachers?${params.toString()}`;
      console.log("➡️ fetching:", url);

      const res = await fetch(url, {
        method: "GET",
        headers: { Accept: "application/json" },
      });

      const data = await res.json().catch(() => null);
      console.log("⬅️ response:", res.status, data);

      if (!res.ok || !data?.ok) {
        // Shows server-provided error message if available.
        const msg = data?.message || "שגיאה בחיפוש מורים";
        showMessage(msg);
        return;
      }

      renderTeachers(data.teachers);
      // Renders teacher cards from the response.
    } catch (err) {
      console.error("❌ fetch error:", err);
      showMessage("שגיאת רשת. בדקי שהשרת רץ ושאת ב-localhost.");
      // Handles network/connection issues.
    }
  }

  form.addEventListener("submit", (e) => {
    // Prevents default form submit and runs JS search instead.
    e.preventDefault();
    searchTeachers();
  });

  form.addEventListener("reset", () => {
    // Clears results and UI after reset (timeout ensures inputs reset first).
    setTimeout(() => {
      updateBubble();
      listEl.innerHTML = "";
      clearMessage();
      setResultsTitleVisible(false);
    }, 0);
  });
});
