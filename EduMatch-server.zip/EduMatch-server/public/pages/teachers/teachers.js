// public/pages/teachers/teachers.js
document.addEventListener("DOMContentLoaded", () => {
  console.log("✅ teachers.js loaded");

  const form = document.getElementById("search-form");
  const listEl = document.getElementById("teachers-list");
  const noResultsEl = document.getElementById("no-results");
  const resultsTitleEl = document.getElementById("results-title");

  const subjectInput = document.getElementById("filter-subject");
  const cityInput = document.getElementById("filter-city");
  const nameInput = document.getElementById("filter-name");

  const slider = document.getElementById("search-price-range");
  const bubble = document.getElementById("search-price-bubble");

  // Hard check: if essential HTML elements are missing, show a clear warning and stop.
  const missing = [];
  if (!form) missing.push("#search-form (form)");
  if (!listEl) missing.push("#teachers-list (results container)");
  if (!noResultsEl) missing.push("#no-results (message container)");
  if (!resultsTitleEl) missing.push("#results-title (results title)");

  if (missing.length) {
    console.error("❌ Missing required elements:", missing);

    if (document.body) {
      const warn = document.createElement("div");
      warn.style.padding = "12px";
      warn.style.margin = "12px 0";
      warn.style.border = "1px solid #ff4d4f";
      warn.style.borderRadius = "8px";
      warn.style.background = "rgba(255, 77, 79, 0.08)";
      warn.style.direction = "rtl";
      warn.style.fontFamily = "inherit";

      warn.innerHTML = `
        <strong>שגיאה בעמוד:</strong><br/>
        חסרים אלמנטים חובה ב-HTML, ולכן החיפוש לא עובד.<br/>
        <span style="opacity:.85">${missing.join(", ")}</span>
      `;

      document.body.prepend(warn);
    }
    return;
  }

  // Hide title until the first valid search happens.
  resultsTitleEl.hidden = true;

  function setResultsTitleVisible(isVisible) {
    resultsTitleEl.hidden = !isVisible;
  }

  // DATALISTS: Cities + Subjects (defaults + optional API)
  function fillDatalist(listEl, items) {
    if (!listEl) return;

    listEl.innerHTML = "";
    const frag = document.createDocumentFragment();

    items.forEach((val) => {
      const opt = document.createElement("option");
      opt.value = val;
      frag.appendChild(opt);
    });

    listEl.appendChild(frag);
  }

  async function loadCitiesDatalist() {
    const list = document.getElementById("cities-list");
    if (!list) return;

    const defaultCities = [
      "אור יהודה", "אופקים", "אילת", "אלעד", "אריאל", "אשדוד", "אשקלון",
      "באר יעקב", "באר שבע", "בית שמש", "בית שאן", "בני ברק", "בת ים",
      "גבעתיים", "גדרה", "דימונה", "הרצליה", "חדרה", "חולון", "חיפה",
      "טבריה", "יבנה", "יהוד-מונוסון", "ירוחם", "ירושלים",
      "כפר סבא", "כרמיאל", "לוד", "מודיעין-מכבים-רעות", "מעלה אדומים",
      "נהריה", "נס ציונה", "נצרת", "נשר", "נתיבות", "נתניה",
      "עכו", "עפולה", "ערד",
      "פתח תקווה", "צפת", "קריית אתא", "קריית גת", "קריית ים", "קריית מוצקין", "קריית שמונה",
      "ראש העין", "ראשון לציון", "רחובות", "רמלה", "רמת גן", "רמת השרון", "רעננה",
      "שדרות", "תל אביב-יפו"
    ];

    let dbCities = [];

    try {
      const res = await fetch(`/api/cities?ts=${Date.now()}`, {
        headers: { Accept: "application/json" },
        cache: "no-store",
      });

      const data = await res.json().catch(() => null);
      if (res.ok && data?.ok && Array.isArray(data.cities)) dbCities = data.cities;
    } catch (e) {
      console.warn("❌ cities API failed, using defaults only:", e);
    }

    const merged = Array.from(
      new Set([...defaultCities, ...dbCities].map((c) => String(c || "").trim()).filter(Boolean))
    ).sort((a, b) => a.localeCompare(b, "he"));

    fillDatalist(list, merged);
  }

  async function loadSubjectsDatalist() {
    const list = document.getElementById("subjects-list");
    if (!list) return;

    const defaultSubjects = [
      "מתמטיקה", "אנגלית", "עברית", "לשון", "ספרות", "היסטוריה", "אזרחות", "גיאוגרפיה", "תנ״ך",
      "פיזיקה", "כימיה", "ביולוגיה", "מדעי המחשב", "מדעים",
      "תכנות", "Python", "JavaScript", "Java", "C#", "C", "C++",
      "SQL", "MySQL", "מסדי נתונים", "אלגוריתמים", "מבני נתונים", "פיתוח אתרים", "HTML", "CSS",
      "פסיכומטרי - כמותי", "פסיכומטרי - מילולי", "פסיכומטרי - אנגלית", "פסיכומטרי - חיבור",
      "חדו\"א", "אלגברה לינארית", "סטטיסטיקה", "הסתברות", "כלכלה", "חשבונאות", "ניהול", "מערכות מידע",
      "אנגלית מדוברת", "ערבית", "רוסית", "ספרדית", "צרפתית", "גרמנית",
      "פוטושופ", "אילוסטרייטור", "עיצוב גרפי", "ציור",
      "גיטרה", "פסנתר", "פיתוח קול"
    ];

    let dbSubjects = [];

    try {
      const res = await fetch(`/api/subjects?ts=${Date.now()}`, {
        headers: { Accept: "application/json" },
        cache: "no-store",
      });

      const data = await res.json().catch(() => null);

      if (res.ok && data?.ok && Array.isArray(data.subjects)) {
        dbSubjects = data.subjects
          .map((x) => (typeof x === "string" ? x : x?.subject_name))
          .filter(Boolean);
      }
    } catch (e) {
      console.warn("ℹ️ subjects API not available, using defaults only.");
    }

    const merged = Array.from(
      new Set([...defaultSubjects, ...dbSubjects].map((s) => String(s || "").trim()).filter(Boolean))
    ).sort((a, b) => a.localeCompare(b, "he"));

    fillDatalist(list, merged);
  }

  loadCitiesDatalist();
  loadSubjectsDatalist();

  // Favorites 
  let favoritesSet = new Set();

  async function loadFavoritesSet() {
    try {
      const res = await fetch(`/api/favorites?ts=${Date.now()}`, {
        credentials: "same-origin",
        cache: "no-store",
        headers: { Accept: "application/json" },
      });

      const data = await res.json().catch(() => null);

      if (!res.ok || !data?.ok) {
        favoritesSet = new Set();
        return;
      }

      const favs = Array.isArray(data.favorites) ? data.favorites : [];
      favoritesSet = new Set(favs.map((x) => String(x.user_id)));
    } catch {
      favoritesSet = new Set();
    }
  }

  // Price bubble positioning 
  function updateBubble() {
    if (!slider || !bubble) return;

    bubble.textContent = slider.value;

    const min = Number(slider.min || 0);
    const max = Number(slider.max || 100);
    const val = Number(slider.value || 0);
    const pct = (val - min) / (max - min || 1);

    bubble.style.left = "auto";
    bubble.style.right = `${pct * 100}%`;
  }

  if (slider) {
    updateBubble();
    slider.addEventListener("input", updateBubble);
  }

  // UI helpers 
  function escapeHtml(str) {
    return String(str ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function showMessage(msg) {
    listEl.innerHTML = "";
    noResultsEl.textContent = msg;
    noResultsEl.style.display = "block";
  }

  function clearMessage() {
    noResultsEl.style.display = "none";
    noResultsEl.textContent = "";
  }

  function setLoading(isLoading) {
    if (!isLoading) return;
    clearMessage();
    listEl.innerHTML = `<p class="empty-state">טוען תוצאות...</p>`;
  }

  function prettyLessonMode(mode) {
    const m = String(mode || "").trim().toLowerCase();
    if (m === "online") return "אונליין";
    if (m === "frontal") return "פרונטלי";
    if (m === "both") return "אונליין + פרונטלי";
    return mode ? String(mode) : "";
  }

  function requireLoginForFavorites() {
    alert("התחבר/י על מנת להוסיף מורה למועדפים");
  }

  function goToBook(teacherId) {
    const id = encodeURIComponent(String(teacherId));
    const subject = encodeURIComponent((subjectInput?.value || "").trim());
    window.location.href = `../book/book.html?teacherId=${id}${subject ? `&subject=${subject}` : ""}`;
  }

  function renderTeachers(teachers) {
    listEl.innerHTML = "";

    if (!teachers || teachers.length === 0) {
      showMessage("לא נמצאו מורים מתאימים לחיפוש שביצעת.");
      return;
    }

    clearMessage();

    teachers.forEach((t) => {
      const subjectsHtml = (t.subjects || [])
        .map((s) => {
          const price = Number(s.price);
          const dur = Number(s.duration_minutes);

          return `
            <div class="teacher-subject">
              <strong>${escapeHtml(s.subject)}</strong>
              <span>${Number.isFinite(price) ? price : ""} ₪ לשעה</span>
              <span>${Number.isFinite(dur) ? `(${dur} דק׳)` : ""}</span>
            </div>
          `;
        })
        .join("");

      const modeLabel = prettyLessonMode(t.lesson_mode);

      const teacherIdStr = String(t.user_id);
      const favOn = favoritesSet.has(teacherIdStr);
      const favLabel = favOn ? " הסר ממועדפים" : " הוסף למועדפים";

      const card = document.createElement("article");
      card.className = "teacher-card";

      card.innerHTML = `
        <div class="teacher-card-header">
          <h3>${escapeHtml(t.fullName)}</h3>
          <p class="teacher-meta">
            ${t.city ? `📍 ${escapeHtml(t.city)}` : ""}
            ${modeLabel ? ` • ${escapeHtml(modeLabel)}` : ""}
          </p>
        </div>

        <div class="teacher-card-body">
          ${subjectsHtml || `<p class="empty-state">אין מקצועות להצגה</p>`}
        </div>

        <div class="teacher-actions">
          <button type="button" class="btn-secondary btn-fav" data-teacher-id="${escapeHtml(t.user_id)}">
            ${escapeHtml(favLabel)}
          </button>
          <button type="button" class="btn-primary btn-book" data-teacher-id="${escapeHtml(t.user_id)}">
            בדוק זמינות
          </button>
        </div>
      `;

      const favBtn = card.querySelector(".btn-fav");
      const bookBtn = card.querySelector(".btn-book");

      if (favBtn) {
        favBtn.addEventListener("click", async () => {
          const id = favBtn.getAttribute("data-teacher-id");
          if (!id) return;

          const idStr = String(id);
          const currentlyOn = favoritesSet.has(idStr);

          favBtn.disabled = true;

          try {
            const res = await fetch(`/api/favorites/${encodeURIComponent(idStr)}`, {
              method: currentlyOn ? "DELETE" : "POST",
              credentials: "same-origin",
              headers: { Accept: "application/json" },
            });

            if (res.status === 401) {
              requireLoginForFavorites();
              return;
            }

            const data = await res.json().catch(() => null);

            if (!res.ok || !data?.ok) {
              console.error("favorites failed:", res.status, data);
              return;
            }

            if (currentlyOn) {
              favoritesSet.delete(idStr);
              favBtn.textContent = " הוסף למועדפים";
            } else {
              favoritesSet.add(idStr);
              favBtn.textContent = " הסר ממועדפים";
            }
          } catch (err) {
            console.error("favorites error:", err);
          } finally {
            favBtn.disabled = false;
          }
        });
      }

      if (bookBtn) {
        bookBtn.addEventListener("click", () => {
          const id = bookBtn.getAttribute("data-teacher-id");
          goToBook(id);
        });
      }

      listEl.appendChild(card);
    });
  }

  async function searchTeachers() {
    const subject = (subjectInput?.value || "").trim();
    const city = (cityInput?.value || "").trim();
    const name = (nameInput?.value || "").trim();
    const maxPrice = slider ? Number(slider.value) : null;

    if (!subject || subject.length < 2) {
      setResultsTitleVisible(false);
      showMessage("חובה להזין מקצוע (לפחות 2 תווים).");
      return;
    }

    setResultsTitleVisible(true);

    const params = new URLSearchParams();
    params.set("subject", subject);
    if (city) params.set("city", city);
    if (name) params.set("name", name);
    if (Number.isFinite(maxPrice)) params.set("maxPrice", String(maxPrice));

    setLoading(true);

    try {
      await loadFavoritesSet();

      const url = `/api/teachers?${params.toString()}`;

      const res = await fetch(url, {
        method: "GET",
        headers: { Accept: "application/json" },
      });

      const data = await res.json().catch(() => null);

      if (!res.ok || !data?.ok) {
        const msg = data?.message || "שגיאה בחיפוש מורים";
        showMessage(msg);
        return;
      }

      renderTeachers(data.teachers);
    } catch (err) {
      console.error("❌ fetch error:", err);
      showMessage("שגיאת רשת. בדקי שהשרת רץ ושאת ב-localhost.");
    }
  }

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    searchTeachers();
  });

  form.addEventListener("reset", () => {
    setTimeout(() => {
      updateBubble();
      listEl.innerHTML = "";
      clearMessage();
      setResultsTitleVisible(false);
    }, 0);
  });
});
