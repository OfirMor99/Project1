// public/js/profile.js

// Run all profile-page logic only after the DOM is fully loaded.
document.addEventListener("DOMContentLoaded", () => {
  // Cache main layout containers (logged-out vs logged-in UI).
  const noUserCard = document.getElementById("no-user-card");
  const layout = document.getElementById("profile-layout");

  // Cache main action buttons (edit profile + logout).
  const editBtn = document.getElementById("edit-profile-btn");
  const logoutBtn = document.getElementById("logout-btn");

  // Banner that nudges teachers to fill availability if missing.
  const availabilityBanner = document.getElementById("availability-banner");

  // Cache profile header UI elements (name/email/role/favorites container).
  const ui = {
    greetingEl: document.getElementById("profile-greeting"),
    nameEl: document.getElementById("profile-name"),
    emailEl: document.getElementById("profile-email"),
    fieldEl: document.getElementById("profile-field"),
    rolePill: document.getElementById("profile-role-pill"),
    favoritesSection: document.getElementById("favorites-section"),
  };

  // Shared "Future lessons" section elements (used for student & teacher).
  const futureSection = document.getElementById("future-lessons-section");
  const futureEmptyEl = document.getElementById("future-lessons-empty");
  const futureListEl = document.getElementById("future-lessons-list");

  // Shared "History lessons" section elements (used for student & teacher).
  const historySection = document.getElementById("history-lessons-section");
  const historyEmptyEl = document.getElementById("history-lessons-empty");
  const historyListEl = document.getElementById("history-lessons-list");

  // Modal (edit profile) core elements + multi-step panels/buttons.
  const modal = document.getElementById("edit-modal");
  const panels = Array.from(document.querySelectorAll(".edit-panel"));
  const alertBox = document.getElementById("edit-alert");
  const stepBtns = Array.from(document.querySelectorAll(".edit-step"));

  // Modal primary buttons: Next (multi-step), Save, Cancel/Close.
  const nextBtn = document.getElementById("edit-next-btn");
  const saveBtn = document.getElementById("edit-save-btn");
  const cancelBtn = document.getElementById("edit-cancel-btn");

  // Any element inside modal with data-close="true" closes the modal.
  const closeTriggers = modal
    ? Array.from(modal.querySelectorAll("[data-close='true']"))
    : [];

  // Step 1 inputs (shared), plus teacher-only inputs (experience/duration).
  const inpFirstName = document.getElementById("edit-firstName");
  const inpLastName = document.getElementById("edit-lastName");
  const inpPhone = document.getElementById("edit-phone");
  const inpCity = document.getElementById("edit-city");
  const inpExperience = document.getElementById("edit-experience");
  const inpDuration = document.getElementById("edit-duration");

  // Rows that should appear only for teachers in the edit modal.
  const teacherExpRow = document.getElementById("teacher-exp-row");
  const teacherDurRow = document.getElementById("teacher-dur-row");

  // Teacher subjects UI (list + "add subject" inputs/button).
  const subjectsListEl = document.getElementById("subjects-list");
  const newSubjectName = document.getElementById("new-subject-name");
  const newSubjectPrice = document.getElementById("new-subject-price");
  const addSubjectBtn = document.getElementById("add-subject-btn");

  // Teacher exceptions UI (date/type/start/end + list rendering).
  const exDate = document.getElementById("ex-date");
  const exType = document.getElementById("ex-type");
  const exStart = document.getElementById("ex-start");
  const exEnd = document.getElementById("ex-end");
  const exAddBtn = document.getElementById("ex-add-btn");
  const exAlert = document.getElementById("ex-alert");
  const exList = document.getElementById("exceptions-list");

  // Weekday mapping helpers (UI keys <-> numeric day_of_week used by API).
  const DAY_TO_NUM = { sun: 0, mon: 1, tue: 2, wed: 3, thu: 4, fri: 5, sat: 6 };
  const NUM_TO_DAY = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];

  // Runtime state: current user, wizard step, and role flag.
  let currentUser = null;
  let activeStep = 1;
  let isTeacher = false;

  // Draft buffers for edit modal (subjects/exceptions/availability before saving).
  let subjectsDraft = [];
  let exceptionsDraft = [];
  let availabilityDraft = [];

  // Tiny DOM helpers (safe set text/display if element exists).
  const setText = (el, txt) => { if (el) el.textContent = txt; };
  const setDisplay = (el, value) => { if (el) el.style.display = value; };

  // ======================================================
  // ✅ API base
  // ======================================================
  // Centralizes API base path and builds consistent endpoint URLs.
  const API_BASE = "/api";
  const apiUrl = (path) => `${API_BASE}${path.startsWith("/") ? path : `/${path}`}`;

  // ======================================================
  // HTML escape
  // ======================================================
  // Escapes user-controlled strings to prevent HTML injection in templates.
  function escapeHtml(str) {
    return String(str ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  // ======================================================
  // Layout helpers
  // ======================================================
  // Shows the "not logged in/no user" state and hides profile layout.
  function showNoUser() {
    setDisplay(noUserCard, "block");
    setDisplay(layout, "none");
  }

  // Shows the profile layout and hides the "no user" card.
  function showLayout() {
    setDisplay(noUserCard, "none");
    setDisplay(layout, "grid");
  }

  // Opens the edit modal and locks background scroll (via body class).
  function openModal() {
    if (!modal) return;
    modal.classList.add("is-open");
    modal.setAttribute("aria-hidden", "false");
    document.body.classList.add("modal-open");
  }

  // Closes the edit modal and resets UI feedback (alerts + errors).
  function closeModal() {
    if (!modal) return;
    modal.classList.remove("is-open");
    modal.setAttribute("aria-hidden", "true");
    document.body.classList.remove("modal-open");
    hideAlert();
    clearErrors();
  }

  // Displays an inline modal alert message.
  function showAlert(msg) {
    if (!alertBox) return;
    alertBox.style.display = "block";
    alertBox.textContent = msg;
  }

  // Hides and clears the modal alert area.
  function hideAlert() {
    if (!alertBox) return;
    alertBox.style.display = "none";
    alertBox.textContent = "";
  }

  // Clears step-1 validation messages (simple text placeholders).
  function clearErrors() {
    const ids = ["err-firstName", "err-lastName", "err-phone", "err-city", "err-experience", "err-duration"];
    ids.forEach((id) => {
      const el = document.getElementById(id);
      if (el) el.textContent = "";
    });
  }

  // Sets a specific error message under a field by element id.
  function setError(id, msg) {
    const el = document.getElementById(id);
    if (el) el.textContent = msg;
  }

  // ======================================================
  // Date/time helpers
  // ======================================================
  // Normalizes various date inputs into "YYYY-MM-DD" (or empty string).
  function normalizeISODate(val) {
    if (val === undefined || val === null) return "";
    if (val instanceof Date && !isNaN(val.getTime())) {
      const y = val.getFullYear();
      const m = String(val.getMonth() + 1).padStart(2, "0");
      const d = String(val.getDate()).padStart(2, "0");
      return `${y}-${m}-${d}`;
    }
    const s = String(val).trim();
    if (!s) return "";
    if (/^\d{4}-\d{2}-\d{2}/.test(s)) return s.slice(0, 10);
    const m = s.match(/^(\d{1,2})[.\-/](\d{1,2})[.\-/](\d{4})$/);
    if (m) {
      const dd = String(Number(m[1])).padStart(2, "0");
      const mm = String(Number(m[2])).padStart(2, "0");
      const yy = String(m[3]);
      return `${yy}-${mm}-${dd}`;
    }
    return "";
  }

  // Formats "YYYY-MM-DD" into Israeli display "DD/MM/YYYY".
  function fmtDateHeb(iso) {
    const [y, m, d] = String(iso || "").split("-").map(Number);
    if (!y || !m || !d) return iso || "";
    return `${String(d).padStart(2, "0")}/${String(m).padStart(2, "0")}/${y}`;
  }

  // Converts lesson mode enum into a Hebrew label for UI.
  function modeLabel(mode) {
    if (mode === "online") return "מקוון";
    if (mode === "frontal") return "פרונטלי";
    return "מקוון / פרונטלי";
  }

  // Converts booking status into a Hebrew label for UI.
  function statusLabel(status) {
    if (status === "cancelled") return "בוטל";
    if (status === "confirmed") return "מאושר";
    return status || "—";
  }

  // ======================================================
  // ✅ Safe fetch helper
  // ======================================================
  // Fetch wrapper: always includes cookies, disables cache, returns parsed JSON if possible.
  async function fetchJson(url, options = {}) {
    const res = await fetch(url, {
      credentials: "include",
      cache: "no-store",
      headers: { Accept: "application/json", ...(options.headers || {}) },
      ...options,
    });

    const text = await res.text().catch(() => "");
    let data = null;
    try { data = text ? JSON.parse(text) : null; } catch (_) { data = null; }

    return { res, data, text };
  }

  // Tries multiple endpoints until one isn't 404 (helps when routes differ).
  async function fetchFirstOk(endpoints) {
    for (const ep of endpoints) {
      const { res, data } = await fetchJson(`${ep}?ts=${Date.now()}`);
      if (res.status === 404) continue;
      return { res, data, endpoint: ep };
    }
    const { res, data } = await fetchJson(`${endpoints[0]}?ts=${Date.now()}`);
    return { res, data, endpoint: endpoints[0] };
  }

  // ======================================================
  // Banner
  // ======================================================
  // Permanently hides the availability banner for this session.
  function hideAvailabilityBannerForever() {
    try { sessionStorage.removeItem("showAvailabilityBanner"); } catch (_) { }
    if (availabilityBanner) availabilityBanner.hidden = true;
  }

  // Renders the banner HTML and wires its buttons (go to step 3 or dismiss).
  function showAvailabilityBanner() {
    if (!availabilityBanner) return;

    availabilityBanner.innerHTML = `
      <strong>כמעט סיימנו 🎉</strong>
      <p>כדי שתלמידים יוכלו להזמין שיעור איתך- צריך לעדכן זמינות. לחצ/י על ״ערוך פרטים" </p>
      <div class="banner-actions">
        <button type="button" class="btn-primary" id="go-edit-profile">עדכון זמינות</button>
        <button type="button" class="btn-secondary" id="dismiss-banner">הבנתי</button>
      </div>
    `;

    availabilityBanner.hidden = false;

    const goBtn = document.getElementById("go-edit-profile");
    if (goBtn) {
      goBtn.addEventListener("click", () => {
        prefillModalFromCurrentUser();
        openModal();
        if (isTeacher) setActiveStep(3);
        hideAvailabilityBannerForever();
      });
    }

    const disBtn = document.getElementById("dismiss-banner");
    if (disBtn) disBtn.addEventListener("click", hideAvailabilityBannerForever);
  }

  // Decides whether to show the banner: only for teachers with no availability.
  function maybeShowAvailabilityBanner() {
    let shouldShow = false;
    try { shouldShow = sessionStorage.getItem("showAvailabilityBanner") === "true"; } catch (_) { }
    if (!shouldShow) return;
    if (currentUser?.role !== "teacher") return;

    const hasAvailability = Array.isArray(currentUser.availability) && currentUser.availability.length > 0;
    if (hasAvailability) {
      hideAvailabilityBannerForever();
      return;
    }

    showAvailabilityBanner();
  }

  // ======================================================
  // Future lessons (student + teacher)
  // ======================================================
  // Sets the section title depending on role (teacher sees booked-to-me label).
  function setFutureTitleByRole() {
    const titleEl = document.getElementById("future");
    if (!titleEl || !currentUser) return;
    titleEl.textContent = currentUser.role === "teacher" ? "שיעורים שהוזמנו אליי" : "שיעורים עתידיים";
  }

  // Loads future lessons from role-specific endpoint and renders cards.
  async function loadFutureLessons() {
    if (!futureListEl || !futureEmptyEl) return;
    if (!currentUser) return;

    try {
      setFutureTitleByRole();

      // Picks endpoint based on role (student vs teacher).
      const endpoint =
        currentUser.role === "teacher"
          ? apiUrl("/bookings/teacher/future")
          : apiUrl("/bookings/future");

      const { res, data } = await fetchJson(`${endpoint}?ts=${Date.now()}`);

      // If not logged in, redirect to login.
      if (res.status === 401) {
        window.location.replace("/pages/login/login.html");
        return;
      }

      // Handles server errors / unexpected payloads.
      if (!res.ok || !data?.ok) {
        futureEmptyEl.style.display = "block";
        futureEmptyEl.textContent = "לא הצלחתי לטעון שיעורים.";
        futureListEl.innerHTML = "";
        return;
      }

      // Empty state if there are no lessons.
      const lessons = Array.isArray(data.lessons) ? data.lessons : [];
      if (!lessons.length) {
        futureEmptyEl.style.display = "block";
        futureEmptyEl.textContent =
          currentUser.role === "teacher" ? "אין שיעורים שהוזמנו עדיין." : "אין שיעורים עתידיים.";
        futureListEl.innerHTML = "";
        return;
      }

      futureEmptyEl.style.display = "none";

      // Optional highlight of "last booked" lesson using sessionStorage.
      const highlightId = Number(sessionStorage.getItem("lastBookingId") || "");
      if (highlightId) sessionStorage.removeItem("lastBookingId");

      const isTeacherView = currentUser.role === "teacher";

      // Builds HTML cards for each lesson; student view includes a cancel button.
      futureListEl.innerHTML = lessons
        .map((l) => {
          const isHi = highlightId && Number(l.booking_id) === highlightId;

          const title = isTeacherView
            ? `${l.student_first_name || ""} ${l.student_last_name || ""}`.trim() || "תלמיד/ה"
            : `${l.teacher_first_name || ""} ${l.teacher_last_name || ""}`.trim() || "מורה";

          const extraLine = isTeacherView && l.student_email
            ? `<div><strong>אימייל תלמיד/ה:</strong> ${escapeHtml(l.student_email)}</div>`
            : "";

          const actionsHtml = !isTeacherView
            ? `
              <div style="margin-top:10px;">
                <button type="button"
                        class="btn-secondary booking-cancel"
                        data-booking-id="${Number(l.booking_id)}">
                  ביטול
                </button>
              </div>
            `
            : "";

          return `
            <article class="teacher-card"
                     style="margin-top:12px; ${isHi ? "outline:2px solid #2aa6c7; box-shadow:0 0 0 4px rgba(42,166,199,0.15);" : ""}"
                     data-booking-id="${Number(l.booking_id)}">
              <div class="teacher-card-header">
                <h3>${escapeHtml(title)}</h3>
              </div>

              <div style="display:grid; gap:6px; padding: 6px 0;">
                ${extraLine}
                <div><strong>מקצוע:</strong> ${escapeHtml(l.subject_name)}</div>
                <div><strong>תאריך:</strong> ${fmtDateHeb(l.lesson_date)}</div>
                <div><strong>שעה:</strong> ${escapeHtml(l.start_time)}</div>
                <div><strong>משך:</strong> ${Number(l.duration_minutes)} דק׳</div>
                <div><strong>מחיר לשעה:</strong> ${Number(l.price_per_hour)} ₪</div>
                <div><strong>אופן שיעור:</strong> ${modeLabel(l.lesson_mode)}</div>
                <div><strong>סטטוס:</strong> ${statusLabel(l.status)}</div>
                ${actionsHtml}
              </div>
            </article>
          `;
        })
        .join("");
    } catch (err) {
      // Network fallback for future lessons.
      console.error("loadFutureLessons error:", err);
      futureEmptyEl.style.display = "block";
      futureEmptyEl.textContent = "שגיאת רשת בטעינת שיעורים.";
      futureListEl.innerHTML = "";
    }
  }

  // Handles click on "cancel booking" (student-only, delegated listener).
  if (futureListEl) {
    futureListEl.addEventListener("click", async (e) => {
      const btn = e.target.closest(".booking-cancel");
      if (!btn) return;

      const bookingId = btn.getAttribute("data-booking-id");
      if (!bookingId) return;

      // Simple confirmation before cancel.
      const ok = confirm("לבטל את השיעור הזה?");
      if (!ok) return;

      // Temporary button loading state.
      btn.disabled = true;
      const prevText = btn.textContent;
      btn.textContent = "מבטל...";

      try {
        // Calls cancel endpoint and refreshes lists on success.
        const { res, data } = await fetchJson(apiUrl(`/bookings/${encodeURIComponent(bookingId)}/cancel`), {
          method: "PUT",
        });

        if (res.status === 401) {
          window.location.replace("/pages/login/login.html");
          return;
        }

        if (!res.ok || !data?.ok) {
          alert(data?.message || "לא הצלחתי לבטל את השיעור.");
        } else {
          await loadFutureLessons();
          await loadHistoryLessons();
        }
      } catch (err) {
        // Network fallback for cancel request.
        console.error("cancel booking error:", err);
        alert("שגיאת רשת בביטול השיעור.");
      } finally {
        // Restore button state.
        btn.disabled = false;
        btn.textContent = prevText || "ביטול";
      }
    });
  }

  // ======================================================
  // History lessons (student + teacher)
  // ======================================================
  // Sets the history section title (currently same for both roles).
  function setHistoryTitleByRole() {
    const titleEl = document.getElementById("history");
    if (!titleEl || !currentUser) return;
    titleEl.textContent = currentUser.role === "teacher" ? "היסטוריית שיעורים" : "היסטוריית שיעורים";
  }

  // Loads past lessons from role-specific endpoint and renders cards.
  async function loadHistoryLessons() {
    if (!historyListEl || !historyEmptyEl) return;
    if (!currentUser) return;

    try {
      setHistoryTitleByRole();

      // Ensures the history section is visible.
      if (historySection) historySection.style.display = "block";

      // Teacher flow: fixed endpoint for teacher past lessons.
      if (currentUser.role === "teacher") {
        const endpoint = apiUrl("/bookings/teacher/past");
        const { res, data } = await fetchJson(`${endpoint}?ts=${Date.now()}`);

        if (res.status === 401) {
          window.location.replace("/pages/login/login.html");
          return;
        }

        if (!res.ok || !data?.ok) {
          historyEmptyEl.style.display = "block";
          historyEmptyEl.textContent = "לא הצלחתי לטעון היסטוריה.";
          historyListEl.innerHTML = "";
          return;
        }

        const lessons = Array.isArray(data.lessons) ? data.lessons : [];
        if (!lessons.length) {
          historyEmptyEl.style.display = "block";
          historyEmptyEl.textContent = "אין שיעורים בהיסטוריה עדיין.";
          historyListEl.innerHTML = "";
          return;
        }

        historyEmptyEl.style.display = "none";

        // Teacher history cards include student identity and email if available.
        historyListEl.innerHTML = lessons
          .map((l) => {
            const studentName = `${l.student_first_name || ""} ${l.student_last_name || ""}`.trim() || "תלמיד/ה";
            const extraLine = l.student_email
              ? `<div><strong>אימייל תלמיד/ה:</strong> ${escapeHtml(l.student_email)}</div>`
              : "";

            return `
              <article class="teacher-card" style="margin-top:12px;" data-booking-id="${Number(l.booking_id)}">
                <div class="teacher-card-header">
                  <h3>${escapeHtml(studentName)}</h3>
                </div>

                <div style="display:grid; gap:6px; padding: 6px 0;">
                  ${extraLine}
                  <div><strong>מקצוע:</strong> ${escapeHtml(l.subject_name)}</div>
                  <div><strong>תאריך:</strong> ${fmtDateHeb(l.lesson_date)}</div>
                  <div><strong>שעה:</strong> ${escapeHtml(l.start_time)}</div>
                  <div><strong>משך:</strong> ${Number(l.duration_minutes)} דק׳</div>
                  <div><strong>מחיר לשעה:</strong> ${Number(l.price_per_hour)} ₪</div>
                  <div><strong>אופן שיעור:</strong> ${modeLabel(l.lesson_mode)}</div>
                  <div><strong>סטטוס:</strong> ${statusLabel(l.status)}</div>
                </div>
              </article>
            `;
          })
          .join("");

        return;
      }

      // Student flow: tries two possible endpoints (past/history) for compatibility.
      const candidates = [
        apiUrl("/bookings/past"),
        apiUrl("/bookings/history"),
      ];

      const { res, data } = await fetchFirstOk(candidates);

      if (res.status === 401) {
        window.location.replace("/pages/login/login.html");
        return;
      }

      if (!res.ok || !data?.ok) {
        historyEmptyEl.style.display = "block";
        historyEmptyEl.textContent = "לא הצלחתי לטעון היסטוריה.";
        historyListEl.innerHTML = "";
        return;
      }

      const lessons = Array.isArray(data.lessons) ? data.lessons : [];
      if (!lessons.length) {
        historyEmptyEl.style.display = "block";
        historyEmptyEl.textContent = "אין שיעורים בהיסטוריה עדיין.";
        historyListEl.innerHTML = "";
        return;
      }

      historyEmptyEl.style.display = "none";

      // Student history cards include teacher identity and lesson details.
      historyListEl.innerHTML = lessons
        .map((l) => {
          const teacherName = `${l.teacher_first_name || ""} ${l.teacher_last_name || ""}`.trim() || "מורה";
          return `
            <article class="teacher-card" style="margin-top:12px;" data-booking-id="${Number(l.booking_id)}">
              <div class="teacher-card-header">
                <h3>${escapeHtml(teacherName)}</h3>
              </div>

              <div style="display:grid; gap:6px; padding: 6px 0;">
                <div><strong>מקצוע:</strong> ${escapeHtml(l.subject_name)}</div>
                <div><strong>תאריך:</strong> ${fmtDateHeb(l.lesson_date)}</div>
                <div><strong>שעה:</strong> ${escapeHtml(l.start_time)}</div>
                <div><strong>משך:</strong> ${Number(l.duration_minutes)} דק׳</div>
                <div><strong>מחיר לשעה:</strong> ${Number(l.price_per_hour)} ₪</div>
                <div><strong>אופן שיעור:</strong> ${modeLabel(l.lesson_mode)}</div>
                <div><strong>סטטוס:</strong> ${statusLabel(l.status)}</div>
              </div>
            </article>
          `;
        })
        .join("");
    } catch (err) {
      // Network fallback for history lessons.
      console.error("loadHistoryLessons error:", err);
      historyEmptyEl.style.display = "block";
      historyEmptyEl.textContent = "שגיאת רשת בטעינת היסטוריה.";
      historyListEl.innerHTML = "";
    }
  }

  // ======================================================
  // Favorites (student only)
  // ======================================================
  // Loads favorites list for students, renders cards, and wires remove/book actions.
  async function loadFavorites() {
    if (!ui.favoritesSection) return;
    if (!currentUser || currentUser.role !== "student") return;

    try {
      const { res, data } = await fetchJson(`${apiUrl("/favorites")}?ts=${Date.now()}`);

      if (res.status === 401) {
        window.location.replace("/pages/login/login.html");
        return;
      }

      if (!res.ok || !data?.ok) {
        ui.favoritesSection.innerHTML = `
          <h2>המועדפים שלי</h2>
          <p class="empty-state">לא הצלחתי לטעון מועדפים.</p>
        `;
        return;
      }

      const favs = Array.isArray(data.favorites) ? data.favorites : [];

      // Empty state when there are no favorites.
      if (!favs.length) {
        ui.favoritesSection.innerHTML = `
          <h2>המועדפים שלי</h2>
          <p class="empty-state">עדיין לא שמרת מורים למועדפים.</p>
        `;
        return;
      }

      // Builds favorite teacher cards with subjects/prices and action buttons.
      const cards = favs
        .map((t) => {
          const id = t.user_id;
          const name = t.fullName || "מורה";

          const subjects = Array.isArray(t.subjects) ? t.subjects : [];
          const subjectsHtml = subjects.length
            ? `
              <div class="fav-subjects" style="margin-top:8px; display:grid; gap:6px;">
                ${subjects
              .map((s) => {
                const dur = Number(s.duration_minutes || 0);
                const durLabel = dur > 0 ? `ל־${dur} דק׳` : "לשיעור";
                return `
                      <div class="fav-subject-row" style="display:flex; justify-content:space-between; gap:10px;">
                        <span>${escapeHtml(s.subject_name)}</span>
                        <span><strong>${Number(s.price_per_hour)}₪</strong> ${durLabel}</span>
                      </div>
                    `;
              })
              .join("")}
              </div>
            `
            : `<p class="empty-state" style="margin-top:8px;">לא הוגדרו מקצועות למורה.</p>`;

          return `
            <article class="teacher-card" style="margin-top:12px;">
              <div class="teacher-card-header">
                <h3>${escapeHtml(name)}</h3>
              </div>

              ${subjectsHtml}

              <div class="teacher-actions" style="margin-top:12px;">
                <button type="button" class="btn-secondary fav-remove" data-teacher-id="${escapeHtml(id)}">
                  הסר ממועדפים
                </button>
                <button type="button" class="btn-primary fav-book" data-teacher-id="${escapeHtml(id)}">
                  בדוק זמינות
                </button>
              </div>
            </article>
          `;
        })
        .join("");

      // Writes the favorites section and attaches handlers for remove/book.
      ui.favoritesSection.innerHTML = `
        <h2>המועדפים שלי</h2>
        ${cards}
      `;

      // Remove favorite -> DELETE + reload list.
      ui.favoritesSection.querySelectorAll(".fav-remove").forEach((btn) => {
        btn.addEventListener("click", async () => {
          const teacherId = btn.getAttribute("data-teacher-id");
          await fetchJson(apiUrl(`/favorites/${encodeURIComponent(teacherId)}`), {
            method: "DELETE",
          });
          await loadFavorites();
        });
      });

      // Book from favorites -> go to booking page with teacherId in query.
      ui.favoritesSection.querySelectorAll(".fav-book").forEach((btn) => {
        btn.addEventListener("click", () => {
          const teacherId = btn.getAttribute("data-teacher-id");
          window.location.href = `../book/book.html?teacherId=${encodeURIComponent(teacherId)}`;
        });
      });
    } catch (err) {
      // Network fallback for favorites.
      console.error("loadFavorites error:", err);
      ui.favoritesSection.innerHTML = `
        <h2>המועדפים שלי</h2>
        <p class="empty-state">שגיאת רשת בטעינת מועדפים.</p>
      `;
    }
  }

  // ======================================================
  // Phone helpers
  // ======================================================
  // Strips all non-digit characters from a string.
  function toDigits(str) {
    return String(str || "").replace(/\D/g, "");
  }

  // Validates Israeli mobile numbers: 05 + 8 digits (total 10).
  function isValidIsraeliMobile(phoneDigits) {
    return /^05\d{8}$/.test(phoneDigits);
  }

  // Validates and optionally normalizes the phone input to digits only.
  function validatePhoneField({ normalize = true } = {}) {
    const raw = (inpPhone?.value || "").trim();
    const digits = toDigits(raw);

    if (normalize && inpPhone) inpPhone.value = digits;

    if (!digits) {
      setError("err-phone", "חובה להזין טלפון");
      return false;
    }
    if (!isValidIsraeliMobile(digits)) {
      setError("err-phone", "טלפון חייב להתחיל ב־05 ולהכיל בדיוק 10 ספרות");
      return false;
    }

    setError("err-phone", "");
    return true;
  }

  // ======================================================
  // Steps UI
  // ======================================================
  // Activates a wizard step and toggles correct panels/buttons (teacher vs student).
  function setActiveStep(step) {
    activeStep = step;

    stepBtns.forEach((b) => b.classList.toggle("is-active", Number(b.dataset.step) === step));
    panels.forEach((p) => p.classList.toggle("is-active", Number(p.dataset.panel) === step));

    if (isTeacher) {
      if (step < 3) {
        if (nextBtn) nextBtn.style.display = "inline-flex";
        if (saveBtn) saveBtn.style.display = "none";
      } else {
        if (nextBtn) nextBtn.style.display = "none";
        if (saveBtn) saveBtn.style.display = "inline-flex";
      }
    } else {
      if (nextBtn) nextBtn.style.display = "none";
      if (saveBtn) saveBtn.style.display = "inline-flex";
    }
  }

  // Shows/hides teacher-only steps and rows, and resets to step 1 for students.
  function toggleTeacherSteps(teacher) {
    isTeacher = teacher;

    if (teacherExpRow) teacherExpRow.style.display = teacher ? "block" : "none";
    if (teacherDurRow) teacherDurRow.style.display = teacher ? "block" : "none";

    const step2Btn = document.getElementById("step-teacher-2");
    const step3Btn = document.getElementById("step-teacher-3");

    if (step2Btn) step2Btn.style.display = teacher ? "inline-flex" : "none";
    if (step3Btn) step3Btn.style.display = teacher ? "inline-flex" : "none";

    if (!teacher) setActiveStep(1);
  }

  // ======================================================
  // Render user
  // ======================================================
  // Renders profile header and toggles sections based on user role.
  function renderUser(u) {
    showLayout();

    // Teacher city row is displayed only for teacher role.
    const teacherCityRow = document.getElementById("teacher-city-row");
    if (u.role === "teacher") {
      if (teacherCityRow) teacherCityRow.style.display = "block";
    } else {
      if (teacherCityRow) teacherCityRow.style.display = "none";
    }

    // Basic identity info.
    const fullName = `${u.first_name || ""} ${u.last_name || ""}`.trim();
    const first = (fullName.split(" ")[0] || "").trim() || "🙂";

    setText(ui.greetingEl, `שלום ${first},`);
    setText(ui.nameEl, fullName || "—");
    setText(ui.emailEl, u.email || "—");

    // Role-specific UI: teacher shows subjects/experience; student shows favorites.
    if (u.role === "teacher") {
      setText(ui.rolePill, "מורה");
      if (ui.favoritesSection) ui.favoritesSection.style.display = "none";

      const subjectsText =
        u.subjects && u.subjects.length
          ? u.subjects
            .map((s) => `${s.subject ?? s.subject_name} (${s.price ?? s.price_per_hour}₪)`)
            .join(", ")
          : "טרם הוגדרו מקצועות";

      const expText =
        u.years_experience !== null && u.years_experience !== undefined
          ? ` • ${u.years_experience} שנות ניסיון`
          : "";

      setText(ui.fieldEl, subjectsText + expText);

      if (futureSection) futureSection.style.display = "block";
      if (historySection) historySection.style.display = "block";
    } else {
      setText(ui.rolePill, "תלמיד/ה");
      if (ui.favoritesSection) ui.favoritesSection.style.display = "block";
      setText(ui.fieldEl, "פרופיל תלמיד/ה");

      if (futureSection) futureSection.style.display = "block";
      if (historySection) historySection.style.display = "block";
    }
  }

  // ======================================================
  // Subjects helpers
  // ======================================================
  // Normalizes subjects from server shape into the local draft shape.
  function normalizeSubjectsFromServer(serverUser) {
    const arr = Array.isArray(serverUser.subjects) ? serverUser.subjects : [];
    return arr
      .map((s) => ({
        subject_name: s.subject ?? s.subject_name ?? "",
        price_per_hour: Number(s.price ?? s.price_per_hour ?? 0),
        duration_minutes: Number(s.duration_minutes ?? 0),
      }))
      .filter((x) => x.subject_name.trim());
  }

  // Renders the subjectsDraft list and wires remove buttons.
  function renderSubjectsDraft() {
    if (!subjectsListEl) return;
    subjectsListEl.innerHTML = "";

    if (!subjectsDraft.length) {
      const p = document.createElement("p");
      p.className = "edit-hint";
      p.style.margin = "0";
      p.textContent = "אין תחומים שהוגדרו עדיין.";
      subjectsListEl.appendChild(p);
      return;
    }

    subjectsDraft.forEach((s, idx) => {
      const row = document.createElement("div");
      row.className = "subject-row";

      const text = document.createElement("div");
      text.className = "subject-row__text";
      text.textContent = `${s.subject_name} • ${s.price_per_hour}₪ • ${s.duration_minutes} דק׳`;

      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "btn-secondary subject-row__remove";
      remove.textContent = "❌";
      remove.addEventListener("click", () => {
        subjectsDraft.splice(idx, 1);
        renderSubjectsDraft();
      });

      row.appendChild(text);
      row.appendChild(remove);
      subjectsListEl.appendChild(row);
    });
  }

  // Validates new subject inputs and pushes a new subject into the draft list.
  function addSubjectFromInputs() {
    hideAlert();

    const name = (newSubjectName?.value || "").trim();
    const price = Number(newSubjectPrice?.value || "");
    const defaultDur = Number(inpDuration?.value || 0);

    if (!name) return showAlert("יש להזין תחום לימוד.");
    if (!Number.isFinite(price) || price <= 0) return showAlert("יש להזין מחיר תקין (> 0).");
    if (!Number.isFinite(defaultDur) || defaultDur <= 0)
      return showAlert("יש להזין משך שיעור תקין בשלב 1 (בדקות).");

    const exists = subjectsDraft.some((s) => s.subject_name === name);
    if (exists) return showAlert("התחום כבר קיים ברשימה.");

    subjectsDraft.push({
      subject_name: name,
      price_per_hour: price,
      duration_minutes: defaultDur,
    });

    if (newSubjectName) newSubjectName.value = "";
    if (newSubjectPrice) newSubjectPrice.value = "";

    renderSubjectsDraft();
  }

  // Keeps all subjects duration in sync with the "default duration" input.
  function syncSubjectsDurationFromInput() {
    if (!isTeacher) return;
    const defaultDur = Number(inpDuration?.value || 0);
    if (!Number.isFinite(defaultDur) || defaultDur <= 0) return;

    subjectsDraft = (Array.isArray(subjectsDraft) ? subjectsDraft : []).map((s) => ({
      ...s,
      duration_minutes: defaultDur,
    }));
    renderSubjectsDraft();
  }

  // ======================================================
  // Exceptions helpers
  // ======================================================
  // Shows/hides the exceptions alert area inside the modal.
  function setExAlert(msg = "") {
    if (!exAlert) return;
    exAlert.style.display = msg ? "block" : "none";
    exAlert.textContent = msg;
  }

  // Simple validation: start time must be before end time.
  function isTimeOrderOk(start, end) {
    return start && end && start < end;
  }

  // Renders exceptionsDraft as rows (sorted by date) with remove buttons.
  function renderExceptions() {
    if (!exList) return;
    exList.innerHTML = "";

    if (!exceptionsDraft.length) {
      const p = document.createElement("p");
      p.className = "edit-hint";
      p.style.margin = "0";
      p.textContent = "אין חריגות שהוגדרו עדיין.";
      exList.appendChild(p);
      return;
    }

    exceptionsDraft
      .slice()
      .sort((a, b) => String(a.date).localeCompare(String(b.date)))
      .forEach((ex, idx) => {
        const row = document.createElement("div");
        row.className = "subject-row";

        const text = document.createElement("div");
        text.className = "subject-row__text";

        if (ex.type === "off") {
          text.textContent = `${ex.date} • לא זמין`;
        } else {
          text.textContent = `${ex.date} • זמינות מיוחדת: ${ex.start_time}–${ex.end_time}`;
        }

        const remove = document.createElement("button");
        remove.type = "button";
        remove.className = "btn-secondary subject-row__remove";
        remove.textContent = "❌";
        remove.addEventListener("click", () => {
          exceptionsDraft.splice(idx, 1);
          renderExceptions();
        });

        row.appendChild(text);
        row.appendChild(remove);
        exList.appendChild(row);
      });
  }

  // Enables/disables time inputs depending on exception type (off vs custom).
  function syncTimeInputsByType() {
    if (!exType || !exStart || !exEnd) return;
    const t = exType.value;

    const isCustom = t === "custom";
    exStart.disabled = !isCustom;
    exEnd.disabled = !isCustom;

    if (!isCustom) {
      exStart.value = "";
      exEnd.value = "";
    }
  }

  // Validates exception inputs and upserts (replace if same date) into exceptionsDraft.
  function addExceptionFromInputs() {
    setExAlert("");

    const rawDate = exDate?.value || "";
    const date = normalizeISODate(rawDate);
    const type = exType?.value || "off";
    const start = exStart?.value || "";
    const end = exEnd?.value || "";

    if (!date) return setExAlert("חובה לבחור תאריך תקין.");

    if (type === "custom") {
      if (!start || !end) return setExAlert("בשעות זמינות ספציפיות חובה למלא התחלה וסיום.");
      if (!isTimeOrderOk(start, end)) return setExAlert("שעת הסיום חייבת להיות אחרי שעת ההתחלה.");
    }

    const existingIdx = exceptionsDraft.findIndex((x) => x.date === date);

    const newEx = {
      date,
      type,
      start_time: type === "custom" ? start : null,
      end_time: type === "custom" ? end : null,
    };

    if (existingIdx >= 0) exceptionsDraft[existingIdx] = newEx;
    else exceptionsDraft.push(newEx);

    if (exDate) exDate.value = "";
    if (exType) exType.value = "off";
    syncTimeInputsByType();
    renderExceptions();
  }

  // ======================================================
  // Availability helpers
  // ======================================================
  // Finds availability UI controls by day key (sun/mon/...).
  function getStartEl(dayKey) {
    return document.querySelector(`input[type='time'][data-start='${dayKey}']`);
  }
  function getEndEl(dayKey) {
    return document.querySelector(`input[type='time'][data-end='${dayKey}']`);
  }
  function getCheckEl(dayKey) {
    return document.querySelector(`input[type='checkbox'][data-day='${dayKey}']`);
  }

  // Enables/disables a day row based on checkbox, and clears times when disabled.
  function syncDayRowUI(dayKey) {
    const cb = getCheckEl(dayKey);
    const st = getStartEl(dayKey);
    const en = getEndEl(dayKey);
    if (!cb || !st || !en) return;

    const enabled = cb.checked;
    st.disabled = !enabled;
    en.disabled = !enabled;

    if (!enabled) {
      st.value = "";
      en.value = "";
    }
  }

  // Reads weekly availability from UI and validates required times.
  function readAvailabilityFromUI() {
    const out = [];

    for (const dayKey of Object.keys(DAY_TO_NUM)) {
      const cb = getCheckEl(dayKey);
      const st = getStartEl(dayKey);
      const en = getEndEl(dayKey);
      if (!cb || !st || !en) continue;

      if (!cb.checked) continue;

      const startVal = (st.value || "").trim();
      const endVal = (en.value || "").trim();

      if (!startVal || !endVal) {
        showAlert("בזמינות שבועית: אם יום מסומן כזמין חייבים לבחור שעות התחלה וסיום.");
        return null;
      }
      if (!(startVal < endVal)) {
        showAlert("בזמינות שבועית: שעת הסיום חייבת להיות אחרי שעת ההתחלה.");
        return null;
      }

      out.push({
        day_of_week: DAY_TO_NUM[dayKey],
        start_time: startVal,
        end_time: endVal,
      });
    }

    return out;
  }

  // Applies availability list from server into the UI (one range per day).
  function applyAvailabilityToUI(list) {
    for (const dayKey of Object.keys(DAY_TO_NUM)) {
      const cb = getCheckEl(dayKey);
      if (cb) cb.checked = false;
      syncDayRowUI(dayKey);
    }

    const arr = Array.isArray(list) ? list : [];
    const firstPerDay = new Map();

    // Keeps only the first valid availability range per day_of_week.
    for (const a of arr) {
      const dow = Number(a.day_of_week);
      if (!Number.isFinite(dow) || dow < 0 || dow > 6) continue;
      if (firstPerDay.has(dow)) continue;

      const st = String(a.start_time || "").slice(0, 5);
      const en = String(a.end_time || "").slice(0, 5);
      if (!st || !en || !(st < en)) continue;

      firstPerDay.set(dow, { day_of_week: dow, start_time: st, end_time: en });
    }

    // Writes checkbox + times into the matching day row.
    for (const a of Array.from(firstPerDay.values())) {
      const dayKey = NUM_TO_DAY[a.day_of_week];
      const cb = getCheckEl(dayKey);
      const st = getStartEl(dayKey);
      const en = getEndEl(dayKey);
      if (!cb || !st || !en) continue;

      cb.checked = true;
      syncDayRowUI(dayKey);
      st.value = a.start_time;
      en.value = a.end_time;
    }
  }

  // ======================================================
  // Validation
  // ======================================================
  // Validates step 1 fields (and teacher-only fields if teacher).
  function validateStep1() {
    clearErrors();
    hideAlert();

    const firstName = (inpFirstName?.value || "").trim();
    const lastName = (inpLastName?.value || "").trim();

    let ok = true;

    if (!firstName) { setError("err-firstName", "חובה להזין שם פרטי"); ok = false; }
    if (!lastName) { setError("err-lastName", "חובה להזין שם משפחה"); ok = false; }

    if (!validatePhoneField({ normalize: true })) ok = false;

    if (isTeacher) {
      const years = Number(inpExperience?.value || 0);
      const dur = Number(inpDuration?.value || 0);

      if (!Number.isFinite(years) || years < 0) { setError("err-experience", "שנות ניסיון חייב להיות מספר תקין"); ok = false; }
      if (!Number.isFinite(dur) || dur <= 0) { setError("err-duration", "משך שיעור חייב להיות מספר תקין (>0)"); ok = false; }
    }

    return ok;
  }

  // ======================================================
  // ✅ Load user
  // ======================================================
  // Loads the current logged-in user, renders UI, and loads related data (favorites/lessons).
  async function loadMe() {
    try {
      const { res, data } = await fetchJson(`${apiUrl("/me")}?ts=${Date.now()}`);

      if (res.status === 401) {
        window.location.replace("/pages/login/login.html");
        return;
      }

      if (!res.ok || !data?.ok || !data?.user) {
        console.warn("loadMe failed:", { status: res.status, data });
        showNoUser();
        return;
      }

      currentUser = data.user;

      toggleTeacherSteps(currentUser.role === "teacher");
      renderUser(currentUser);

      maybeShowAvailabilityBanner();

      await loadFavorites();
      await loadFutureLessons();
      await loadHistoryLessons();

      // Supports direct navigation to sections via URL hash.
      if (window.location.hash === "#future" && futureSection) {
        futureSection.scrollIntoView({ behavior: "smooth", block: "start" });
      }
      if (window.location.hash === "#history" && historySection) {
        historySection.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    } catch (err) {
      console.error("Profile load error:", err);
      showNoUser();
    }
  }

  // ======================================================
  // Prefill modal
  // ======================================================
  // Fills the edit modal with currentUser data and builds drafts for editing.
  function prefillModalFromCurrentUser() {
    if (!currentUser) return;

    if (inpFirstName) inpFirstName.value = currentUser.first_name || "";
    if (inpLastName) inpLastName.value = currentUser.last_name || "";
    if (inpPhone) inpPhone.value = currentUser.phone || "";
    if (inpCity) inpCity.value = currentUser.city || "";

    if (isTeacher) {
      if (inpExperience) inpExperience.value = currentUser.years_experience ?? 0;

      // Chooses lesson duration from the first subject if available, else defaults.
      const durFromFirst =
        currentUser.subjects && currentUser.subjects[0]?.duration_minutes
          ? Number(currentUser.subjects[0].duration_minutes)
          : 45;

      if (inpDuration) inpDuration.value = durFromFirst;

      // Prepare subject drafts and render list.
      subjectsDraft = normalizeSubjectsFromServer(currentUser);
      renderSubjectsDraft();

      // Apply weekly availability into UI.
      availabilityDraft = Array.isArray(currentUser.availability) ? currentUser.availability : [];
      applyAvailabilityToUI(availabilityDraft);

      // Normalize exceptions into draft shape and render list.
      exceptionsDraft = (Array.isArray(currentUser.exceptions) ? currentUser.exceptions : [])
        .map((ex) => ({
          date: normalizeISODate(ex.date),
          type: ex.type,
          start_time: ex.start_time ?? null,
          end_time: ex.end_time ?? null,
        }))
        .filter((x) => !!x.date);

      renderExceptions();
    } else {
      // Students: clear teacher-only drafts.
      subjectsDraft = [];
      renderSubjectsDraft();
    }

    setActiveStep(1);
  }

  // ======================================================
  // ✅ Save profile
  // ======================================================
  // Builds the update payload (student/teacher) and sends PUT /api/me.
  async function saveProfile() {
    if (!currentUser) return;

    // Block save if validation fails.
    if (!validateStep1()) {
      showAlert("אנא תקני את השדות המסומנים לפני שמירה.");
      return;
    }

    // Base payload for all users.
    const payload = {
      first_name: (inpFirstName?.value || "").trim(),
      last_name: (inpLastName?.value || "").trim(),
      phone: toDigits(inpPhone?.value || ""),
      city: (inpCity?.value || "").trim(),
    };

    // Teacher-only payload additions: experience, subjects, availability, exceptions.
    if (isTeacher) {
      payload.years_experience = Number(inpExperience?.value || 0);
      payload.lesson_mode = currentUser.lesson_mode ?? null;

      const defaultDur = Number(inpDuration?.value || 0);

      // Enforces a single duration for all subjects based on default duration input.
      subjectsDraft = (Array.isArray(subjectsDraft) ? subjectsDraft : []).map((s) => ({
        subject_name: s.subject_name,
        price_per_hour: Number(s.price_per_hour),
        duration_minutes: defaultDur,
      }));
      payload.subjects = subjectsDraft;

      // Reads weekly availability from UI; stops save if invalid.
      const av = readAvailabilityFromUI();
      if (av === null) return;
      availabilityDraft = av;
      payload.availability = availabilityDraft;

      // Normalizes exceptions into server payload format.
      payload.exceptions = (Array.isArray(exceptionsDraft) ? exceptionsDraft : [])
        .map((ex) => ({
          date: normalizeISODate(ex.date),
          type: ex.type === "custom" ? "custom" : "off",
          start_time: ex.type === "custom" ? (ex.start_time || null) : null,
          end_time: ex.type === "custom" ? (ex.end_time || null) : null,
        }))
        .filter((ex) => !!ex.date);
    }

    try {
      // Sends update request to server.
      const { res, data, text } = await fetchJson(apiUrl("/me"), {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (res.status === 401) {
        window.location.replace("/pages/login/login.html");
        return;
      }

      // Server error handling (including phone-specific hint).
      if (!res.ok || !data?.ok) {
        const msg = data?.message || `שגיאה בעדכון פרטים (HTTP ${res.status})`;
        console.warn("saveProfile failed:", { status: res.status, data, text });
        if (msg.toLowerCase().includes("phone") || msg.includes("טלפון")) {
          setError("err-phone", "טלפון חייב להתחיל ב־05 ולהכיל בדיוק 10 ספרות");
        }
        showAlert(msg);
        return;
      }

      // On success: close modal and reload user+lists to reflect changes.
      closeModal();
      await loadMe();
    } catch (err) {
      // Network fallback for save.
      console.error("Save error:", err);
      showAlert("שגיאת תקשורת בעדכון");
    }
  }

  // ======================================================
  // Events
  // ======================================================
  // Phone input: validate on blur, enforce digits-only on input.
  if (inpPhone) {
    inpPhone.addEventListener("blur", () => {
      clearErrors();
      validatePhoneField({ normalize: true });
    });

    inpPhone.addEventListener("input", () => {
      const digits = toDigits(inpPhone.value);
      if (inpPhone.value !== digits) inpPhone.value = digits;
    });
  }

  // Duration changes: keep all subjects durations synced to the new default.
  if (inpDuration) {
    inpDuration.addEventListener("change", syncSubjectsDurationFromInput);
    inpDuration.addEventListener("blur", syncSubjectsDurationFromInput);
  }

  // Edit button: opens modal and pre-fills with current user data.
  if (editBtn) {
    editBtn.addEventListener("click", () => {
      prefillModalFromCurrentUser();
      openModal();
    });
  }

  // Modal close triggers (X buttons, overlay buttons, cancel button, Esc key).
  closeTriggers.forEach((el) => el.addEventListener("click", closeModal));
  if (cancelBtn) cancelBtn.addEventListener("click", closeModal);

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && modal?.classList.contains("is-open")) closeModal();
  });

  // Step navigation: validates step 1 before allowing teacher to move to steps 2/3.
  stepBtns.forEach((b) => {
    b.addEventListener("click", () => {
      const step = Number(b.dataset.step);
      if (!isTeacher && step !== 1) return;

      if (step === 2 || step === 3) {
        if (!validateStep1()) {
          showAlert("לפני מעבר לשלב הבא יש למלא את הפרטים בצורה תקינה.");
          return;
        }
      }
      setActiveStep(step);
    });
  });

  // "Next" button for teacher wizard: validates and moves forward.
  if (nextBtn) {
    nextBtn.addEventListener("click", () => {
      if (!isTeacher) return;

      if (!validateStep1()) {
        showAlert("לפני מעבר לשלב הבא יש למלא את הפרטים בצורה תקינה.");
        return;
      }

      if (activeStep < 3) setActiveStep(activeStep + 1);
    });
  }

  // Save and add-subject actions.
  if (saveBtn) saveBtn.addEventListener("click", saveProfile);
  if (addSubjectBtn) addSubjectBtn.addEventListener("click", addSubjectFromInputs);

  // Logout: POST to /api/logout (cookie clear) then go home.
  if (logoutBtn) {
    logoutBtn.addEventListener("click", async () => {
      try {
        await fetch(apiUrl("/logout"), { method: "POST", credentials: "include" });
      } finally {
        window.location.href = "/index.html";
      }
    });
  }

  // Exceptions events: update UI when type changes, add exception on click.
  if (exType) exType.addEventListener("change", syncTimeInputsByType);
  if (exAddBtn) exAddBtn.addEventListener("click", addExceptionFromInputs);

  // Availability checkboxes: enable/disable time inputs per day when toggled.
  const availCheckboxes = Array.from(document.querySelectorAll("input[type='checkbox'][data-day]"));
  availCheckboxes.forEach((cb) => cb.addEventListener("change", () => syncDayRowUI(cb.dataset.day)));

  // Initial UI sync: exceptions type, exceptions list, availability rows, then load user.
  syncTimeInputsByType();
  renderExceptions();
  Object.keys(DAY_TO_NUM).forEach(syncDayRowUI);

  // Initial data load (user + lessons + favorites).
  loadMe();
});
