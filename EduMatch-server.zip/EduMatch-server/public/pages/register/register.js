// public/pages/register/register.js

document.addEventListener("DOMContentLoaded", () => {

  // Loads city options into the <datalist id="cities-list"> (fallback list + optional API).
  async function loadCitiesDatalist() {
    const list = document.getElementById("cities-list");
    if (!list) return;

    const defaultCities = [
      "אור יהודה", "אופקים", "אילת", "אלעד", "אריאל", "אשדוד", "אשקלון",
      "באר יעקב", "באר שבע", "בית שמש", "בית שאן", "בני ברק", "בת ים",
      "גבעתיים", "גדרה", "דימונה", "הרצליה", "חדרה", "חולון", "חיפה",
      "טבריה", "יבנה", "יהוד-מונוסון", "ירוחם", "ירושלים",
      "כפר סבא", "כרמיאל", "לוד", "מודיעין-מכבים-רעות", "מעלה אדומים",
      "נהריה", "נס ציונה", "נצרת", "נשר", "נתיבות", "נתניה",
      "עכו", "עפולה", "ערד",
      "פתח תקווה", "צפת", "קריית אתא", "קריית גת", "קריית ים", "קריית מוצקין", "קריית שמונה",
      "ראש העין", "ראשון לציון", "רחובות", "רמלה", "רמת גן", "רמת השרון", "רעננה",
      "שדרות", "תל אביב-יפו"
    ];

    let dbCities = [];

    try {
      const res = await fetch(`/api/cities?ts=${Date.now()}`, {
        headers: { Accept: "application/json" },
        cache: "no-store",
      });

      const data = await res.json().catch(() => null);

      if (res.ok && data?.ok && Array.isArray(data.cities)) {
        dbCities = data.cities;
      }
    } catch (e) {
      console.warn("❌ cities API failed, using defaults only:", e);
    }

    const merged = Array.from(
      new Set([...defaultCities, ...dbCities].map((c) => String(c || "").trim()).filter(Boolean))
    ).sort((a, b) => a.localeCompare(b, "he"));

    list.innerHTML = "";

    const frag = document.createDocumentFragment();

    merged.forEach((city) => {
      const opt = document.createElement("option");
      opt.value = city;
      frag.appendChild(opt);
    });

    list.appendChild(frag);
  }

  loadCitiesDatalist();

  // Password visibility toggle (Font Awesome eye icon).
  document.querySelectorAll(".toggle-password").forEach((btn) => {
    btn.addEventListener("click", () => {
      const wrapper = btn.closest(".password-wrapper");
      const input = wrapper?.querySelector("input");
      const icon = btn.querySelector("i");

      if (!input) return;

      const isPassword = input.type === "password";
      input.type = isPassword ? "text" : "password";

      if (icon) {
        icon.classList.toggle("fa-eye", !isPassword);
        icon.classList.toggle("fa-eye-slash", isPassword);
      }

      // Keep aria attributes in sync for accessibility.
      btn.setAttribute("aria-label", isPassword ? "הסתר סיסמה" : "הצג סיסמה");
      btn.setAttribute("aria-pressed", isPassword ? "true" : "false");
    });
  });

  const isEmailValid = (value) =>
    /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test((value || "").trim());

  const isIsraeliPhoneValid = (value) =>
    /^05\d{8}$/.test((value || "").trim());

  function getRowEl(input) {
    return input?.closest?.(".form-row") || null;
  }

  function setFieldError(input, message) {
    const row = getRowEl(input);
    if (!row || !input) return;
    const p = row.querySelector(".error-message");
    if (p) p.textContent = message || "";
    input.setAttribute("aria-invalid", message ? "true" : "false");
  }

  function clearFieldError(input) {
    if (!input) return;
    setFieldError(input, "");
  }

  // Visual feedback for invalid inputs (CSS animation via .input-error).
  function shakeInput(input) {
    if (!input) return;
    input.classList.remove("input-error");
    void input.offsetWidth;
    input.classList.add("input-error");
    input.addEventListener(
      "animationend",
      () => input.classList.remove("input-error"),
      { once: true }
    );
  }

  // Shows a form-level alert summarizing validation errors.
  function setAlert(alertEl, messages) {
    if (!alertEl) return;

    if (!messages || messages.length === 0) {
      alertEl.hidden = true;
      alertEl.innerHTML = "";
      return;
    }

    alertEl.hidden = false;
    alertEl.innerHTML = `
      <strong>יש לתקן את השדות הבאים:</strong>
      <ul>
        ${messages.map((m) => `<li>${m}</li>`).join("")}
      </ul>
    `;
    alertEl.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  // Legacy flag used by older UI logic.
  function setLoggedInLegacy() {
    try {
      sessionStorage.setItem("edumatchLoggedIn", "true");
    } catch (_) {}
  }

  // Clears fields on bfcache/back-forward to reduce unwanted autofill leftovers.
  function clearRegisterFieldsIfPresent() {
    const registerForm = document.querySelector("#register-form");
    if (!registerForm) return;

    const email = registerForm.querySelector("#register-email");
    const password = registerForm.querySelector("#register-password");

    if (email) email.value = "";
    if (password) password.value = "";

    const registerAlert = registerForm.querySelector("#register-alert");
    if (registerAlert) setAlert(registerAlert, []);
  }

  window.addEventListener("pageshow", () => {
    const registerForm = document.querySelector("#register-form");
    if (!registerForm) return;

    const email = registerForm.querySelector("#register-email");
    const password = registerForm.querySelector("#register-password");

    const hasAutofill = (email && email.value) || (password && password.value);
    if (hasAutofill) clearRegisterFieldsIfPresent();
  });

  const registerForm = document.querySelector("#register-form");
  if (!registerForm) return;

  const first_name = registerForm.querySelector("#first-name");
  const last_name = registerForm.querySelector("#last-name");
  const email = registerForm.querySelector("#register-email");
  const phone = registerForm.querySelector("#register-phone");
  const password = registerForm.querySelector("#register-password");

  const terms = registerForm.querySelector("input[name='terms']");
  const roleRadios = registerForm.querySelectorAll("input[name='role']");
  const teacherFields = registerForm.querySelector(".role-teacher");
  const registerAlert = registerForm.querySelector("#register-alert");

  // Toggle teacher-only fields based on selected role.
  function updateRoleFields() {
    const role = registerForm.querySelector("input[name='role']:checked")?.value;
    if (teacherFields) {
      teacherFields.classList.toggle("is-open", role === "teacher");
    }
  }

  roleRadios.forEach((r) => r.addEventListener("change", updateRoleFields));
  updateRoleFields();

  const subjectsContainer = registerForm.querySelector("#subjects-container");
  const addSubjectBtn = registerForm.querySelector("#add-subject-btn");

  // Dynamic add/remove of teacher subject rows.
  if (subjectsContainer && addSubjectBtn) {
    addSubjectBtn.addEventListener("click", () => {
      const row = document.createElement("div");
      row.className = "subject-row";
      row.innerHTML = `
        <input type="text" name="teacher-subject[]" placeholder="מקצוע">
        <input type="number" name="teacher-price[]" placeholder="מחיר לשעה" min="0">
        <button type="button" class="btn-secondary subject-remove-btn" aria-label="מחק מקצוע">✕</button>
      `;
      subjectsContainer.appendChild(row);
    });

    subjectsContainer.addEventListener("click", (e) => {
      const btn = e.target.closest(".subject-remove-btn");
      if (!btn) return;
      btn.closest(".subject-row")?.remove();
    });
  }

  // Collect teacher subjects and attach shared duration_minutes from lesson-duration input.
  function collectTeacherSubjects() {
    const subjectInputs = Array.from(
      registerForm.querySelectorAll("input[name='teacher-subject[]']")
    );
    const priceInputs = Array.from(
      registerForm.querySelectorAll("input[name='teacher-price[]']")
    );

    const durationEl = registerForm.querySelector("#lesson-duration");
    const durationRaw = durationEl?.value;
    const duration =
      durationRaw === "" || durationRaw == null ? NaN : Number(durationRaw);

    const out = [];
    const max = Math.max(subjectInputs.length, priceInputs.length);

    for (let i = 0; i < max; i++) {
      const name = (subjectInputs[i]?.value || "").trim();
      const priceRaw = priceInputs[i]?.value;
      const price = priceRaw === "" || priceRaw == null ? NaN : Number(priceRaw);

      if (!name && !Number.isFinite(price)) continue;

      out.push({
        subject_name: name,
        price_per_hour: price,
        duration_minutes: duration,
      });
    }

    return { out, subjectInputs, priceInputs, durationEl };
  }

  // Full client-side validation before sending JSON to /api/register.
  function validateRegister() {
    const errors = [];
    const invalidInputs = [];

    [first_name, last_name, email, phone, password].forEach(clearFieldError);

    if (!first_name?.value.trim()) {
      errors.push("שם פרטי חסר");
      invalidInputs.push(first_name);
    }

    if (!last_name?.value.trim()) {
      errors.push("שם משפחה חסר");
      invalidInputs.push(last_name);
    }

    if (!email?.value.trim() || !isEmailValid(email.value)) {
      errors.push("אימייל לא תקין");
      invalidInputs.push(email);
    }

    if (phone?.value && !isIsraeliPhoneValid(phone.value)) {
      errors.push("טלפון לא תקין");
      invalidInputs.push(phone);
    }

    if (!password?.value || password.value.length < 6) {
      errors.push("סיסמה קצרה מדי");
      invalidInputs.push(password);
    }

    if (terms && !terms.checked) {
      errors.push("יש לאשר תנאי שימוש");
    }

    const role = registerForm.querySelector("input[name='role']:checked")?.value;

    if (role === "teacher") {
      const cityEl = registerForm.querySelector("#teacher-city");
      const expEl = registerForm.querySelector("#teacher-experience");

      const city = (cityEl?.value || "").trim();
      const years = Number(expEl?.value);

      if (!city) {
        errors.push("יש לבחור עיר");
        invalidInputs.push(cityEl);
      }

      if (!Number.isFinite(years) || years < 0) {
        errors.push("שנות ניסיון לא תקינות");
        invalidInputs.push(expEl);
      }

      const { out: subjects, subjectInputs, priceInputs, durationEl } =
        collectTeacherSubjects();

      if (!subjects.length) {
        errors.push("יש להזין לפחות מקצוע אחד");
        if (subjectInputs[0]) invalidInputs.push(subjectInputs[0]);
      } else {
        subjects.forEach((s, idx) => {
          if (!s.subject_name) {
            errors.push(`מקצוע חסר בשורה ${idx + 1}`);
            if (subjectInputs[idx]) invalidInputs.push(subjectInputs[idx]);
          }
          if (!Number.isFinite(s.price_per_hour) || s.price_per_hour <= 0) {
            errors.push(`מחיר לא תקין בשורה ${idx + 1}`);
            if (priceInputs[idx]) invalidInputs.push(priceInputs[idx]);
          }
        });
      }

      const duration = Number(durationEl?.value);
      if (!Number.isFinite(duration) || duration <= 0) {
        errors.push("יש להזין משך שיעור בדקות");
        invalidInputs.push(durationEl);
      }
    }

    return { errors, invalidInputs: invalidInputs.filter(Boolean) };
  }

  registerForm.addEventListener("submit", async (e) => {
    // Prevent default HTML form submit and send JSON via fetch instead.
    e.preventDefault();

    const { errors, invalidInputs } = validateRegister();
    if (errors.length) {
      invalidInputs.forEach(shakeInput);
      setAlert(registerAlert, errors);
      return;
    }

    const role =
      registerForm.querySelector("input[name='role']:checked")?.value ||
      "student";

    const lesson_mode =
      registerForm.querySelector("input[name='lesson-mode']:checked")?.value ||
      "both";

    const payload = {
      first_name: first_name.value.trim(),
      last_name: last_name.value.trim(),
      email: email.value.trim(),
      phone: phone.value.trim() || null,
      password: password.value,
      role,
      lesson_mode,
    };

    if (role === "teacher") {
      payload["teacher-city"] =
        registerForm.querySelector("#teacher-city")?.value.trim() || null;

      payload["teacher-experience"] =
        Number(registerForm.querySelector("#teacher-experience")?.value) || 0;

      payload.subjects = collectTeacherSubjects().out;
    }

    try {
      const submitBtn = registerForm.querySelector("button[type='submit']");
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.dataset.prevText = submitBtn.textContent;
        submitBtn.textContent = "שולח...";
      }

      const res = await fetch("/api/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "same-origin",
        body: JSON.stringify(payload),
      });

      const data = await res.json().catch(() => ({}));

      if (!res.ok) {
        setAlert(registerAlert, [data?.message || "שגיאה בהרשמה"]);
        return;
      }

      // Auto-login after successful registration.
      const loginRes = await fetch("/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "same-origin",
        body: JSON.stringify({
          email: payload.email,
          password: payload.password,
        }),
      });

      if (!loginRes.ok) {
        setAlert(registerAlert, ["נרשמת אך ההתחברות נכשלה"]);
        return;
      }

      setLoggedInLegacy();

      if (role === "teacher") {
        sessionStorage.setItem("showAvailabilityBanner", "true");
      }

      window.location.href = "/pages/profile/profile.html";
    } catch (err) {
      console.error(err);
      setAlert(registerAlert, ["שגיאת שרת"]);
    } finally {
      const submitBtn = registerForm.querySelector("button[type='submit']");
      if (submitBtn) {
        submitBtn.disabled = false;
        if (submitBtn.dataset.prevText) {
          submitBtn.textContent = submitBtn.dataset.prevText;
          delete submitBtn.dataset.prevText;
        }
      }
    }
  });
});
