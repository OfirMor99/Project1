// public/pages/register/register.js

document.addEventListener("DOMContentLoaded", () => {
  // Run the script only after the HTML is fully loaded.

  // ======================================================
  // ✅ Cities datalist loader (DEFAULT + DB)
  // ======================================================
  async function loadCitiesDatalist() {
    // Populates the <datalist id="cities-list"> with city options.

    const list = document.getElementById("cities-list");
    // Grabs the datalist element used by the city input.
    if (!list) return;
    // If the datalist doesn't exist on the page, stop.

    const defaultCities = [
      // Local fallback list of common Israeli cities (works even if API fails).
      "אור יהודה", "אופקים", "אילת", "אלעד", "אריאל", "אשדוד", "אשקלון",
      "באר יעקב", "באר שבע", "בית שמש", "בית שאן", "בני ברק", "בת ים",
      "גבעתיים", "גדרה", "דימונה", "הרצליה", "חדרה", "חולון", "חיפה",
      "טבריה", "יבנה", "יהוד-מונוסון", "ירוחם", "ירושלים",
      "כפר סבא", "כרמיאל", "לוד", "מודיעין-מכבים-רעות", "מעלה אדומים",
      "נהריה", "נס ציונה", "נצרת", "נשר", "נתיבות", "נתניה",
      "עכו", "עפולה", "ערד",
      "פתח תקווה", "צפת", "קריית אתא", "קריית גת", "קריית ים", "קריית מוצקין", "קריית שמונה",
      "ראש העין", "ראשון לציון", "רחובות", "רמלה", "רמת גן", "רמת השרון", "רעננה",
      "שדרות", "תל אביב-יפו"
    ];

    let dbCities = [];
    // Will hold cities returned from the backend.

    try {
      const res = await fetch(`/api/cities?ts=${Date.now()}`, {
        // Fetch city list from server, adding ts to avoid caching.
        headers: { Accept: "application/json" },
        cache: "no-store",
      });

      const data = await res.json().catch(() => null);
      // Safely parse JSON (doesn't crash if response isn't JSON).

      if (res.ok && data?.ok && Array.isArray(data.cities)) {
        // Use server cities only if the response structure is valid.
        dbCities = data.cities;
      }
    } catch (e) {
      // If the request fails, continue with defaults only.
      console.warn("❌ cities API failed, using defaults only:", e);
    }

    const merged = Array.from(
      // Merge defaults + db list, trim, remove empties, dedupe with Set.
      new Set([...defaultCities, ...dbCities].map((c) => String(c || "").trim()).filter(Boolean))
    ).sort((a, b) => a.localeCompare(b, "he"));
    // Sort cities in Hebrew order.

    list.innerHTML = "";
    // Clears existing options (if any).

    const frag = document.createDocumentFragment();
    // Uses a fragment for faster DOM insertion.

    merged.forEach((city) => {
      const opt = document.createElement("option");
      // Creates a <option> item for datalist.
      opt.value = city;
      frag.appendChild(opt);
    });

    list.appendChild(frag);
    // Injects all options at once.
  }

  loadCitiesDatalist();
  // Loads the cities list immediately on page load.

  // =========================
  // ✅ Show/Hide password (eye button) - Font Awesome
  // =========================
  document.querySelectorAll(".toggle-password").forEach((btn) => {
    // Binds toggle behavior to every "eye" button.

    btn.addEventListener("click", () => {
      const wrapper = btn.closest(".password-wrapper");
      // Finds the password wrapper near the clicked button.
      const input = wrapper?.querySelector("input");
      // Finds the password input inside that wrapper.
      const icon = btn.querySelector("i");
      // Gets the <i> icon inside the button.

      if (!input) return;
      // Safety guard if markup is missing.

      const isPassword = input.type === "password";
      // Checks current input state.
      input.type = isPassword ? "text" : "password";
      // Toggles between hidden and visible password.

      if (icon) {
        // Switches the eye icon class based on state.
        icon.classList.toggle("fa-eye", !isPassword);
        icon.classList.toggle("fa-eye-slash", isPassword);
      }

      btn.setAttribute("aria-label", isPassword ? "הסתר סיסמה" : "הצג סיסמה");
      // Updates accessibility label.
      btn.setAttribute("aria-pressed", isPassword ? "true" : "false");
      // Updates pressed state for accessibility.
    });
  });

  // =========================
  // Helpers
  // =========================
  const isEmailValid = (value) =>
    // Simple email format validation.
    /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test((value || "").trim());

  const isIsraeliPhoneValid = (value) =>
    // Validates Israeli mobile numbers that start with 05 + 8 digits.
    /^05\d{8}$/.test((value || "").trim());

  function getRowEl(input) {
    // Returns the closest ".form-row" wrapper of an input.
    return input?.closest?.(".form-row") || null;
  }

  function setFieldError(input, message) {
    // Shows an error message under a specific field and updates aria-invalid.
    const row = getRowEl(input);
    if (!row || !input) return;
    const p = row.querySelector(".error-message");
    if (p) p.textContent = message || "";
    input.setAttribute("aria-invalid", message ? "true" : "false");
  }

  function clearFieldError(input) {
    // Clears the error message for a field.
    if (!input) return;
    setFieldError(input, "");
  }

  function shakeInput(input) {
    // Adds a temporary CSS animation class to draw attention to invalid inputs.
    if (!input) return;
    input.classList.remove("input-error");
    void input.offsetWidth; // Forces reflow so animation can restart.
    input.classList.add("input-error");
    input.addEventListener(
      "animationend",
      () => input.classList.remove("input-error"),
      { once: true }
    );
  }

  function setAlert(alertEl, messages) {
    // Shows a top alert with a list of validation problems (or hides it if none).
    if (!alertEl) return;

    if (!messages || messages.length === 0) {
      alertEl.hidden = true;
      alertEl.innerHTML = "";
      return;
    }

    alertEl.hidden = false;
    alertEl.innerHTML = `
      <strong>יש לתקן את השדות הבאים:</strong>
      <ul>
        ${messages.map((m) => `<li>${m}</li>`).join("")}
      </ul>
    `;
    alertEl.scrollIntoView({ behavior: "smooth", block: "start" });
    // Scrolls to the alert so the user sees it immediately.
  }

  function setLoggedInLegacy() {
    // Stores a legacy "logged in" flag in sessionStorage (for older UI logic).
    try {
      sessionStorage.setItem("edumatchLoggedIn", "true");
    } catch (_) {}
  }

  // =========================
  // Clear Register fields (anti-autofill leftovers)
  // =========================
  function clearRegisterFieldsIfPresent() {
    // Clears email/password fields and resets alert (helps fight browser autofill).
    const registerForm = document.querySelector("#register-form");
    if (!registerForm) return;

    const email = registerForm.querySelector("#register-email");
    const password = registerForm.querySelector("#register-password");

    if (email) email.value = "";
    if (password) password.value = "";

    const registerAlert = registerForm.querySelector("#register-alert");
    if (registerAlert) setAlert(registerAlert, []);
  }

  window.addEventListener("pageshow", () => {
    // Runs when navigating back/forward (bfcache), to clean autofilled values.
    const registerForm = document.querySelector("#register-form");
    if (!registerForm) return;

    const email = registerForm.querySelector("#register-email");
    const password = registerForm.querySelector("#register-password");

    const hasAutofill = (email && email.value) || (password && password.value);
    if (hasAutofill) clearRegisterFieldsIfPresent();
  });

  // =========================
  // REGISTER
  // =========================
  const registerForm = document.querySelector("#register-form");
  // Main registration form element.
  if (!registerForm) return;
  // If form isn't on the page, stop.

  const first_name = registerForm.querySelector("#first-name");
  const last_name = registerForm.querySelector("#last-name");
  const email = registerForm.querySelector("#register-email");
  const phone = registerForm.querySelector("#register-phone");
  const password = registerForm.querySelector("#register-password");
  // Core input references.

  const terms = registerForm.querySelector("input[name='terms']");
  const roleRadios = registerForm.querySelectorAll("input[name='role']");
  const teacherFields = registerForm.querySelector(".role-teacher");
  const registerAlert = registerForm.querySelector("#register-alert");
  // Elements that control role-specific UI + validation feedback.

  function updateRoleFields() {
    // Shows/hides teacher-only section based on selected role.
    const role = registerForm.querySelector("input[name='role']:checked")?.value;
    if (teacherFields) {
      teacherFields.classList.toggle("is-open", role === "teacher");
    }
  }

  roleRadios.forEach((r) => r.addEventListener("change", updateRoleFields));
  // Re-evaluate when role changes.
  updateRoleFields();
  // Run once on load.

  // =========================
  // ADD/REMOVE SUBJECT ROWS
  // =========================
  const subjectsContainer = registerForm.querySelector("#subjects-container");
  const addSubjectBtn = registerForm.querySelector("#add-subject-btn");
  // Teacher subjects dynamic fields.

  if (subjectsContainer && addSubjectBtn) {
    addSubjectBtn.addEventListener("click", () => {
      // Adds a new subject+price row.
      const row = document.createElement("div");
      row.className = "subject-row";
      row.innerHTML = `
        <input type="text" name="teacher-subject[]" placeholder="מקצוע">
        <input type="number" name="teacher-price[]" placeholder="מחיר לשעה" min="0">
        <button type="button" class="btn-secondary subject-remove-btn" aria-label="מחק מקצוע">✕</button>
      `;
      subjectsContainer.appendChild(row);
    });

    subjectsContainer.addEventListener("click", (e) => {
      // Removes a subject row via event delegation.
      const btn = e.target.closest(".subject-remove-btn");
      if (!btn) return;
      btn.closest(".subject-row")?.remove();
    });
  }

  // =========================
  // Collect teacher subjects (YOUR DB: teacher_subjects.duration_minutes)
  // =========================
  function collectTeacherSubjects() {
    // Reads subject + price fields and adds the shared lesson duration.
    const subjectInputs = Array.from(
      registerForm.querySelectorAll("input[name='teacher-subject[]']")
    );
    const priceInputs = Array.from(
      registerForm.querySelectorAll("input[name='teacher-price[]']")
    );

    const durationEl = registerForm.querySelector("#lesson-duration");
    // The lesson duration input (minutes).
    const durationRaw = durationEl?.value;
    const duration =
      durationRaw === "" || durationRaw == null ? NaN : Number(durationRaw);
    // Converts duration to a number (NaN if missing).

    const out = [];
    const max = Math.max(subjectInputs.length, priceInputs.length);
    // Loops safely even if arrays differ.

    for (let i = 0; i < max; i++) {
      const name = (subjectInputs[i]?.value || "").trim();
      const priceRaw = priceInputs[i]?.value;
      const price = priceRaw === "" || priceRaw == null ? NaN : Number(priceRaw);

      if (!name && !Number.isFinite(price)) continue;
      // Skip fully empty rows.

      out.push({
        subject_name: name,
        price_per_hour: price,
        duration_minutes: duration,
      });
      // Normalized subject object expected by the API/DB.
    }

    return { out, subjectInputs, priceInputs, durationEl };
    // Also returns the DOM inputs for error highlighting.
  }

  function validateRegister() {
    // Validates all required inputs and returns errors + which inputs are invalid.
    const errors = [];
    const invalidInputs = [];

    [first_name, last_name, email, phone, password].forEach(clearFieldError);
    // Clears previous per-field errors.

    if (!first_name?.value.trim()) {
      errors.push("שם פרטי חסר");
      invalidInputs.push(first_name);
    }

    if (!last_name?.value.trim()) {
      errors.push("שם משפחה חסר");
      invalidInputs.push(last_name);
    }

    if (!email?.value.trim() || !isEmailValid(email.value)) {
      errors.push("אימייל לא תקין");
      invalidInputs.push(email);
    }

    if (phone?.value && !isIsraeliPhoneValid(phone.value)) {
      errors.push("טלפון לא תקין");
      invalidInputs.push(phone);
    }

    if (!password?.value || password.value.length < 6) {
      errors.push("סיסמה קצרה מדי");
      invalidInputs.push(password);
    }

    if (terms && !terms.checked) {
      errors.push("יש לאשר תנאי שימוש");
    }
    // Terms checkbox must be checked.

    const role = registerForm.querySelector("input[name='role']:checked")?.value;
    // Selected role (student/teacher).

    if (role === "teacher") {
      // Extra validations for teacher registration.
      const cityEl = registerForm.querySelector("#teacher-city");
      const expEl = registerForm.querySelector("#teacher-experience");

      const city = (cityEl?.value || "").trim();
      const years = Number(expEl?.value);

      if (!city) {
        errors.push("יש לבחור עיר");
        invalidInputs.push(cityEl);
      }

      if (!Number.isFinite(years) || years < 0) {
        errors.push("שנות ניסיון לא תקינות");
        invalidInputs.push(expEl);
      }

      const { out: subjects, subjectInputs, priceInputs, durationEl } =
        collectTeacherSubjects();
      // Collects subjects + duration and exposes inputs for error marking.

      if (!subjects.length) {
        errors.push("יש להזין לפחות מקצוע אחד");
        if (subjectInputs[0]) invalidInputs.push(subjectInputs[0]);
      } else {
        subjects.forEach((s, idx) => {
          if (!s.subject_name) {
            errors.push(`מקצוע חסר בשורה ${idx + 1}`);
            if (subjectInputs[idx]) invalidInputs.push(subjectInputs[idx]);
          }
          if (!Number.isFinite(s.price_per_hour) || s.price_per_hour <= 0) {
            errors.push(`מחיר לא תקין בשורה ${idx + 1}`);
            if (priceInputs[idx]) invalidInputs.push(priceInputs[idx]);
          }
        });
      }

      const duration = Number(durationEl?.value);
      if (!Number.isFinite(duration) || duration <= 0) {
        errors.push("יש להזין משך שיעור בדקות");
        invalidInputs.push(durationEl);
      }
    }

    return { errors, invalidInputs: invalidInputs.filter(Boolean) };
    // Returns all issues and the exact inputs to highlight.
  }

  registerForm.addEventListener("submit", async (e) => {
    // Intercepts form submit and sends JSON via fetch instead of default POST.
    e.preventDefault();

    const { errors, invalidInputs } = validateRegister();
    // Run validation before submitting.
    if (errors.length) {
      invalidInputs.forEach(shakeInput);
      // Visually highlight invalid fields.
      setAlert(registerAlert, errors);
      // Show a summary alert.
      return;
    }

    const role =
      registerForm.querySelector("input[name='role']:checked")?.value ||
      "student";
    // Selected role, defaulting to student.

    const lesson_mode =
      registerForm.querySelector("input[name='lesson-mode']:checked")?.value ||
      "both";
    // Selected lesson mode preference (online/frontal/both).

    const payload = {
      // Base registration payload sent to the backend.
      first_name: first_name.value.trim(),
      last_name: last_name.value.trim(),
      email: email.value.trim(),
      phone: phone.value.trim() || null,
      password: password.value,
      role,
      lesson_mode,
    };

    if (role === "teacher") {
      // Adds teacher-specific fields only when role is teacher.
      payload["teacher-city"] =
        registerForm.querySelector("#teacher-city")?.value.trim() || null;

      payload["teacher-experience"] =
        Number(registerForm.querySelector("#teacher-experience")?.value) || 0;

      payload.subjects = collectTeacherSubjects().out;
      // Includes teacher subjects list with prices + duration.
    }

    try {
      const submitBtn = registerForm.querySelector("button[type='submit']");
      // Disables submit button to prevent double submits.
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.dataset.prevText = submitBtn.textContent;
        submitBtn.textContent = "שולח...";
      }

      const res = await fetch("/api/register", {
        // Sends registration request to backend as JSON.
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "same-origin",
        body: JSON.stringify(payload),
      });

      const data = await res.json().catch(() => ({}));
      // Parses response JSON safely.

      if (!res.ok) {
        // Shows server error message (e.g., email already exists).
        setAlert(registerAlert, [data?.message || "שגיאה בהרשמה"]);
        return;
      }

      const loginRes = await fetch("/api/login", {
        // Auto-login after successful registration.
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "same-origin",
        body: JSON.stringify({
          email: payload.email,
          password: payload.password,
        }),
      });

      if (!loginRes.ok) {
        // Registration succeeded but login failed (rare but possible).
        setAlert(registerAlert, ["נרשמת אך ההתחברות נכשלה"]);
        return;
      }

      setLoggedInLegacy();
      // Marks login state in sessionStorage for legacy UI logic.

      if (role === "teacher") {
        sessionStorage.setItem("showAvailabilityBanner", "true");
        // Triggers the "set availability" banner on profile page.
      }

      window.location.href = "/pages/profile/profile.html";
      // Redirects user to the profile page after login.
    } catch (err) {
      // Network/server failure handling.
      console.error(err);
      setAlert(registerAlert, ["שגיאת שרת"]);
    } finally {
      const submitBtn = registerForm.querySelector("button[type='submit']");
      // Re-enables submit button and restores original text.
      if (submitBtn) {
        submitBtn.disabled = false;
        if (submitBtn.dataset.prevText) {
          submitBtn.textContent = submitBtn.dataset.prevText;
          delete submitBtn.dataset.prevText;
        }
      }
    }
  });
});
