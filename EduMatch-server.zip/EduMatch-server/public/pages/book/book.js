// public/pages/book/book.js
document.addEventListener("DOMContentLoaded", () => {
  // Normalize strings for comparisons (trim + lowercase)
  function normalize(str) {
    return (str || "").trim().toLowerCase();
  }

  // Read query param from URL (e.g., teacherId, subject)
  function getQueryParam(name) {
    const url = new URL(window.location.href);
    return url.searchParams.get(name);
  }

  // Render lesson mode tags in the teacher card
  function buildModeTags(lessonMode) {
    const box = document.getElementById("teacher-modes");
    if (!box) return;
    box.innerHTML = "";

    const addTag = (mode, label) => {
      const span = document.createElement("span");
      span.className = "lesson-mode-tag";
      span.dataset.mode = mode;
      span.textContent = label;
      box.appendChild(span);
    };

    if (lessonMode === "online") addTag("online", "💻 מקוון");
    else if (lessonMode === "frontal") addTag("frontal", "🏫 פרונטלי");
    else {
      addTag("online", "💻 מקוון");
      addTag("frontal", "🏫 פרונטלי");
    }
  }

  // Render lesson mode radio buttons in the summary box
  function buildModeRadios(lessonMode) {
    const box = document.getElementById("summary-mode-box");
    if (!box) return;
    box.innerHTML = "";

    const mk = (value, label, checked) => {
      const lab = document.createElement("label");
      lab.className = "summary-radio";
      lab.innerHTML = `<input type="radio" name="summary-lesson-mode" value="${value}" ${
        checked ? "checked" : ""
      }> ${label}`;
      box.appendChild(lab);
    };

    if (lessonMode === "online") mk("online", "מקוון", true);
    else if (lessonMode === "frontal") mk("frontal", "פרונטלי", true);
    else {
      mk("online", "מקוון", true);
      mk("frontal", "פרונטלי", false);
    }
  }

  // =========================
  // Availability helpers
  // =========================

  // Checks if the teacher has any weekly availability enabled
  function hasAnyAvailability(weekly) {
    if (!weekly) return false;
    return Object.values(weekly).some((v) => v && v.enabled);
  }

  // Convert HH:mm to total minutes
  function timeToMinutes(t) {
    const [h, m] = (t || "00:00").split(":").map(Number);
    return h * 60 + (m || 0);
  }

  // Convert total minutes back to HH:mm
  function minutesToTime(mins) {
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
  }

  // Add minutes to a HH:mm time string
  function addMinutesToTimeHHMM(startHHMM, addMins) {
    const base = timeToMinutes(startHHMM);
    return minutesToTime(base + (Number(addMins) || 0));
  }

  // Build available time slots for a day (step = lesson duration)
  function buildSlotsForDay(availabilityDay, durationMinutes) {
    if (!availabilityDay?.enabled) return [];
    if (!availabilityDay.start || !availabilityDay.end) return [];

    const start = timeToMinutes(availabilityDay.start);
    const end = timeToMinutes(availabilityDay.end);
    const dur = Math.max(1, Number(durationMinutes) || 60);

    if (start >= end) return [];

    const slots = [];
    for (let t = start; t + dur <= end; t += dur) {
      slots.push(minutesToTime(t));
    }
    return slots;
  }

  // Convert Date -> YYYY-MM-DD
  function toISODate(dateObj) {
    const y = dateObj.getFullYear();
    const m = String(dateObj.getMonth() + 1).padStart(2, "0");
    const d = String(dateObj.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  }

  // Resolve availability for a specific date (exceptions override weekly)
  function getResolvedAvailabilityForDate(teacher, dateObj) {
    const iso = toISODate(dateObj);

    const exceptions = teacher?.exceptions || [];
    const ex = exceptions.find((e) => e && e.date === iso);

    if (ex && ex.type === "off") return { enabled: false, start: "", end: "" };

    if (ex && ex.type === "custom") {
      // Support both start/end and start_time/end_time field names
      return {
        enabled: true,
        start: ex.start || ex.start_time || "",
        end: ex.end || ex.end_time || "",
      };
    }

    const key = dayKeyByGetDay[dateObj.getDay()];
    const dayAvail = teacher?.availabilityWeekly?.[key];
    return dayAvail || { enabled: false, start: "", end: "" };
  }

  // Returns true if at least one slot exists on that date
  function hasSlotsOnDate(teacher, dateObj, durationMinutes) {
    const resolved = getResolvedAvailabilityForDate(teacher, dateObj);
    const slots = buildSlotsForDay(resolved, Number(durationMinutes) || 60);
    return slots.length > 0;
  }

  // =========================
  // DOM refs
  // =========================

  // Main sections (shown/hidden based on state)
  const layoutEl = document.getElementById("booking-layout");
  const errorEl = document.getElementById("booking-error");
  const noAvailEl = document.getElementById("booking-no-availability");

  // Teacher card fields
  const teacherNameEl = document.getElementById("teacher-name");
  const teacherCityEl = document.getElementById("teacher-city");
  const teacherSubjectEl = document.getElementById("teacher-subject");
  const teacherPriceEl = document.getElementById("teacher-price");
  const durationLabelEl = document.getElementById("lesson-duration-label");

  // Calendar + slots
  const calendarMonthLabel = document.getElementById("calendar-month-label");
  const calendarDaysContainer = document.getElementById("calendar-days");
  const timeSlotsContainer = document.getElementById("time-slots");
  const timesHintEl = document.getElementById("times-hint");

  // Summary + confirm
  const summaryDateEl = document.getElementById("summary-date");
  const summaryTimeEl = document.getElementById("summary-time");
  const summaryDurationEl = document.getElementById("summary-duration");
  const summaryPriceEl = document.getElementById("summary-price");
  const confirmBtn = document.getElementById("confirm-booking");

  // Hebrew month names for calendar label
  const monthNamesHebrew = [
    "ינואר","פברואר","מרץ","אפריל","מאי","יוני",
    "יולי","אוגוסט","ספטמבר","אוקטובר","נובמבר","דצמבר",
  ];

  // Maps JS getDay() -> weekly availability keys
  const dayKeyByGetDay = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];

  // UI state
  let currentYear, currentMonth;
  let selectedDate = null;
  let selectedTime = null;

  // Cached teacher + chosen subject (used when creating booking)
  let teacher = null;
  let chosenSubjectObj = null;
  let chosenSubjectId = null;
  let chosenDuration = 60;
  let chosenPrice = null;

  // =========================
  // Booking API
  // =========================

  // Resolve subject_id by subject name (server lookup)
  async function getSubjectIdByName(subjectName) {
    const name = (subjectName || "").trim();
    if (!name) throw new Error("Missing subject name");

    const res = await fetch(`/api/subjects/resolve?name=${encodeURIComponent(name)}`, {
      headers: { Accept: "application/json" },
      cache: "no-store",
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data?.ok || !data.subject_id) throw new Error("Failed to resolve subject_id");
    return Number(data.subject_id);
  }

  // Create booking in DB (requires selected date/time)
  async function createBooking() {
    if (!teacher) throw new Error("Missing teacher");
    if (!selectedDate || !selectedTime) throw new Error("Missing date/time");

    const teacherId = Number(getQueryParam("teacherId"));
    const dateISO = toISODate(selectedDate);

    const subjectName = chosenSubjectObj?.subject || chosenSubjectObj?.subject_name || "";
    const subjectId = chosenSubjectId ?? (await getSubjectIdByName(subjectName));

    const payload = {
      teacher_user_id: teacherId,
      subject_id: subjectId,
      lesson_date: dateISO,
      start_time: selectedTime,
    };

    const res = await fetch("/api/bookings", {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      credentials: "same-origin",
      body: JSON.stringify(payload),
    });

    const data = await res.json().catch(() => ({}));

    // If not logged in -> redirect to login with returnTo
    if (res.status === 401) {
      alert("התחבר על מנת להזמין שיעור");
      const returnTo = encodeURIComponent(window.location.pathname + window.location.search);
      window.location.href = `../login/login.html?returnTo=${returnTo}`;
      throw new Error("Not logged in");
    }

    if (!res.ok || !data?.ok) {
      throw new Error(data?.message || `שגיאה ביצירת הזמנה (HTTP ${res.status})`);
    }

    return { bookingId: data.bookingId, data };
  }

  // =========================
  // Init (load teacher + build UI)
  // =========================

  (async function init() {
    const teacherId = getQueryParam("teacherId");
    const requestedSubject = getQueryParam("subject");

    // Missing teacherId -> show error card
    if (!teacherId) {
      if (errorEl) errorEl.style.display = "block";
      return;
    }

    // Fetch teacher details
    try {
      const res = await fetch(`/api/teachers/${encodeURIComponent(teacherId)}`, {
        headers: { Accept: "application/json" },
        cache: "no-store",
      });
      const data = await res.json().catch(() => ({}));

      if (!res.ok || !data?.ok || !data?.teacher) {
        if (errorEl) errorEl.style.display = "block";
        return;
      }
      teacher = data.teacher;
    } catch (e) {
      console.error("Failed to fetch teacher:", e);
      if (errorEl) errorEl.style.display = "block";
      return;
    }

    // No weekly availability -> show info card
    if (!hasAnyAvailability(teacher?.availabilityWeekly)) {
      if (noAvailEl) noAvailEl.style.display = "block";
      return;
    }

    if (layoutEl) layoutEl.style.display = "block";

    // Choose subject to display (requestedSubject or first subject)
    const subjects = Array.isArray(teacher.subjects) ? teacher.subjects : [];
    let chosen = null;

    if (requestedSubject) {
      chosen =
        subjects.find((s) => normalize(s.subject) === normalize(requestedSubject)) ||
        subjects.find((s) => normalize(s.subject).includes(normalize(requestedSubject))) ||
        null;
    }
    if (!chosen) chosen = subjects[0] || { subject: "לא צוין", price: "—", duration_minutes: 60 };

    chosenSubjectObj = chosen;
    chosenDuration = Number(chosen.duration_minutes || 60);
    chosenPrice = chosen.price ?? chosen.price_per_hour ?? null;

    // subject_id is resolved later by name (if needed)
    chosenSubjectId = null;

    // Fill teacher card + summary
    if (teacherNameEl) teacherNameEl.textContent = teacher.fullName || "—";
    if (teacherCityEl) teacherCityEl.textContent = teacher.city || "לא צוין";
    if (teacherSubjectEl) teacherSubjectEl.textContent = chosen.subject || "לא צוין";
    if (teacherPriceEl) teacherPriceEl.textContent = `${chosenPrice ?? "—"} ש"ח`;
    if (durationLabelEl) durationLabelEl.textContent = `${chosenDuration} דקות`;

    if (summaryDurationEl) summaryDurationEl.textContent = `${chosenDuration} דקות`;
    if (summaryPriceEl) summaryPriceEl.textContent = `${chosenPrice ?? "—"} ש"ח`;

    buildModeTags(teacher.lessonMode);
    buildModeRadios(teacher.lessonMode);

    // Show selected lesson mode text under the radios
    const summaryModeBox = document.getElementById("summary-mode-box");
    const modeChosenLine = document.createElement("div");
    modeChosenLine.id = "mode-chosen-line";
    modeChosenLine.style.marginTop = "8px";
    modeChosenLine.style.fontSize = "14px";
    modeChosenLine.style.opacity = "0.9";

    function updateModeChosenLine() {
      const picked =
        document.querySelector('input[name="summary-lesson-mode"]:checked')?.value || "online";
      modeChosenLine.textContent = `נבחר: ${picked === "frontal" ? "פרונטלי" : "מקוון"}`;
    }

    if (summaryModeBox && !document.getElementById("mode-chosen-line")) {
      summaryModeBox.appendChild(modeChosenLine);
      updateModeChosenLine();
      summaryModeBox.addEventListener("change", updateModeChosenLine);
    }

    // Init calendar UI
    initCalendar(teacher, chosenDuration);

    // Confirm booking -> create on server -> go to profile
    confirmBtn?.addEventListener("click", async () => {
      if (!selectedDate || !selectedTime) return;
      confirmBtn.disabled = true;

      try {
        const { bookingId } = await createBooking();
        sessionStorage.setItem("lastBookingId", String(bookingId));
        window.location.href = "../profile/profile.html#future";
      } catch (err) {
        if (err?.message === "Not logged in") return; // already redirected
        console.error("createBooking error:", err);
        alert(err?.message || "שגיאה ביצירת הזמנה");
        confirmBtn.disabled = false;
      }
    });
  })();

  // =========================
  // Calendar
  // =========================

  // Setup current month and navigation
  function initCalendar(teacher, durationMinutes) {
    const today = new Date();
    currentYear = today.getFullYear();
    currentMonth = today.getMonth();

    renderCalendar(teacher, durationMinutes, currentYear, currentMonth);

    document.getElementById("prev-month")?.addEventListener("click", () =>
      changeMonth(teacher, durationMinutes, -1)
    );
    document.getElementById("next-month")?.addEventListener("click", () =>
      changeMonth(teacher, durationMinutes, 1)
    );
  }

  // Change month and reset selection
  function changeMonth(teacher, durationMinutes, offset) {
    currentMonth += offset;
    if (currentMonth < 0) {
      currentMonth = 11;
      currentYear--;
    } else if (currentMonth > 11) {
      currentMonth = 0;
      currentYear++;
    }

    selectedDate = null;
    selectedTime = null;

    updateSummary();
    updateConfirmButtonState();

    if (timeSlotsContainer) timeSlotsContainer.innerHTML = "";
    if (timesHintEl) timesHintEl.textContent = "בחרי קודם תאריך ביומן כדי לראות שעות זמינות.";

    renderCalendar(teacher, durationMinutes, currentYear, currentMonth);
  }

  // Render month grid and disable invalid days
  function renderCalendar(teacher, durationMinutes, year, month) {
    if (!calendarDaysContainer || !calendarMonthLabel) return;

    calendarDaysContainer.innerHTML = "";

    const firstDayOfMonth = new Date(year, month, 1);
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const startDayIndex = firstDayOfMonth.getDay(); // 0=Sun

    calendarMonthLabel.textContent = `${monthNamesHebrew[month]} ${year}`;

    // Add blank cells before the 1st day
    for (let i = 0; i < startDayIndex; i++) {
      const blankCell = document.createElement("div");
      blankCell.className = "calendar-day calendar-day--empty";
      calendarDaysContainer.appendChild(blankCell);
    }

    const today = new Date();
    const startOfToday = new Date(today.getFullYear(), today.getMonth(), today.getDate());

    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(year, month, day);
      const dayOfWeek = date.getDay();

      const dayCell = document.createElement("button");
      dayCell.type = "button";
      dayCell.classList.add("calendar-day");
      dayCell.textContent = day;

      // Mark today
      if (year === today.getFullYear() && month === today.getMonth() && day === today.getDate()) {
        dayCell.classList.add("calendar-day--today");
      }

      const startOfCellDate = new Date(year, month, day);
      const isPastDay = startOfCellDate < startOfToday;

      // Disable weekends (Fri+Sat) and unavailable days
      const isWeekend = dayOfWeek === 5 || dayOfWeek === 6;
      const isUnavailableForTeacher = !hasSlotsOnDate(teacher, date, durationMinutes);

      const isDisabled = isPastDay || isWeekend || isUnavailableForTeacher;

      if (isDisabled) {
        dayCell.classList.add("calendar-day--disabled");
        dayCell.disabled = true;
      } else {
        dayCell.addEventListener("click", () =>
          onDateSelected(teacher, durationMinutes, year, month, day)
        );
      }

      // Keep selected styling
      if (
        selectedDate &&
        selectedDate.getFullYear() === year &&
        selectedDate.getMonth() === month &&
        selectedDate.getDate() === day
      ) {
        dayCell.classList.add("calendar-day--selected");
      }

      calendarDaysContainer.appendChild(dayCell);
    }
  }

  // Handle date selection -> load slots
  function onDateSelected(teacher, durationMinutes, year, month, day) {
    selectedDate = new Date(year, month, day);
    selectedTime = null;

    document.querySelectorAll(".calendar-day--selected").forEach((el) =>
      el.classList.remove("calendar-day--selected")
    );

    calendarDaysContainer?.querySelectorAll(".calendar-day").forEach((cell) => {
      if (cell.textContent === String(day) && !cell.classList.contains("calendar-day--disabled")) {
        cell.classList.add("calendar-day--selected");
      }
    });

    if (summaryDateEl) summaryDateEl.textContent = `${day} ${monthNamesHebrew[month]} ${year}`;
    if (summaryTimeEl) summaryTimeEl.textContent = "לא נבחר";

    loadTimeSlotsForDate(teacher, durationMinutes, selectedDate);
    updateConfirmButtonState();
  }

  // Render time slots for selected date
  function loadTimeSlotsForDate(teacher, durationMinutes, dateObj) {
    if (!timeSlotsContainer || !timesHintEl) return;

    timeSlotsContainer.innerHTML = "";

    const resolved = getResolvedAvailabilityForDate(teacher, dateObj);
    const slots = buildSlotsForDay(resolved, durationMinutes);

    if (!slots.length) {
      timesHintEl.textContent = "אין שעות זמינות ביום הזה. בחרי יום אחר.";
      return;
    }

    timesHintEl.textContent = "בחרי שעה זמינה מתוך הרשימה.";

    slots.forEach((timeStr) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "time-slot";
      btn.textContent = timeStr;
      btn.addEventListener("click", () => onTimeSelected(timeStr));
      timeSlotsContainer.appendChild(btn);
    });
  }

  // Handle time selection
  function onTimeSelected(timeStr) {
    selectedTime = timeStr;

    document.querySelectorAll(".time-slot--selected").forEach((el) =>
      el.classList.remove("time-slot--selected")
    );

    document.querySelectorAll(".time-slot").forEach((el) => {
      if (el.textContent === timeStr) el.classList.add("time-slot--selected");
    });

    if (summaryTimeEl) summaryTimeEl.textContent = timeStr;
    updateConfirmButtonState();
  }

  // Reset summary fields when selection is cleared
  function updateSummary() {
    if (!selectedDate && summaryDateEl) summaryDateEl.textContent = "לא נבחר";
    if (!selectedTime && summaryTimeEl) summaryTimeEl.textContent = "לא נבחר";
  }

  // Enable confirm only when date + time are selected
  function updateConfirmButtonState() {
    if (!confirmBtn) return;
    confirmBtn.disabled = !(selectedDate && selectedTime);
  }
});
